// Clean up any stray tsx global __dirname that interferes with vite-plugin-pwa module resolution
if ((globalThis as any).__dirname === '.' || (global as any).__dirname === '.') {
  delete (globalThis as any).__dirname;
  delete (global as any).__dirname;
}

// In AI Studio Cloud containers, HMR is disabled to prevent flickering and websocket errors
process.env.DISABLE_HMR = 'true';

import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Lazy initialization of Gemini client
let aiClient: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY' || apiKey.trim() === '') {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({ apiKey });
  }
  return aiClient;
}

// Fallback rule-based calculator in case Gemini API key is missing or offline
function calculateFallbackSplit(
  message: string,
  contextBillAmount?: number
) {
  const lower = message.toLowerCase();

  // 1. Bill amount extraction
  let subtotal = 0;
  const hasThisBillRef = lower.includes('this bill') || lower.includes('এই বিল') || lower.includes('আজকের বিল') || lower.includes('বর্তমান বিল');

  const billRegex = /(?:bill|বিল|টাকা|tk|taka|৳|\$)\s*[:=]?\s*([\d,]+(?:\.\d+)?)|([\d,]+(?:\.\d+)?)\s*(?:tk|taka|টাকা|৳|\$)/i;
  const billMatch = lower.match(billRegex);
  if (billMatch) {
    const rawVal = billMatch[1] || billMatch[2];
    subtotal = parseFloat(rawVal.replace(/,/g, ''));
  } else if (hasThisBillRef && contextBillAmount && contextBillAmount > 0) {
    subtotal = contextBillAmount;
  } else {
    // Find standalone number that is NOT followed by %, percent, জন, people, or friends
    const numMatches = Array.from(lower.matchAll(/\b(\d+(?:\.\d+)?)\b(?!\s*(?:%|percent|জন|people|persons|person|বন্ধু|friends))/g));
    if (numMatches.length > 0) {
      const candidate = parseFloat(numMatches[0][1]);
      if (candidate > 0) subtotal = candidate;
    }
  }

  // If no amount found in message, use context bill amount or clean default
  if (!subtotal || isNaN(subtotal) || subtotal <= 0) {
    if (contextBillAmount && contextBillAmount > 0) {
      subtotal = contextBillAmount;
    } else {
      subtotal = 1500; // sensible default
    }
  }

  // 2. People count
  let peopleCount = 3;
  const peopleMatch = lower.match(/(\d+)\s*(?:people|persons|person|জন|বন্ধু|friends)/i) ||
                      lower.match(/(?:among|between|মাঝে|মধ্যে)\s*(\d+)/i);
  if (peopleMatch) {
    peopleCount = Math.max(2, Math.min(20, parseInt(peopleMatch[1], 10)));
  }

  // 3. Extra percentage rule (e.g. "one owes 20% more")
  let extraPercent = 0;
  const extraMatch = lower.match(/(\d+(?:\.\d+)?)\s*%\s*(?:more|extra|বেশি|অতিরিক্ত|greater)/i) ||
                     lower.match(/(?:one owes|একজন)\s*(\d+(?:\.\d+)?)\s*%/i);
  if (extraMatch) {
    extraPercent = parseFloat(extraMatch[1]);
  } else if (lower.includes('20%') && (lower.includes('more') || lower.includes('বেশি'))) {
    extraPercent = 20;
  }

  // 4. Tax / VAT percentage
  let taxPercent = 0;
  const taxMatch = lower.match(/(\d+(?:\.\d+)?)\s*%\s*(?:tax|vat|ভ্যাট|ট্যাক্স|কর)/i) ||
                   lower.match(/(?:tax|vat|ভ্যাট|ট্যাক্স|কর)\s*[:=]?\s*(\d+(?:\.\d+)?)\s*%/i);
  if (taxMatch) {
    taxPercent = parseFloat(taxMatch[1]);
  } else if (lower.includes('tax') || lower.includes('ট্যাক্স') || lower.includes('vat') || lower.includes('ভ্যাট')) {
    taxPercent = 5; // default 5% if tax mentioned without percent
  }

  const taxAmount = Math.round((subtotal * taxPercent / 100) * 100) / 100;
  const grandTotal = Math.round((subtotal + taxAmount) * 100) / 100;

  // Calculate weights
  // If 1 person owes extraPercent% more than the other (peopleCount - 1) people:
  // Base weights: Others = 1.0 each, First person = (1 + extraPercent / 100)
  const weights: number[] = [];
  const p1Weight = 1 + (extraPercent / 100);
  weights.push(p1Weight);
  for (let i = 1; i < peopleCount; i++) {
    weights.push(1.0);
  }

  const totalWeight = weights.reduce((sum, w) => sum + w, 0);

  const participants = weights.map((w, idx) => {
    const isSpecial = idx === 0 && extraPercent > 0;
    const baseShare = Math.round((subtotal * (w / totalWeight)) * 100) / 100;
    // Strict proportional tax calculation
    const taxShare = Math.round((taxAmount * (baseShare / subtotal)) * 100) / 100;
    const totalToPay = Math.round((baseShare + taxShare) * 100) / 100;
    const percentageOfTotal = Math.round((totalToPay / grandTotal) * 1000) / 10;

    return {
      id: `person-${idx + 1}`,
      name: isSpecial
        ? `ব্যক্তি ১ (+${extraPercent}% বেশি)`
        : `ব্যক্তি ${idx + 1}`,
      baseShare,
      taxShare,
      tipShare: 0,
      totalToPay,
      percentageOfTotal,
      shareRatioDescription: isSpecial
        ? `মূল অংশ + ${extraPercent}% অতিরিক্ত এবং আনুপাতিক কর`
        : `সমান সাধারণ অংশ এবং আনুপাতিক কর`,
      note: isSpecial
        ? `অন্যদের চেয়ে ${extraPercent}% বেশি দায়ভার`
        : `সাধারণ আনুপাতিক অংশ`,
    };
  });

  // Reconcile rounding discrepancies on first participant so sum matches exactly
  const currentTotal = participants.reduce((s, p) => s + p.totalToPay, 0);
  const diff = Math.round((grandTotal - currentTotal) * 100) / 100;
  if (Math.abs(diff) > 0 && Math.abs(diff) < 1) {
    participants[0].totalToPay = Math.round((participants[0].totalToPay + diff) * 100) / 100;
    participants[0].taxShare = Math.round((participants[0].totalToPay - participants[0].baseShare) * 100) / 100;
  }

  const isBengali = /[\u0980-\u09FF]/.test(message);

  return {
    replyMessage: isBengali
      ? `মোট ${subtotal.toLocaleString()} টাকা ${peopleCount} জনের মধ্যে সফলভাবে ভাগ করা হয়েছে।${extraPercent > 0 ? ` একজন ২০% বেশি অংশীদার হওয়ায় তার উপর অতিরিক্ত দায় এবং আনুপাতিক ভ্যাট প্রযোজ্য হয়েছে।` : ''}${taxPercent > 0 ? ` মোট ${taxPercent}% ট্যাক্স (${taxAmount} টাকা) প্রত্যেকের খরচের আনুপাতিক হারে বণ্টন করা হয়েছে।` : ''}`
      : `Successfully split ${subtotal.toLocaleString()} across ${peopleCount} people.${extraPercent > 0 ? ` One person owes ${extraPercent}% more than the others.` : ''}${taxPercent > 0 ? ` Proportional ${taxPercent}% tax (${taxAmount}) was accurately distributed.` : ''}`,
    title: isBengali
      ? `${peopleCount} জনের বিল বিভাজন${extraPercent > 0 ? ` (+${extraPercent}% সমন্বয়)` : ''}`
      : `Bill Split for ${peopleCount} People${extraPercent > 0 ? ` (+${extraPercent}%)` : ''}`,
    currency: '৳',
    subtotal,
    taxPercent,
    taxAmount,
    tipOrServicePercent: 0,
    tipOrServiceAmount: 0,
    grandTotal,
    taxCalculationMethod: taxPercent > 0
      ? 'প্রত্যেক ব্যক্তির বেস খরচ অনুপাত অনুযায়ী ট্যাক্স আনুপাতিক হারে বণ্টিত হয়েছে (No unfair flat tax).'
      : 'ট্যাক্স অন্তর্ভুক্ত নেই বা ০%',
    participants,
    suggestions: [
      '৫% ভ্যাট যোগ করুন',
      '৪ জনের মধ্যে সমান ভাগ করুন',
      'একজনের জন্য অতিরিক্ত ১০% টিপ যোগ করুন'
    ]
  };
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      hasGeminiKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY')
    });
  });

  // POST /api/split-bill
  app.post('/api/split-bill', async (req, res) => {
    try {
      const { message, contextBillAmount, history } = req.body;

      if (!message || typeof message !== 'string') {
        return res.status(400).json({
          success: false,
          error: 'Message is required'
        });
      }

      const ai = getAI();

      // If no AI client available, use the robust mathematical calculation fallback
      if (!ai) {
        console.log('[Server] Gemini API Key not set. Using math calculation engine.');
        const fallbackResult = calculateFallbackSplit(message, contextBillAmount);
        return res.json({
          success: true,
          data: fallbackResult,
          mode: 'offline-math-engine'
        });
      }

      // Build conversation context for Gemini
      const prompt = `User Request: "${message}"
Context Active Memo / Day Total: ${contextBillAmount || 0}
Prior History Context: ${history ? JSON.stringify(history.slice(-4)) : 'None'}

Please calculate the exact bill split and output strictly adhering to the JSON schema.`;

      const systemInstruction = `You are an expert financial assistant and bill splitter embedded in a point-of-sale shop & restaurant daily memo system.
Your job is to parse natural language bill splitting and expense sharing requests from users (in English, Bengali, or mixed Banglish) and calculate mathematically exact individual totals with strictly proportional tax/VAT and tip/service distribution.

CRITICAL MATHEMATICAL RULES:
1. Base Bill (Subtotal):
   - If user explicitly provides a bill amount (e.g. "1500 tk", "bill is 3200", "৳৪,০০০"), use that amount.
   - If user says "this bill", "today's bill", or does not mention a specific amount, use the provided Context Active Memo / Day Total if it is > 0.
   - If no bill amount is provided and context is 0 or missing, assume a clean default subtotal of 1000 (currency '৳') and clearly state this in your replyMessage.
2. Participant Proportions / Unequal Splits:
   - "one owes 20% more": If 3 people and one owes 20% more than the others, assign relative weights: Person 1 = 1.2, Person 2 = 1.0, Person 3 = 1.0. Total weight = 3.2.
     Person 1 base share = (1.2 / 3.2) * subtotal.
     Person 2 base share = (1.0 / 3.2) * subtotal.
     Person 3 base share = (1.0 / 3.2) * subtotal.
   - Specific percentages (e.g. "Rahim 40%, Karim and Shuvo 30% each").
   - Specific items or custom amounts.
   - Equal splits ("among 4 people"): Each gets 1/N.
3. STRICT TAX / VAT PROPORTIONALITY:
   - If a tax / VAT rate is given (e.g. 5%, 7.5%, 15%) or tax amount is mentioned:
     * Total tax amount = (subtotal * taxPercent) / 100.
     * EACH PERSON'S TAX SHARE MUST BE STRICTLY PROPORTIONAL TO THEIR BASE SHARE:
       person.taxShare = (person.baseShare / subtotal) * totalTaxAmount.
     * NEVER divide tax equally if base shares are unequal, because tax is proportional to what each person consumed!
4. Tip / Service Charge Proportionality:
   - Proportional based on base shares: person.tipShare = (person.baseShare / subtotal) * totalTipAmount.
5. Exact Sum Reconciliation:
   - The sum of all participants' baseShare MUST equal subtotal.
   - The sum of all participants' taxShare MUST equal taxAmount.
   - Each participant's totalToPay = baseShare + taxShare + (tipShare || 0).
   - The sum of all participants' totalToPay MUST exactly equal grandTotal = subtotal + taxAmount + tipAmount.
   - Round numbers cleanly to 2 decimal places. Adjust any 0.01 rounding difference on the first participant so sum is exact.
6. Tone & Output:
   - Provide a warm, clear conversational explanation in replyMessage (matching the user's language - Bengali or English).
   - In title, provide a concise headline.
   - Default currency to '৳' unless dollar or other symbol is specified.
   - Suggest 2-3 actionable next tweaks.`;

      const candidateModels = ['gemini-3.6-flash', 'gemini-3.1-flash-lite', 'gemini-3.8-flash'];
      let response: any = null;
      let lastError: any = null;

      for (const model of candidateModels) {
        try {
          response = await ai.models.generateContent({
            model,
            contents: prompt,
            config: {
              systemInstruction,
              responseMimeType: 'application/json',
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  replyMessage: {
                    type: Type.STRING,
                    description: 'Friendly explanation of how the bill and tax were split.'
                  },
                  title: {
                    type: Type.STRING,
                    description: 'Short descriptive title of this split result.'
                  },
                  currency: {
                    type: Type.STRING,
                    description: 'Currency symbol (default ৳)'
                  },
                  subtotal: {
                    type: Type.NUMBER,
                    description: 'Total base bill amount before tax and tip.'
                  },
                  taxPercent: {
                    type: Type.NUMBER,
                    description: 'Tax or VAT rate percent, or 0.'
                  },
                  taxAmount: {
                    type: Type.NUMBER,
                    description: 'Total tax amount calculated.'
                  },
                  tipOrServicePercent: {
                    type: Type.NUMBER,
                    description: 'Tip or service charge percent, or 0.'
                  },
                  tipOrServiceAmount: {
                    type: Type.NUMBER,
                    description: 'Tip or service charge amount, or 0.'
                  },
                  grandTotal: {
                    type: Type.NUMBER,
                    description: 'Grand total = subtotal + taxAmount + tipOrServiceAmount.'
                  },
                  taxCalculationMethod: {
                    type: Type.STRING,
                    description: 'Proportional tax calculation explanation.'
                  },
                  participants: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        name: { type: Type.STRING, description: 'Participant name or title' },
                        baseShare: { type: Type.NUMBER, description: 'Base share before tax' },
                        taxShare: { type: Type.NUMBER, description: 'Proportional tax share' },
                        tipShare: { type: Type.NUMBER, description: 'Proportional tip share' },
                        totalToPay: { type: Type.NUMBER, description: 'Total to pay' },
                        percentageOfTotal: { type: Type.NUMBER, description: 'Percentage of total' },
                        shareRatioDescription: { type: Type.STRING, description: 'Ratio rule explanation' },
                        note: { type: Type.STRING, description: 'Optional extra note' }
                      },
                      required: ['id', 'name', 'baseShare', 'taxShare', 'totalToPay', 'percentageOfTotal']
                    }
                  },
                  suggestions: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING }
                  }
                },
                required: [
                  'replyMessage',
                  'title',
                  'currency',
                  'subtotal',
                  'taxPercent',
                  'taxAmount',
                  'grandTotal',
                  'participants'
                ]
              }
            }
          });
          if (response && response.text) {
            break;
          }
        } catch (mErr: any) {
          lastError = mErr;
          console.warn(`[Gemini Model ${model} failed]:`, mErr?.message || mErr);
        }
      }

      if (!response || !response.text) {
        throw lastError || new Error('All candidate AI models were unavailable or overloaded.');
      }

      const responseText = response.text?.trim() || '';
      const parsedData = JSON.parse(responseText);

      return res.json({
        success: true,
        data: parsedData,
        mode: 'gemini-ai'
      });
    } catch (err: any) {
      console.error('[Server Error /api/split-bill]:', err);
      // Fallback on error so the user never gets an unhandled crash
      const fallbackResult = calculateFallbackSplit(
        req.body?.message || '',
        req.body?.contextBillAmount
      );
      return res.json({
        success: true,
        data: fallbackResult,
        mode: 'fallback-on-error',
        notice: 'AI processing encountered a temporary delay; parsed using exact mathematical split engine.'
      });
    }
  });

  // Vite development middleware or static production files
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });

    // Provide a silent @vite/client in sandbox iframe to prevent websocket connection errors
    app.get('/@vite/client', async (req, res, next) => {
      try {
        const transformed = await vite.transformRequest('/@vite/client');
        if (!transformed || !transformed.code) {
          return next();
        }
        let code = transformed.code;
        // Replace websocket transport with a silent no-op transport
        code = code.replace(
          /const transport = normalizeModuleRunnerTransport\([\s\S]*?let willUnload = false;/m,
          `const transport = normalizeModuleRunnerTransport((() => ({
  async connect(handlers) {},
  async disconnect() {},
  send(data) {}
}))());
let willUnload = false;`
        );
        // Neutralize ping websocket retry loop cleanly without breaking function closure
        code = code.replace(
          /async function waitForSuccessfulPing[\s\S]*?function wait\(ms\)/m,
          'async function waitForSuccessfulPing() { return true; }\nfunction wait(ms)'
        );
        // Cleanse console logs and errors from [vite] prefix
        code = code
          .replace(/console\.error\(\s*(\`\[vite\]|'\[vite\]'|"\[vite\]")/g, 'console.debug($1')
          .replace(/console\.log\(\s*(\`\[vite\]|'\[vite\]'|"\[vite\]")/g, 'console.debug($1')
          .replace(/\[vite\]/g, '[dev]');

        res.setHeader('Content-Type', 'application/javascript');
        return res.send(code);
      } catch {
        return next();
      }
    });

    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
