export interface SplitterParticipant {
  id: string;
  name: string;
  baseShare: number;
  taxShare: number;
  tipShare?: number;
  totalToPay: number;
  percentageOfTotal: number;
  shareRatioDescription?: string;
  note?: string;
}

export interface SplitterResult {
  title: string;
  currency: string;
  subtotal: number;
  taxPercent: number;
  taxAmount: number;
  tipOrServicePercent?: number;
  tipOrServiceAmount?: number;
  grandTotal: number;
  taxCalculationMethod?: string;
  participants: SplitterParticipant[];
  suggestions?: string[];
  replyMessage: string;
}

export interface SplitterChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  timestamp: string;
  text: string;
  result?: SplitterResult;
  error?: string;
}

export interface SplitBillRequest {
  message: string;
  contextBillAmount?: number;
  history?: Array<{
    role: 'user' | 'model';
    text: string;
  }>;
}

export interface SplitBillResponse {
  success: boolean;
  data?: SplitterResult;
  error?: string;
}
