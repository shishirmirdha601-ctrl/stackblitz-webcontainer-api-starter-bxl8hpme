export interface Product {
  id: number;
  name: string;
  price: number;
  groupIndex: number;
  groupColor: string;
  categoryKey?: string;
  isCustom?: boolean;
}

export const PRODUCT_DATA: [string, number][] = [
  // Group 1 (Yellow)
  ["আইচবার ১২", 42],
  ["আইসবার ৪৫", 163],
  ["সিপ স্টার", 192],
  ["সিপ জেলি", 80],
  ["পিং পং ৪৫", 180],
  ["পিংপং কালার", 180],
  ["আইচপপ", 8],

  // Group 2 (Light Blue)
  ["পুডিং", 207],
  ["লিচু ৪৫", 180],
  ["লিচু পলি", 45],

  // Group 3 (Orange)
  ["চকোলেড ০৫", 250],
  ["চকোলেড ২৪", 192],
  ["চকোলেড ০০", 250],
  ["মিক্স বার", 160],
  ["লাভ বক্স", 163],
  ["চকোলেড ১৬", 183],
  ["কেরামেল বক্স", 80],
  ["বেলজিও কফি", 90],
  ["বেলজিও মিক্স", 90],
  ["বেলজিও স্ট্রবেরি", 90],
  ["জুম ০৫", 120],
  ["জুম ১০", 192],

  // Group 4 (Pink / Salmon)
  ["১৬০ সস", 55],
  ["২৫০ সস", 77],
  ["৫০০ সস", 129],
  ["০১ কেজি সস", 245],
  ["০২ কেজি সস", 470],
  ["৫ কেজি সস", 770],
  ["পাতা সস", 23],
  ["নাগা চিলি সস", 100],

  // Group 5 (Green)
  ["প্রাণ চাটনি", 4],
  ["জলপাই", 8],
  ["আম ভাগ আচার", 98],
  ["কালোজিরা", 0],

  // Group 6 (Cyan)
  ["জেমস ০৫", 95],
  ["ফিডার", 460],
  ["ডরিমেন", 240],
  ["চশমা", 300],

  // Group 7 (Peach / Orange)
  ["টোস্ট ১০", 8],
  ["টোস্ট বড়", 55],
  ["চিড়া ভাজা", 95],

  // Group 8 (Lavender / Purple)
  ["লাচ্ছা সেমাই", 40],
  ["বারমিসিলি সেমাই", 35]
];

export const GROUP_COLORS = [
  "#fff200", // Group 1
  "#8db3f0", // Group 2
  "#f6a000", // Group 3
  "#e95b63", // Group 4
  "#16f000", // Group 5
  "#25d6e8", // Group 6
  "#f3b15c", // Group 7
  "#c78acf"  // Group 8
];

export const GROUP_NAMES = [
  "গ্রুপ ১ (হলুদ)",
  "গ্রুপ ২ (হালকা নীল)",
  "গ্রুপ ৩ (কমলা)",
  "গ্রুপ ৪ (গোলাপি/লাল)",
  "গ্রুপ ৫ (সবুজ)",
  "গ্রুপ ৬ (আকাশি)",
  "গ্রুপ ৭ (পিচ/গেরুয়া)",
  "গ্রুপ ৮ (বেগুনি)",
];

export const GROUP_RANGES: [number, number][] = [
  [0, 7],   // Group 1: 0 - 6 (7 items)
  [7, 10],  // Group 2: 7 - 9 (3 items)
  [10, 22], // Group 3: 10 - 21 (12 items)
  [22, 30], // Group 4: 22 - 29 (8 items)
  [30, 34], // Group 5: 30 - 33 (4 items)
  [34, 38], // Group 6: 34 - 37 (4 items)
  [38, 41], // Group 7: 38 - 40 (3 items)
  [41, 43]  // Group 8: 41 - 42 (2 items)
];

export function getGroupIndexForProduct(index: number): number {
  for (let g = 0; g < GROUP_RANGES.length; g++) {
    const [start, end] = GROUP_RANGES[g];
    if (index >= start && index < end) {
      return g;
    }
  }
  return 0;
}

const DEFAULT_CATEGORY_BY_INDEX: Record<number, string> = {
  0: 'drinks',
  1: 'drinks',
  2: 'drinks',
  3: 'edible_gel',
  4: 'edible_gel',
  5: 'edible_gel',
  6: 'drinks',
  7: 'edible_gel',
  8: 'edible_gel',
  9: 'edible_gel',
  10: 'chocolate',
  11: 'chocolate',
  12: 'chocolate',
  13: 'chocolate',
  14: 'chocolate',
  15: 'chocolate',
  16: 'chocolate',
  17: 'chocolate',
  18: 'chocolate',
  19: 'chocolate',
  20: 'chocolate',
  21: 'chocolate',
  22: 'sauce',
  23: 'sauce',
  24: 'sauce',
  25: 'sauce',
  26: 'sauce',
  27: 'sauce',
  28: 'sauce',
  29: 'sauce',
  30: 'chutney',
  31: 'pickle',
  32: 'pickle',
  33: 'pickle',
  34: 'bean',
  35: 'bean',
  36: 'bean',
  37: 'bean',
  38: 'snacks',
  39: 'snacks',
  40: 'snacks',
  41: 'semai',
  42: 'semai',
};

export const DEFAULT_PRODUCTS: Product[] = PRODUCT_DATA.map(([name, price], index) => {
  const groupIndex = getGroupIndexForProduct(index);
  return {
    id: index,
    name,
    price,
    groupIndex,
    groupColor: GROUP_COLORS[groupIndex] || "#ffffff",
    categoryKey: DEFAULT_CATEGORY_BY_INDEX[index] || 'others',
    isCustom: false,
  };
});

export const PRODUCTS: Product[] = DEFAULT_PRODUCTS;

export const STORAGE_KEY_PRODUCTS = 'raju_products_catalog_v2';

export function getStoredProducts(): Product[] {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_PRODUCTS);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Validate items and ensure groupColor and categoryKey are set
        return parsed.map((p, idx) => ({
          ...p,
          id: typeof p.id === 'number' ? p.id : idx,
          name: p.name || `পণ্য ${idx + 1}`,
          price: typeof p.price === 'number' ? p.price : 0,
          groupIndex: typeof p.groupIndex === 'number' ? p.groupIndex : getGroupIndexForProduct(idx),
          groupColor: p.groupColor || GROUP_COLORS[p.groupIndex || 0] || '#ffffff',
          categoryKey: p.categoryKey || DEFAULT_CATEGORY_BY_INDEX[p.id] || 'others',
          isCustom: !!p.isCustom,
        }));
      }
    }
  } catch (err) {
    console.error('Error loading stored products', err);
  }
  return DEFAULT_PRODUCTS;
}

export function saveStoredProducts(products: Product[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_PRODUCTS, JSON.stringify(products));
  } catch (err) {
    console.error('Error saving products to storage', err);
  }
}

export function resetStoredProducts(): Product[] {
  try {
    localStorage.removeItem(STORAGE_KEY_PRODUCTS);
  } catch (err) {
    console.error('Error resetting products storage', err);
  }
  return DEFAULT_PRODUCTS;
}
