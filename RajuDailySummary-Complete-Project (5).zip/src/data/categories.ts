export interface CategoryDefinition {
  key: string;
  nameBn: string;
  nameEn: string;
  shortLabel: string;
  iconName: string;
  productIds: number[];
  color: string;
  borderColor: string;
  bgLight: string;
  darkBg: string;
  isSemai?: boolean;
  isOthers?: boolean;
}

export const CATEGORIES: CategoryDefinition[] = [
  {
    key: 'sauce',
    nameBn: 'সস',
    nameEn: 'Sauce',
    shortLabel: 'সস',
    iconName: 'Flame',
    productIds: [22, 23, 24, 25, 26, 27, 28, 29], // ১৬০ সস, ২৫০ সস, ৫০০ সস, ১ কেজি, ২ কেজি, ৫ কেজি, পাতা সস, নাগা চিলি সস
    color: '#e11d48', // rose-600
    borderColor: '#f43f5e',
    bgLight: '#fff1f2',
    darkBg: 'rgba(159, 18, 57, 0.25)',
  },
  {
    key: 'snacks',
    nameBn: 'স্ন্যাক্স',
    nameEn: 'Snacks',
    shortLabel: 'স্ন্যাক্স',
    iconName: 'Cookie',
    productIds: [38, 39, 40], // টোস্ট ১০, টোস্ট বড়, চিড়া ভাজা
    color: '#d97706', // amber-600
    borderColor: '#f59e0b',
    bgLight: '#fffbeb',
    darkBg: 'rgba(180, 83, 9, 0.25)',
  },
  {
    key: 'semai',
    nameBn: 'সেমাই',
    nameEn: 'Semai',
    shortLabel: 'সেমাই (পিস + ফুল)',
    iconName: 'UtensilsCrossed',
    productIds: [41, 42], // লাচ্ছা সেমাই, বারমিসিলি সেমাই
    color: '#9333ea', // purple-600
    borderColor: '#a855f7',
    bgLight: '#faf5ff',
    darkBg: 'rgba(107, 33, 168, 0.25)',
    isSemai: true,
  },
  {
    key: 'pickle',
    nameBn: 'আচার',
    nameEn: 'Pickle',
    shortLabel: 'আচার',
    iconName: 'Apple',
    productIds: [31, 32, 33], // জলপাই, আম ভাগ আচার, কালোজিরা
    color: '#15803d', // green-700
    borderColor: '#22c55e',
    bgLight: '#f0fdf4',
    darkBg: 'rgba(21, 128, 61, 0.25)',
  },
  {
    key: 'chutney',
    nameBn: 'চাটনি',
    nameEn: 'Chutney',
    shortLabel: 'চাটনি',
    iconName: 'Sparkles',
    productIds: [30], // প্রাণ চাটনি
    color: '#059669', // emerald-600
    borderColor: '#10b981',
    bgLight: '#ecfdf5',
    darkBg: 'rgba(5, 150, 105, 0.25)',
  },
  {
    key: 'chocolate',
    nameBn: 'চকোলেড',
    nameEn: 'Chocolate',
    shortLabel: 'চকোলেড',
    iconName: 'Candy',
    productIds: [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21], // চকোলেড ০৫, ২৪, ০০, মিক্স বার, লাভ বক্স, চকোলেড ১৬, কেরামেল বক্স, বেলজিও কফি, মিক্স, স্ট্রবেরি, জুম ০৫, ১০
    color: '#ea580c', // orange-600
    borderColor: '#f97316',
    bgLight: '#fff7ed',
    darkBg: 'rgba(194, 65, 12, 0.25)',
  },
  {
    key: 'edible_gel',
    nameBn: 'এডিবল জেল',
    nameEn: 'Edible Gel',
    shortLabel: 'এডিবল জেল',
    iconName: 'CupSoda',
    productIds: [3, 4, 5, 7, 8, 9], // সিপ জেলি, পিং পং ৪৫, পিংপং কালার, পুডিং, লিচু ৪৫, লিচু পলি
    color: '#0284c7', // sky-600
    borderColor: '#38bdf8',
    bgLight: '#f0f9ff',
    darkBg: 'rgba(2, 132, 199, 0.25)',
  },
  {
    key: 'drinks',
    nameBn: 'ড্রিংকস',
    nameEn: 'Drinks',
    shortLabel: 'ড্রিংকস',
    iconName: 'GlassWater',
    productIds: [0, 1, 2, 6], // আইচবার ১২, আইসবার ৪৫, সিপ স্টার, আইচপপ
    color: '#0891b2', // cyan-600
    borderColor: '#06b6d4',
    bgLight: '#ecfeff',
    darkBg: 'rgba(8, 145, 178, 0.25)',
  },
  {
    key: 'bean',
    nameBn: 'বিন / খেলনা',
    nameEn: 'Bean / Gems',
    shortLabel: 'বিন (জেমস/খেলনা)',
    iconName: 'Boxes',
    productIds: [34, 35, 36, 37], // জেমস ০৫, ফিডার, ডরিমেন, চশমা
    color: '#0d9488', // teal-600
    borderColor: '#14b8a6',
    bgLight: '#f0fdfa',
    darkBg: 'rgba(13, 148, 136, 0.25)',
  },
  {
    key: 'others',
    nameBn: 'অন্যান্য',
    nameEn: 'Others',
    shortLabel: 'অন্যান্য (লিস্টের বাইরে)',
    iconName: 'PackagePlus',
    productIds: [], // Items not in the standard list
    color: '#4f46e5', // indigo-600
    borderColor: '#6366f1',
    bgLight: '#eef2ff',
    darkBg: 'rgba(79, 70, 229, 0.25)',
    isOthers: true,
  },
];
