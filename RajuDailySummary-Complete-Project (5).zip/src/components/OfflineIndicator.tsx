import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div
      id="offline-indicator-banner"
      className="fixed bottom-20 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-600 px-3 py-2 text-xs font-semibold text-white shadow-xl animate-bounce"
    >
      <WifiOff className="w-4 h-4" />
      <span>অফলাইন মোড — ক্যাশ করা ডাটা ব্যবহার হচ্ছে (Web APK Ready)</span>
    </div>
  );
};
