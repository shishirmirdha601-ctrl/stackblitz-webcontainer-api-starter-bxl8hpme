import React, { useState } from 'react';
import {
  Bell,
  BellRing,
  BellOff,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Send,
  Loader2,
  FileDown,
  FileSpreadsheet,
  Smartphone,
} from 'lucide-react';
import { useDailyNotification } from '../hooks/useDailyNotification';

interface DailyNotificationSettingsProps {
  onDownloadPDF?: () => void;
  onDownloadCSV?: () => void;
  onShowToast?: (message: string) => void;
}

const PRESET_TIMES = [
  { label: 'সন্ধ্যা ৭:৩০', value: '19:30' },
  { label: 'রাত ৮:০০', value: '20:00' },
  { label: 'রাত ৯:০০', value: '21:00' },
  { label: 'রাত ১০:০০', value: '22:00' },
];

export const DailyNotificationSettings: React.FC<DailyNotificationSettingsProps> = ({
  onDownloadPDF,
  onDownloadCSV,
  onShowToast,
}) => {
  const {
    config,
    permission,
    isTesting,
    updateReminderTime,
    toggleNotifications,
    sendTestNotification,
  } = useDailyNotification();

  const [isToggling, setIsToggling] = useState(false);

  const handleToggle = async () => {
    setIsToggling(true);
    const result = await toggleNotifications();
    setIsToggling(false);
    if (onShowToast) {
      onShowToast(result.message);
    }
  };

  const handleTestNotification = async () => {
    const result = await sendTestNotification();
    if (onShowToast) {
      onShowToast(result.message);
    }
  };

  return (
    <div
      id="daily-notification-settings-card"
      className="p-3.5 sm:p-4 rounded-xl border border-amber-300 dark:border-amber-800/80 bg-amber-50/70 dark:bg-amber-950/30 space-y-3.5 transition-all shadow-xs"
    >
      {/* Header with Title & Main Toggle */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2.5">
          <div
            className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold border transition-colors ${
              config.enabled
                ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-xs'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-500 dark:text-slate-400 border-slate-300 dark:border-slate-700'
            }`}
          >
            {config.enabled ? (
              <BellRing className="w-5 h-5 animate-wiggle" />
            ) : (
              <BellOff className="w-5 h-5" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm sm:text-base font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
                <span>দৈনিক সামারি নোটিফিকেশন</span>
                <span className="text-[10px] bg-amber-400 text-slate-950 font-black px-1.5 py-0.5 rounded-full uppercase tracking-wider">
                  PWA API
                </span>
              </h4>
            </div>
            <p className="text-[11px] sm:text-xs text-slate-600 dark:text-slate-400 leading-tight">
              দিনশেষে মেমো ও বিক্রয় হিসাব সম্পন্ন হলে PDF ও Excel/CSV রিপোর্ট ডাউনলোডের রিমাইন্ডার
            </p>
          </div>
        </div>

        {/* Toggle Button */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            id="daily-notification-toggle-btn"
            onClick={handleToggle}
            disabled={isToggling}
            role="switch"
            aria-checked={config.enabled}
            className={`relative inline-flex h-7 w-14 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-amber-500 focus:ring-offset-2 ${
              config.enabled ? 'bg-amber-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
            title={config.enabled ? 'নোটিফিকেশন বন্ধ করতে ক্লিক করুন' : 'নোটিফিকেশন চালু করতে ক্লিক করুন'}
          >
            <span className="sr-only">Toggle Daily Summary Notification</span>
            <span
              className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                config.enabled ? 'translate-x-7' : 'translate-x-0'
              }`}
            />
          </button>
          <span
            className={`text-xs font-black px-2 py-0.5 rounded-md ${
              config.enabled
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
            }`}
          >
            {config.enabled ? 'চালু (ON)' : 'বন্ধ (OFF)'}
          </span>
        </div>
      </div>

      {/* Expanded Controls when Notification is Enabled */}
      {config.enabled && (
        <div className="space-y-3 pt-1 border-t border-amber-200/80 dark:border-amber-900/50 animate-fade-in">
          {/* Time Picker & Preset Buttons */}
          <div className="bg-white/80 dark:bg-slate-900/80 p-3 rounded-xl border border-amber-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <label
                htmlFor="notification-time-picker"
                className="text-xs font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5"
              >
                <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>রিমাইন্ডার আসার সময় নির্ধারণ করুন:</span>
              </label>

              <div className="flex items-center gap-1.5">
                <input
                  id="notification-time-picker"
                  type="time"
                  value={config.reminderTime}
                  onChange={(e) => updateReminderTime(e.target.value || '20:00')}
                  className="bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1 text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-amber-500 cursor-pointer"
                />
              </div>
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex items-center gap-1.5 flex-wrap pt-0.5">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                দ্রুত পছন্দ:
              </span>
              {PRESET_TIMES.map((preset) => {
                const isSelected = config.reminderTime === preset.value;
                return (
                  <button
                    key={preset.value}
                    type="button"
                    onClick={() => updateReminderTime(preset.value)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {preset.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Permission Status Indicator */}
          <div className="flex items-center justify-between flex-wrap gap-2 text-xs p-2.5 rounded-lg bg-white/70 dark:bg-slate-900/60 border border-amber-200/70 dark:border-slate-800">
            <div className="flex items-center gap-2">
              {permission === 'granted' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
              ) : permission === 'denied' ? (
                <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0" />
              ) : (
                <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              )}
              <div className="text-[11px] sm:text-xs">
                {permission === 'granted' ? (
                  <span className="text-emerald-800 dark:text-emerald-300 font-semibold">
                    ব্রাউজার নোটিফিকেশন পারমিশন <strong>অনুমোদিত (Granted)</strong> — নির্ধারিত সময়ে ফোন ও পিসিতে অ্যালার্ট আসবে।
                  </span>
                ) : permission === 'denied' ? (
                  <span className="text-red-800 dark:text-red-300 font-semibold">
                    ব্রাউজারে নোটিফিকেশন <strong>ব্লক করা আছে</strong>। সাইট সেটিংসে গিয়ে Allow করুন।
                  </span>
                ) : (
                  <span className="text-slate-700 dark:text-slate-300 font-medium">
                    ব্রাউজারের সিস্টেম নোটিফিকেশন চালু রাখতে নিচের টেস্ট বাটনে ক্লিক করে অনুমোদন দিন।
                  </span>
                )}
              </div>
            </div>

            {/* Test Notification Button */}
            <button
              type="button"
              id="test-daily-notification-btn"
              onClick={handleTestNotification}
              disabled={isTesting}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white shadow-xs transition cursor-pointer active:scale-95 disabled:opacity-60 shrink-0"
              title="ডিভাইসে নোটিফিকেশন পরীক্ষা করে দেখুন"
            >
              {isTesting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <Send className="w-3.5 h-3.5" />
              )}
              <span>{isTesting ? 'পাঠানো হচ্ছে...' : 'টেস্ট নোটিফিকেশন পাঠান'}</span>
            </button>
          </div>

          {/* Quick Action Buttons for PDF and CSV */}
          {(onDownloadPDF || onDownloadCSV) && (
            <div className="flex items-center gap-2 flex-wrap pt-0.5">
              <span className="text-[11px] font-bold text-slate-600 dark:text-slate-400">
                রিপোর্টে দ্রুত অ্যাক্সেস:
              </span>
              {onDownloadPDF && (
                <button
                  type="button"
                  onClick={onDownloadPDF}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-rose-100 hover:bg-rose-200 dark:bg-rose-950/60 dark:hover:bg-rose-900/70 text-rose-800 dark:text-rose-300 border border-rose-200 dark:border-rose-800 transition cursor-pointer"
                >
                  <FileDown className="w-3 h-3" />
                  <span>PDF রিপোর্ট</span>
                </button>
              )}
              {onDownloadCSV && (
                <button
                  type="button"
                  onClick={onDownloadCSV}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-bold bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/60 dark:hover:bg-emerald-900/70 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 transition cursor-pointer"
                >
                  <FileSpreadsheet className="w-3 h-3" />
                  <span>Excel / CSV</span>
                </button>
              )}
            </div>
          )}

          {/* PWA & Mobile Tip */}
          <div className="flex items-start gap-2 p-2 rounded-lg bg-amber-100/60 dark:bg-slate-900/40 border border-amber-200/50 dark:border-slate-800 text-[11px] text-amber-900 dark:text-amber-300/90 leading-tight">
            <Smartphone className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
            <span>
              <strong>PWA / Web APK সুবিধা:</strong> অ্যাপটি ফোনে ইনস্টল (Add to Home Screen) করা থাকলে ব্রাউজার বন্ধ থাকলেও নির্ধারিত সময়ে সরাসরি ডিভাইসের নোটিফিকেশন সেন্টারে মেমো সামারির অ্যালার্ট চলে আসবে।
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
