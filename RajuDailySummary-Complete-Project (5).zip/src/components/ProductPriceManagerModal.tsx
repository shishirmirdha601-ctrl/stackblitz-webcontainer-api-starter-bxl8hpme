import React, { useState, useMemo } from 'react';
import { Product, GROUP_COLORS, GROUP_NAMES } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { 
  X, 
  Plus, 
  Save, 
  Search, 
  Trash2, 
  RotateCcw, 
  Tag, 
  Edit3, 
  Check, 
  AlertTriangle,
  PackagePlus,
  Sliders,
  CheckCircle2,
  Sparkles
} from 'lucide-react';

interface ProductPriceManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onUpdateProducts: (newProducts: Product[], message?: string) => void;
  onResetProducts: () => void;
  onToast: (message: string) => void;
}

export const ProductPriceManagerModal: React.FC<ProductPriceManagerModalProps> = ({
  isOpen,
  onClose,
  products,
  onUpdateProducts,
  onResetProducts,
  onToast,
}) => {
  const [activeTab, setActiveTab] = useState<'prices' | 'add' | 'reset'>('prices');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGroupFilter, setSelectedGroupFilter] = useState<number | 'all'>('all');

  // Editing state for bulk/single price & name changes
  const [editedProducts, setEditedProducts] = useState<Product[]>(() => products);

  // Sync editedProducts whenever modal opens or products prop changes
  React.useEffect(() => {
    setEditedProducts(products);
  }, [products, isOpen]);

  // Add Product Form State
  const [newName, setNewName] = useState('');
  const [newPrice, setNewPrice] = useState('');
  const [newGroupIndex, setNewGroupIndex] = useState<number>(0);
  const [newCategoryKey, setNewCategoryKey] = useState<string>('others');

  const handlePriceChange = (id: number, valStr: string) => {
    const val = parseFloat(valStr) || 0;
    setEditedProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, price: Math.max(0, val) } : p))
    );
  };

  const handleQuickDelta = (id: number, delta: number) => {
    setEditedProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, price: Math.max(0, p.price + delta) } : p))
    );
  };

  const handleNameChange = (id: number, val: string) => {
    setEditedProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, name: val } : p))
    );
  };

  const handleGroupChange = (id: number, gIdx: number) => {
    setEditedProducts((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              groupIndex: gIdx,
              groupColor: GROUP_COLORS[gIdx] || '#ffffff',
            }
          : p
      )
    );
  };

  const handleCategoryChange = (id: number, catKey: string) => {
    setEditedProducts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, categoryKey: catKey } : p))
    );
  };

  // Save single product change
  const handleSaveSingle = (id: number) => {
    const updated = editedProducts.find((p) => p.id === id);
    if (!updated) return;
    const nextProducts = products.map((p) => (p.id === id ? updated : p));
    onUpdateProducts(nextProducts, `"${updated.name}" এর প্রাইজ ও তথ্য আপডেট হয়েছে (৳ ${updated.price} টাকা)!`);
  };

  // Save all modified products
  const handleSaveAll = () => {
    onUpdateProducts(editedProducts, 'সব পণ্যের নাম ও প্রাইজ সফলভাবে আপডেট এবং সেভ করা হয়েছে!');
    onClose();
  };

  // Delete product (only if custom or permitted)
  const handleDeleteProduct = (id: number, name: string) => {
    if (!window.confirm(`আপনি কি নিশ্চিত যে "${name}" পণ্যটি তালিকা থেকে মুছে ফেলতে চান?`)) {
      return;
    }
    const next = products.filter((p) => p.id !== id);
    // Re-index cleanly so IDs remain contiguous
    const reindexed = next.map((p, idx) => ({ ...p, id: idx }));
    onUpdateProducts(reindexed, `"${name}" পণ্যটি সফলভাবে মুছে ফেলা হয়েছে!`);
  };

  // Add new product
  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newName.trim();
    if (!cleanName) {
      onToast('অনুগ্রহ করে পণ্যের সঠিক নাম লিখুন');
      return;
    }
    const priceNum = parseFloat(newPrice);
    if (isNaN(priceNum) || priceNum < 0) {
      onToast('অনুগ্রহ করে পণ্যের বৈধ মূল্য (Price) নির্ধারণ করুন');
      return;
    }

    const newId = products.length;
    const newProductItem: Product = {
      id: newId,
      name: cleanName,
      price: priceNum,
      groupIndex: newGroupIndex,
      groupColor: GROUP_COLORS[newGroupIndex] || '#ffffff',
      categoryKey: newCategoryKey,
      isCustom: true,
    };

    const next = [...products, newProductItem];
    onUpdateProducts(next, `নতুন পণ্য "${cleanName}" (৳ ${priceNum} টাকা) সফলভাবে যোগ করা হয়েছে!`);
    setNewName('');
    setNewPrice('');
    setActiveTab('prices');
  };

  // Filtered view for edit tab
  const filteredList = useMemo(() => {
    return editedProducts.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.price.toString().includes(searchQuery);
      const matchGroup =
        selectedGroupFilter === 'all' ? true : p.groupIndex === selectedGroupFilter;
      return matchSearch && matchGroup;
    });
  }, [editedProducts, searchQuery, selectedGroupFilter]);

  // Check if any product was modified
  const hasChanges = useMemo(() => {
    return JSON.stringify(products) !== JSON.stringify(editedProducts);
  }, [products, editedProducts]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-2 sm:p-4 overflow-y-auto animate-fadeIn"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] my-auto">
        {/* Header */}
        <div className="bg-slate-900 text-white p-4 sm:p-5 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center font-bold">
              <Tag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
                <span>প্রোডাক্ট ও প্রাইজ ম্যানেজার</span>
                <span className="text-xs bg-amber-400/20 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-400/30">
                  {products.length} টি পণ্য
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                নতুন পণ্য তৈরি করুন, যেকোনো পণ্যের নাম ও প্রাইজ (দর) আপডেট করুন
              </p>
            </div>
          </div>
          <button
            type="button"
            id="close-product-manager-btn"
            onClick={onClose}
            className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 active:bg-rose-600/40 text-rose-300 border border-rose-500/40 text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95 shadow-xs shrink-0"
            title="উইন্ডো বন্ধ করুন"
          >
            <X className="w-4 h-4 text-rose-400" />
            <span>বন্ধ করুন</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-950/60 px-3 pt-2 gap-2 shrink-0 overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('prices')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-t border-x cursor-pointer ${
              activeTab === 'prices'
                ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 border-slate-200 dark:border-slate-800 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border-transparent'
            }`}
          >
            <Edit3 className="w-4 h-4" />
            <span>প্রাইজ ও তথ্য আপডেট</span>
            <span className="text-[10px] bg-slate-200 dark:bg-slate-800 px-1.5 py-0.2 rounded-full">
              {products.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('add')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-t border-x cursor-pointer ${
              activeTab === 'add'
                ? 'bg-white dark:bg-slate-900 text-emerald-600 dark:text-emerald-400 border-slate-200 dark:border-slate-800 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border-transparent'
            }`}
          >
            <PackagePlus className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>+ নতুন প্রোডাক্ট যোগ</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('reset')}
            className={`flex items-center gap-1.5 px-4 py-2.5 rounded-t-xl text-xs sm:text-sm font-bold transition border-t border-x ml-auto cursor-pointer ${
              activeTab === 'reset'
                ? 'bg-white dark:bg-slate-900 text-red-600 dark:text-red-400 border-slate-200 dark:border-slate-800 shadow-xs'
                : 'text-slate-500 hover:text-red-600 border-transparent'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>রিসেট অপশন</span>
          </button>
        </div>

        {/* TAB 1: প্রাইজ ও তথ্য আপডেট */}
        {activeTab === 'prices' && (
          <div className="flex flex-col flex-1 overflow-hidden p-3 sm:p-5 space-y-3">
            {/* Search and Filters */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2.5 shrink-0 bg-slate-50 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200 dark:border-slate-700/80">
              <div className="relative flex-1">
                <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="পণ্যের নাম বা প্রাইজ লিখে দ্রুত খুঁজুন..."
                  className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              {/* Group Filter */}
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-semibold text-slate-500 shrink-0">গ্রুপ:</span>
                <select
                  value={selectedGroupFilter}
                  onChange={(e) =>
                    setSelectedGroupFilter(
                      e.target.value === 'all' ? 'all' : parseInt(e.target.value, 10)
                    )
                  }
                  className="text-xs py-1.5 px-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white font-medium"
                >
                  <option value="all">সব গ্রুপ (১ - ৮)</option>
                  {GROUP_NAMES.map((name, idx) => (
                    <option key={idx} value={idx}>
                      {name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Save all changes button if modified */}
              {hasChanges && (
                <button
                  type="button"
                  onClick={handleSaveAll}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs px-3.5 py-1.5 rounded-lg flex items-center justify-center gap-1.5 shadow-sm transition active:scale-95 cursor-pointer shrink-0 animate-pulse"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>সব সেভ করুন</span>
                </button>
              )}
            </div>

            {/* Notification hint */}
            <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between px-1">
              <span>💡 যেকোনো পণ্যের দাম বা নাম পরিবর্তন করে "আপডেট" চাপুন অথবা কুইক বাটন ব্যবহার করুন।</span>
              <span className="font-bold text-slate-700 dark:text-slate-300">{filteredList.length} টি পণ্য প্রদর্শিত</span>
            </div>

            {/* Product list */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {filteredList.map((p) => {
                const isCustom = !!p.isCustom;
                const original = products.find((orig) => orig.id === p.id);
                const isModified =
                  original &&
                  (original.price !== p.price ||
                    original.name !== p.name ||
                    original.groupIndex !== p.groupIndex ||
                    original.categoryKey !== p.categoryKey);

                return (
                  <div
                    key={p.id}
                    className={`p-2.5 sm:p-3 rounded-xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                      isModified
                        ? 'bg-amber-50 dark:bg-amber-950/30 border-amber-300 dark:border-amber-700/80 shadow-xs'
                        : 'bg-white dark:bg-slate-900/90 border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {/* Left: ID, Group badge & Name */}
                    <div className="flex items-center gap-2.5 flex-1 w-full sm:w-auto">
                      <div
                        style={{ backgroundColor: p.groupColor }}
                        className="w-7 h-7 rounded-lg text-slate-950 font-black text-xs flex items-center justify-center shrink-0 border border-black/10 shadow-2xs"
                        title={`গ্রুপ ${p.groupIndex + 1}`}
                      >
                        {p.id + 1}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <input
                            type="text"
                            value={p.name}
                            onChange={(e) => handleNameChange(p.id, e.target.value)}
                            className="text-xs sm:text-sm font-extrabold text-slate-900 dark:text-white bg-transparent border-b border-dashed border-slate-300 dark:border-slate-700 hover:border-blue-500 focus:border-blue-600 focus:outline-none px-1 py-0.5 min-w-[140px]"
                            title="পণ্যের নাম এডিট করুন"
                          />
                          {isCustom && (
                            <span className="text-[10px] bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-300 px-1.5 py-0.2 rounded-full font-bold">
                              নতুন যুক্ত
                            </span>
                          )}
                          <span className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-1.5 py-0.2 rounded font-medium">
                            G{p.groupIndex + 1}
                          </span>
                        </div>

                        {/* Category badge / selector */}
                        <div className="mt-1 flex items-center gap-2 text-[11px] text-slate-500">
                          <span>ক্যাটাগরি:</span>
                          <select
                            value={p.categoryKey || 'others'}
                            onChange={(e) => handleCategoryChange(p.id, e.target.value)}
                            className="bg-transparent text-[11px] font-semibold text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 rounded px-1.5 py-0.5 cursor-pointer"
                          >
                            {CATEGORIES.map((c) => (
                              <option key={c.key} value={c.key}>
                                {c.nameBn} ({c.nameEn})
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Right: Price editor + Quick adjustments + Save button */}
                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end flex-wrap">
                      {/* Quick Adjust Buttons */}
                      <div className="hidden sm:flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => handleQuickDelta(p.id, -5)}
                          className="px-1.5 py-1 text-[10px] font-bold rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition cursor-pointer"
                          title="৫ টাকা কমান"
                        >
                          -৫
                        </button>
                        <button
                          type="button"
                          onClick={() => handleQuickDelta(p.id, 5)}
                          className="px-1.5 py-1 text-[10px] font-bold rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 transition cursor-pointer"
                          title="৫ টাকা বাড়ান"
                        >
                          +৫
                        </button>
                      </div>

                      {/* Price input */}
                      <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-xl border border-slate-200 dark:border-slate-700">
                        <span className="text-xs font-black text-red-600 dark:text-red-400">৳</span>
                        <input
                          type="number"
                          min="0"
                          step="1"
                          value={p.price}
                          onChange={(e) => handlePriceChange(p.id, e.target.value)}
                          className="w-20 font-black text-sm text-slate-900 dark:text-white bg-transparent text-right focus:outline-none"
                          title="একক মূল্য / দর (টাকা)"
                        />
                        <span className="text-[10px] font-bold text-slate-500">টাকা</span>
                      </div>

                      {/* Update button */}
                      <button
                        type="button"
                        onClick={() => handleSaveSingle(p.id)}
                        disabled={!isModified}
                        className={`text-xs font-black px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition cursor-pointer ${
                          isModified
                            ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-2xs active:scale-95'
                            : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
                        }`}
                        title="এই পণ্যের প্রাইজ আপডেট করুন"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>আপডেট</span>
                      </button>

                      {/* Delete button (for custom added items or if user wants to remove) */}
                      {isCustom && (
                        <button
                          type="button"
                          onClick={() => handleDeleteProduct(p.id, p.name)}
                          className="p-1.5 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-950/50 transition cursor-pointer"
                          title="পণ্যটি মুছে ফেলুন"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}

              {filteredList.length === 0 && (
                <div className="text-center py-12 text-slate-400">
                  <p className="text-sm font-semibold">কোনো পণ্য পাওয়া যায়নি</p>
                  <p className="text-xs mt-1">অন্য কোনো নাম বা ফিল্টার চেষ্টা করুন</p>
                </div>
              )}
            </div>

            {/* Bottom bar */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <span className="text-xs text-slate-500">
                পরিবর্তন করার পর স্বয়ংক্রিয়ভাবে লোকাল স্টোরেজে সংরক্ষিত হয়।
              </span>
              <button
                type="button"
                onClick={handleSaveAll}
                className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs px-4 py-2 rounded-xl flex items-center gap-1.5 transition active:scale-95 cursor-pointer shadow-sm"
              >
                <Save className="w-4 h-4" />
                <span>সম্পূর্ণ সেভ করে বন্ধ করুন</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB 2: নতুন প্রোডাক্ট যোগ করুন */}
        {activeTab === 'add' && (
          <form
            onSubmit={handleCreateProduct}
            className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4"
          >
            <div className="bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 p-3.5 rounded-xl flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold shrink-0 mt-0.5">
                <Sparkles className="w-4 h-4" />
              </div>
              <div className="text-xs text-emerald-900 dark:text-emerald-200 space-y-0.5">
                <h4 className="font-black text-sm">নতুন প্রোডাক্ট অন্তর্ভুক্ত করুন</h4>
                <p>
                  নতুন পণ্য যোগ করলে এটি সরাসরি শিটের তালিকায় সবার নিচে যুক্ত হবে এবং মেমো ও
                  জমার সাথে স্বাভাবিক পণ্যের মতো হিসাব হবে।
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Product Name */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <span>পণ্যের নাম (Product Name) *</span>
                </label>
                <input
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="যেমন: ম্যাংগো ড্রিংকস ২৫০, নতুন চকোলেট..."
                  className="w-full px-3.5 py-2.5 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {/* Product Price */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                  <span>একক দর / মূল্য (টাকা) *</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                    ৳
                  </span>
                  <input
                    type="number"
                    required
                    min="0"
                    step="1"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    placeholder="যেমন: ১২০"
                    className="w-full pl-8 pr-3.5 py-2.5 text-xs sm:text-sm bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Group Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                গ্রুপ নির্বাচন করুন (গ্রুপ অনুযায়ী টেবিলে ব্যাকগ্রাউন্ড কালার হবে):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {GROUP_NAMES.map((gName, idx) => {
                  const isSelected = newGroupIndex === idx;
                  const color = GROUP_COLORS[idx];
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setNewGroupIndex(idx)}
                      style={{
                        backgroundColor: color,
                        borderColor: isSelected ? '#000000' : 'transparent',
                      }}
                      className={`p-2 rounded-xl text-xs font-black text-slate-950 border-2 transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'ring-2 ring-emerald-500 shadow-md scale-[1.02]'
                          : 'opacity-85 hover:opacity-100'
                      }`}
                    >
                      <span>{gName}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-slate-950" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Category Selector */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">
                ক্যাটাগরি নির্বাচন (ক্যাটাগরি সামারি ও এক্সপোর্টের জন্য):
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                {CATEGORIES.map((cat) => {
                  const isSelected = newCategoryKey === cat.key;
                  return (
                    <button
                      key={cat.key}
                      type="button"
                      onClick={() => setNewCategoryKey(cat.key)}
                      className={`p-2 rounded-xl border text-xs font-bold flex flex-col items-start transition cursor-pointer ${
                        isSelected
                          ? 'bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-500 ring-2 ring-blue-400/40 shadow-xs'
                          : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:border-slate-400'
                      }`}
                    >
                      <div className="flex items-center justify-between w-full">
                        <span>{cat.nameBn}</span>
                        {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                      </div>
                      <span className="text-[10px] text-slate-400 font-normal">
                        {cat.nameEn}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setActiveTab('prices')}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition cursor-pointer"
              >
                বাতিল
              </button>
              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs sm:text-sm px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-md transition active:scale-95 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>নতুন প্রোডাক্ট যুক্ত করুন</span>
              </button>
            </div>
          </form>
        )}

        {/* TAB 3: রিসেট অপশন */}
        {activeTab === 'reset' && (
          <div className="p-5 sm:p-6 space-y-4">
            <div className="bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/60 p-4 rounded-xl flex items-start gap-3.5">
              <AlertTriangle className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
              <div className="text-xs text-red-900 dark:text-red-200 space-y-1">
                <h4 className="font-extrabold text-sm text-red-800 dark:text-red-300">
                  ডিফল্ট ৪৩টি পণ্যের তালিকায় রিসেট
                </h4>
                <p>
                  যদি আপনি পূর্বে কোনো পণ্যের নাম বা প্রাইজ ভুল করে পরিবর্তন করে থাকেন এবং মূল
                  ফ্যাক্টরি ডিফল্ট ৪৩টি পণ্যের তালিকায় ফিরে যেতে চান, তাহলে এই বাটনটি ব্যবহার করুন।
                </p>
                <p className="font-bold text-red-700 dark:text-red-400">
                  সতর্কতা: এতে কাস্টম যুক্ত করা পণ্য মুছে যাবে এবং পূর্বের মূল প্রাইজ ফিরে আসবে।
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end pt-4">
              <button
                type="button"
                onClick={() => {
                  if (
                    window.confirm(
                      'আপনি কি নিশ্চিত যে মূল ৪৩টি পণ্যের ডিফল্ট প্রাইজ ও তালিকায় রিসেট করতে চান?'
                    )
                  ) {
                    onResetProducts();
                    onClose();
                  }
                }}
                className="bg-red-600 hover:bg-red-700 text-white font-extrabold text-xs sm:text-sm px-5 py-2.5 rounded-xl flex items-center gap-2 shadow-sm transition active:scale-95 cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>ডিফল্ট তালিকায় রিসেট করুন</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
