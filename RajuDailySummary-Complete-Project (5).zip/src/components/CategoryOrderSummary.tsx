import React, { useState, useMemo } from 'react';
import { Product } from '../data/products';
import { UnlistedItem } from '../types';
import { CATEGORIES, CategoryDefinition } from '../data/categories';
import {
  Layers,
  Copy,
  Check,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  Settings2,
  PackagePlus,
  Flame,
  Cookie,
  UtensilsCrossed,
  Apple,
  Sparkles,
  Candy,
  CupSoda,
  GlassWater,
  Boxes,
  HelpCircle,
  X,
  Share2
} from 'lucide-react';

interface CategoryOrderSummaryProps {
  products: Product[];
  daySum: number[];
  unlistedItems?: UnlistedItem[];
  currentDate: string;
  onAddUnlistedItem: (item: Omit<UnlistedItem, 'id' | 'timestamp'>) => void;
  onDeleteUnlistedItem: (id: string) => void;
  onToast: (msg: string) => void;
}

export const CategoryOrderSummary: React.FC<CategoryOrderSummaryProps> = ({
  products,
  daySum,
  unlistedItems = [],
  currentDate,
  onAddUnlistedItem,
  onDeleteUnlistedItem,
  onToast,
}) => {
  const [copied, setCopied] = useState<boolean>(false);
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [showAddOtherModal, setShowAddOtherModal] = useState<boolean>(false);
  const [showSemaiConfigModal, setShowSemaiConfigModal] = useState<boolean>(false);

  // Semai pack size setting (how many pieces equal 1 full carton / কেস / ফুল)
  const [semaiPackSize, setSemaiPackSize] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('semai_pack_size');
      return saved ? Math.max(1, parseInt(saved, 10)) : 24;
    } catch {
      return 24;
    }
  });

  // Form state for adding unlisted items (Others)
  const [newItemName, setNewItemName] = useState<string>('');
  const [newItemQty, setNewItemQty] = useState<string>('');
  const [newItemPrice, setNewItemPrice] = useState<string>('');
  const [newItemNote, setNewItemNote] = useState<string>('');

  const handleSetSemaiPackSize = (size: number) => {
    const valid = Math.max(1, size);
    setSemaiPackSize(valid);
    try {
      localStorage.setItem('semai_pack_size', valid.toString());
    } catch {
      // ignore
    }
    setShowSemaiConfigModal(false);
    onToast(`সেমাই ১ ফুল = ${valid} পিস নির্ধারণ করা হয়েছে।`);
  };

  const toggleCategoryExpand = (key: string) => {
    setExpandedCategories((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  // Helper icon renderer
  const renderCategoryIcon = (iconName: string, className: string = 'w-5 h-5') => {
    switch (iconName) {
      case 'Flame':
        return <Flame className={className} />;
      case 'Cookie':
        return <Cookie className={className} />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className={className} />;
      case 'Apple':
        return <Apple className={className} />;
      case 'Sparkles':
        return <Sparkles className={className} />;
      case 'Candy':
        return <Candy className={className} />;
      case 'CupSoda':
        return <CupSoda className={className} />;
      case 'GlassWater':
        return <GlassWater className={className} />;
      case 'Boxes':
        return <Boxes className={className} />;
      case 'PackagePlus':
        return <PackagePlus className={className} />;
      default:
        return <Layers className={className} />;
    }
  };

  // Calculate detailed category summaries
  const categoryStats = useMemo(() => {
    return CATEGORIES.map((cat) => {
      if (cat.isOthers) {
        const totalPieces = unlistedItems.reduce((acc, item) => acc + (item.quantity || 0), 0);
        const totalAmount = unlistedItems.reduce((acc, item) => acc + (item.quantity || 0) * (item.price || 0), 0);
        return {
          cat,
          totalPieces,
          totalAmount,
          itemCount: unlistedItems.length,
          items: unlistedItems.map((u) => ({
            id: u.id,
            name: u.name,
            price: u.price,
            quantity: u.quantity,
            amount: u.quantity * u.price,
            note: u.note,
            isUnlisted: true,
          })),
        };
      }

      // Category matching items (both predefined productIds and any newly added products matching categoryKey)
      const matchingProducts = products.filter(
        (p) => (p.categoryKey && p.categoryKey === cat.key) || cat.productIds.includes(p.id)
      );

      const items = matchingProducts.map((product) => {
        const quantity = daySum[product.id] || 0;
        const price = product?.price || 0;
        return {
          id: product.id.toString(),
          name: product?.name || `পণ্য ${product.id + 1}`,
          price,
          quantity,
          amount: quantity * price,
          isUnlisted: false,
        };
      });

      const activeItems = items.filter((it) => it.quantity > 0);
      const totalPieces = items.reduce((acc, it) => acc + it.quantity, 0);
      const totalAmount = items.reduce((acc, it) => acc + it.amount, 0);

      // Special Semai calculation (Pieces + Full / ফুল)
      let semaiFoolCount = 0;
      let semaiRemainder = 0;
      let semaiFoolText = '';

      if (cat.isSemai) {
        semaiFoolCount = Math.floor(totalPieces / semaiPackSize);
        semaiRemainder = totalPieces % semaiPackSize;
        if (totalPieces === 0) {
          semaiFoolText = '০ ফুল';
        } else if (semaiFoolCount > 0 && semaiRemainder > 0) {
          semaiFoolText = `${semaiFoolCount} ফুল + ${semaiRemainder} পিস`;
        } else if (semaiFoolCount > 0) {
          semaiFoolText = `${semaiFoolCount} ফুল`;
        } else {
          semaiFoolText = `${semaiRemainder} পিস খুচরা`;
        }
      }

      return {
        cat,
        totalPieces,
        totalAmount,
        itemCount: items.length,
        activeItemsCount: activeItems.length,
        items,
        semaiFoolCount,
        semaiRemainder,
        semaiFoolText,
      };
    });
  }, [products, daySum, unlistedItems, semaiPackSize]);

  // Grand totals across all 10 categories
  const grandTotalPieces = useMemo(() => {
    return categoryStats.reduce((acc, item) => acc + item.totalPieces, 0);
  }, [categoryStats]);

  const grandTotalAmount = useMemo(() => {
    return categoryStats.reduce((acc, item) => acc + item.totalAmount, 0);
  }, [categoryStats]);

  // Generate share text for WhatsApp/Messaging
  const generateCategoryShareText = () => {
    const lines: string[] = [];
    lines.push(`📊 ক্যাটাগরিভিত্তিক অর্ডার ও বিক্রয় সামারি`);
    lines.push(`📅 তারিখ: ${currentDate}`);
    lines.push(`----------------------------------------`);

    categoryStats.forEach((c) => {
      const piecesStr = `${c.totalPieces.toLocaleString()} পিস`;
      const amountStr = `৳ ${c.totalAmount.toLocaleString()}`;

      if (c.cat.isSemai) {
        lines.push(
          `🍜 ${c.cat.nameBn} (${c.cat.nameEn}): ${piecesStr} (${c.semaiFoolText}) | ${amountStr}`
        );
      } else {
        lines.push(
          `${c.cat.nameBn} (${c.cat.nameEn}): ${piecesStr} | ${amountStr}`
        );
      }
    });

    lines.push(`----------------------------------------`);
    lines.push(`⭐ সর্বমোট অর্ডার: ${grandTotalPieces.toLocaleString()} পিস | মোট টাকা: ৳ ${grandTotalAmount.toLocaleString()}`);

    return lines.join('\n');
  };

  const handleCopy = async () => {
    const text = generateCategoryShareText();
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(text);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = text;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      onToast('ক্যাটাগরি সামারি টেক্সট ক্লিপবোর্ডে কপি করা হয়েছে!');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onToast('কপি করা সম্ভব হয়নি।');
    }
  };

  // Handle adding unlisted item (Others)
  const handleSubmitUnlistedItem = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newItemName.trim();
    const qty = parseInt(newItemQty, 10);
    const price = parseFloat(newItemPrice);

    if (!name) {
      onToast('অনুগ্রহ করে পণ্যের নাম লিখুন!');
      return;
    }
    if (isNaN(qty) || qty <= 0) {
      onToast('সঠিক পিস বা পরিমাণ লিখুন!');
      return;
    }
    const finalPrice = isNaN(price) || price < 0 ? 0 : price;

    onAddUnlistedItem({
      name,
      quantity: qty,
      price: finalPrice,
      note: newItemNote.trim() || undefined,
    });

    setNewItemName('');
    setNewItemQty('');
    setNewItemPrice('');
    setNewItemNote('');
    setShowAddOtherModal(false);
    onToast(`"${name}" (${qty} পিস) অন্যান্য তালিকায় যোগ করা হয়েছে!`);
  };

  return (
    <section
      id="category-order-summary-section"
      aria-label="Category Order Summary"
      className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-5 shadow-sm border-2 border-indigo-200 dark:border-indigo-900/60 space-y-4 transition-colors"
    >
      {/* Section Header with Overall Badges & Action Buttons */}
      <div className="flex items-center justify-between flex-wrap gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-xs">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <span>ক্যাটাগরি অনুযায়ী অর্ডার সামারি</span>
                <span className="text-[11px] font-extrabold text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 px-2 py-0.5 rounded-full">
                  ১০টি ক্যাটাগরি
                </span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                সস, স্ন্যাক্স, সেমাই (পিস+ফুল), আচার, চাটনি, চকোলেড, এডিবল জেল, ড্রিংকস, বিন ও অন্যান্য আইটেম
              </p>
            </div>
          </div>
        </div>

        {/* Action Controls: Semai Pack config, Add unlisted, Copy Summary */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Semai Packaging Info Pill */}
          <button
            type="button"
            onClick={() => setShowSemaiConfigModal(true)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-purple-50 dark:bg-purple-950/50 hover:bg-purple-100 dark:hover:bg-purple-900/60 text-purple-900 dark:text-purple-300 border border-purple-200 dark:border-purple-800 transition active:scale-95 cursor-pointer shadow-2xs"
            title="সেমাই প্রতি ফুলে পিস সংখ্যা নির্ধারণ করুন (১ ফুল = কত পিস)"
          >
            <Settings2 className="w-3.5 h-3.5 text-purple-600 dark:text-purple-400" />
            <span>সেমাই: ১ ফুল = <strong>{semaiPackSize}</strong> পিস</span>
          </button>

          {/* Add Unlisted Item Button */}
          <button
            type="button"
            id="add-unlisted-item-btn"
            onClick={() => setShowAddOtherModal(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-blue-50 dark:bg-blue-950/50 hover:bg-blue-100 dark:hover:bg-blue-900/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800 transition active:scale-95 cursor-pointer shadow-2xs"
            title="মূল তালিকার বাইরের কোনো পণ্য আসলে এখানে সরাসরি যোগ করুন"
          >
            <PackagePlus className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>+ লিস্টের বাইরের পণ্য (Others)</span>
          </button>

          {/* Copy Category Summary */}
          <button
            type="button"
            id="copy-category-summary-btn"
            onClick={handleCopy}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black transition active:scale-95 cursor-pointer shadow-xs ${
              copied
                ? 'bg-emerald-600 text-white'
                : 'bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white'
            }`}
            title="ক্যাটাগরি অনুযায়ী মোট পিস ও টাকার হিসাব হোয়াটসঅ্যাপ বা মেসেজে পাঠাতে কপি করুন"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4 text-emerald-200" />
                <span>কপি হয়েছে</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>ক্যাটাগরি সামারি কপি</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Grand Total Summary Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200 dark:border-slate-700/80">
        <div className="space-y-0.5">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            আজকের মোট অর্ডার
          </div>
          <div className="text-base sm:text-xl font-black text-slate-900 dark:text-slate-100">
            {grandTotalPieces.toLocaleString()} <span className="text-xs font-semibold text-slate-500">পিস</span>
          </div>
        </div>

        <div className="space-y-0.5">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            মোট অর্ডার মূল্য
          </div>
          <div className="text-base sm:text-xl font-black text-rose-600 dark:text-rose-400">
            ৳ {grandTotalAmount.toLocaleString()}
          </div>
        </div>

        <div className="space-y-0.5">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            সক্রিয় ক্যাটাগরি
          </div>
          <div className="text-base sm:text-xl font-black text-indigo-600 dark:text-indigo-400">
            {categoryStats.filter((c) => c.totalPieces > 0).length} / {CATEGORIES.length}{' '}
            <span className="text-xs font-semibold text-slate-500">টি</span>
          </div>
        </div>

        <div className="space-y-0.5">
          <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
            সেমাই অর্ডার
          </div>
          <div className="text-sm sm:text-base font-black text-purple-700 dark:text-purple-300 truncate">
            {categoryStats.find((c) => c.cat.isSemai)?.totalPieces || 0} পিস{' '}
            <span className="text-xs font-bold text-purple-600 dark:text-purple-400">
              ({categoryStats.find((c) => c.cat.isSemai)?.semaiFoolText})
            </span>
          </div>
        </div>
      </div>

      {/* Grid of 10 Category Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
        {categoryStats.map((item) => {
          const { cat, totalPieces, totalAmount, items, semaiFoolText } = item;
          const isExpanded = !!expandedCategories[cat.key];
          const hasOrders = totalPieces > 0;

          return (
            <div
              key={cat.key}
              id={`category-card-${cat.key}`}
              className={`rounded-xl border transition-all duration-200 flex flex-col justify-between ${
                hasOrders
                  ? 'bg-white dark:bg-slate-800/90 shadow-xs hover:shadow-md border-slate-300 dark:border-slate-700'
                  : 'bg-slate-50/70 dark:bg-slate-900/40 border-slate-200/80 dark:border-slate-800/80 opacity-90'
              }`}
              style={{
                borderTopColor: cat.color,
                borderTopWidth: '4px',
              }}
            >
              <div className="p-3">
                {/* Category Header */}
                <div className="flex items-center justify-between gap-1.5 pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="p-1.5 rounded-lg text-white shrink-0 shadow-2xs"
                      style={{ backgroundColor: cat.color }}
                    >
                      {renderCategoryIcon(cat.iconName, 'w-4 h-4')}
                    </span>
                    <div className="min-w-0">
                      <div className="font-black text-sm text-slate-900 dark:text-slate-100 truncate">
                        {cat.nameBn}
                      </div>
                      <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 truncate">
                        {cat.nameEn}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => toggleCategoryExpand(cat.key)}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded hover:bg-slate-100 dark:hover:bg-slate-700 transition cursor-pointer"
                    title={isExpanded ? 'বিবরণ লুকান' : 'বিস্তারিত দেখুন'}
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>
                </div>

                {/* Key Metrics: Pieces & Taka */}
                <div className="mt-2.5 space-y-1">
                  <div className="flex items-baseline justify-between gap-1">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      মোট বিক্রয়:
                    </span>
                    <span
                      className={`text-base font-black ${
                        hasOrders
                          ? 'text-slate-950 dark:text-white'
                          : 'text-slate-400 dark:text-slate-500'
                      }`}
                    >
                      {totalPieces.toLocaleString()} পিস
                    </span>
                  </div>

                  {/* Semai Specific Full / ফুল Display */}
                  {cat.isSemai && (
                    <div className="bg-purple-50 dark:bg-purple-950/60 text-purple-900 dark:text-purple-300 border border-purple-200 dark:border-purple-800 px-2 py-1 rounded-md text-[11px] font-extrabold flex items-center justify-between">
                      <span>ফুল কার্টুন:</span>
                      <span className="font-black text-purple-700 dark:text-purple-300">
                        {semaiFoolText}
                      </span>
                    </div>
                  )}

                  {/* Order Amount (টাকা) */}
                  <div className="flex items-baseline justify-between gap-1 pt-1 border-t border-dashed border-slate-200 dark:border-slate-800">
                    <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                      মোট টাকা:
                    </span>
                    <span className="font-black text-rose-600 dark:text-rose-400 text-sm sm:text-base">
                      ৳ {totalAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Expandable item details list */}
              {isExpanded && (
                <div className="px-3 pb-3 pt-1 border-t border-slate-100 dark:border-slate-800 text-xs bg-slate-50/50 dark:bg-slate-900/30 rounded-b-xl">
                  <div className="font-bold text-[11px] text-slate-500 dark:text-slate-400 mb-1.5 flex items-center justify-between">
                    <span>আইটেম তালিকা ({items.length} টি)</span>
                    {cat.isOthers && (
                      <button
                        type="button"
                        onClick={() => setShowAddOtherModal(true)}
                        className="text-blue-600 dark:text-blue-400 hover:underline font-bold text-[10px] cursor-pointer"
                      >
                        + নতুন যোগ
                      </button>
                    )}
                  </div>

                  <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                    {items.length === 0 ? (
                      <div className="text-[11px] text-slate-400 dark:text-slate-500 py-1 text-center">
                        কোনো পণ্য নেই
                      </div>
                    ) : (
                      items.map((it) => (
                        <div
                          key={it.id}
                          className={`flex items-center justify-between py-1 px-1.5 rounded text-[11px] ${
                            it.quantity > 0
                              ? 'bg-white dark:bg-slate-800 font-medium text-slate-900 dark:text-slate-100 shadow-2xs'
                              : 'text-slate-500 dark:text-slate-400'
                          }`}
                        >
                          <div className="truncate flex-1 pr-1">
                            <span className="font-bold">{it.name}</span>
                            {it.isUnlisted && it.note && (
                              <span className="ml-1 text-[10px] text-slate-500 dark:text-slate-400">
                                ({it.note})
                              </span>
                            )}
                          </div>
                          <div className="text-right shrink-0 flex items-center gap-1.5">
                            <span className="font-black">{it.quantity} পিস</span>
                            {it.quantity > 0 && (
                              <span className="text-[10px] font-bold text-rose-600 dark:text-rose-400">
                                ৳{it.amount.toLocaleString()}
                              </span>
                            )}
                            {it.isUnlisted && (
                              <button
                                type="button"
                                onClick={() => onDeleteUnlistedItem(it.id)}
                                className="text-red-500 hover:text-red-700 p-0.5 rounded cursor-pointer"
                                title="মুছে ফেলুন"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}

              {/* Bottom Card Footer Toggle */}
              <div className="px-3 py-1.5 bg-slate-50 dark:bg-slate-850 border-t border-slate-100 dark:border-slate-800 rounded-b-xl flex items-center justify-between text-[11px]">
                <span className="text-slate-500 dark:text-slate-400 font-medium">
                  {cat.isOthers
                    ? `${unlistedItems.length} টি আনলিস্টেড পণ্য`
                    : `${items.filter((i) => i.quantity > 0).length}/${items.length} পণ্যে বিক্রয়`}
                </span>
                <button
                  type="button"
                  onClick={() => toggleCategoryExpand(cat.key)}
                  className="text-slate-700 dark:text-slate-300 hover:text-indigo-600 dark:hover:text-indigo-400 font-bold transition cursor-pointer"
                >
                  {isExpanded ? 'সংক্ষেপ' : 'বিস্তারিত'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Add Unlisted Item (Others / লিস্টের বাইরে) */}
      {showAddOtherModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-5 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-blue-100 dark:bg-blue-950/70 text-blue-600 dark:text-blue-400">
                  <PackagePlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-slate-100 text-base">
                    লিস্টের বাইরের পণ্য যোগ করুন (Others)
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    যে পণ্যগুলো মূল ৪৩টি তালিকায় নেই
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowAddOtherModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitUnlistedItem} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  পণ্যের নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="যেমন: কাজু বাদাম, ঘি, বিশেষ মসলা..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    পরিমাণ (পিস) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="1"
                    required
                    value={newItemQty}
                    onChange={(e) => setNewItemQty(e.target.value)}
                    placeholder="পিস"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    একক দর (টাকা)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={newItemPrice}
                    onChange={(e) => setNewItemPrice(e.target.value)}
                    placeholder="দর"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600 font-bold text-rose-600 dark:text-rose-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  মেমো নম্বর বা নোট (ঐচ্ছিক)
                </label>
                <input
                  type="text"
                  value={newItemNote}
                  onChange={(e) => setNewItemNote(e.target.value)}
                  placeholder="যেমন: মেমো-০৫ বা কাস্টমারের নাম"
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAddOtherModal(false)}
                  className="px-4 py-2 rounded-lg text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg text-xs font-black bg-blue-600 hover:bg-blue-700 text-white transition active:scale-95 shadow-sm cursor-pointer"
                >
                  তালিকায় যোগ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Semai Packaging Configuration (ফুল সেটিং) */}
      {showSemaiConfigModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-purple-100 dark:bg-purple-950/70 text-purple-600 dark:text-purple-400">
                  <UtensilsCrossed className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-slate-100 text-base">
                    সেমাই ফুল কার্টুন সেটিং
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    প্রতি ১ ফুল (কার্টুন/কেস) = কত পিস সেমাই
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowSemaiConfigModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3">
              <p className="text-xs text-slate-600 dark:text-slate-300">
                সাধারণত সেমাইয়ের ক্ষেত্রে ২৪ পিস বা ১২ পিসকে ১ ফুল হিসাব করা হয়। আপনার সুবিধাজনক সংখ্যা নির্বাচন করুন:
              </p>

              {/* Quick Preset Buttons */}
              <div className="grid grid-cols-4 gap-2">
                {[12, 20, 24, 36].map((size) => (
                  <button
                    key={size}
                    type="button"
                    onClick={() => handleSetSemaiPackSize(size)}
                    className={`py-2 rounded-lg text-xs font-black border transition cursor-pointer ${
                      semaiPackSize === size
                        ? 'bg-purple-600 text-white border-purple-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 hover:border-purple-400'
                    }`}
                  >
                    {size} পিস
                  </button>
                ))}
              </div>

              {/* Custom input */}
              <div className="pt-2">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  কাস্টম সংখ্যা লিখুন:
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    min="1"
                    defaultValue={semaiPackSize}
                    id="custom-semai-pack-input"
                    className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-sm focus:outline-none focus:ring-2 focus:ring-purple-600 font-black"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const input = document.getElementById(
                        'custom-semai-pack-input'
                      ) as HTMLInputElement;
                      if (input && input.value) {
                        handleSetSemaiPackSize(parseInt(input.value, 10));
                      }
                    }}
                    className="px-3 py-1.5 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700 cursor-pointer"
                  >
                    সেভ করুন
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
