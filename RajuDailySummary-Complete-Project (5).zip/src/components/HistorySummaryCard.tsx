import React from 'react';
import {
  Receipt,
  Package,
  TrendingUp,
  Search,
  Filter,
  X,
  RotateCcw,
  Sparkles
} from 'lucide-react';
import { AnimatedCounter } from './AnimatedCounter';

export interface HistorySummaryCardProps {
  totalEntries: number;
  totalItemsSold: number;
  totalRevenue: number;
  totalUnfilteredEntries: number;
  searchQuery: string;
  onSearchChange: (value: string) => void;
  productFilter: string;
  onProductFilterChange: (value: string) => void;
  productOptions: string[];
  onClearFilters: () => void;
}

export const HistorySummaryCard: React.FC<HistorySummaryCardProps> = ({
  totalEntries,
  totalItemsSold,
  totalRevenue,
  totalUnfilteredEntries,
  searchQuery,
  onSearchChange,
  productFilter,
  onProductFilterChange,
  productOptions,
  onClearFilters,
}) => {
  const isFiltered = searchQuery.trim() !== '' || productFilter !== 'all';

  return (
    <div
      id="history-summary-card"
      className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 dark:border-slate-800 space-y-4 transition-colors"
    >
      {/* Header & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 flex items-center justify-center shrink-0">
            <Receipt className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black text-slate-900 dark:text-slate-100">
                হিস্ট্রি সারসংক্ষেপ (Summary Overview)
              </h3>
              {isFiltered ? (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200 border border-blue-200 dark:border-blue-700">
                  ফিল্টার অনুযায়ী
                </span>
              ) : (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                  আজকের সামগ্রিক
                </span>
              )}
            </div>
            <p className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              {isFiltered
                ? `মোট ${totalUnfilteredEntries} টির মধ্যে ফিল্টারকৃত ${totalEntries} টি এন্ট্রির হিসাব দেখানো হচ্ছে`
                : 'নির্বাচিত তারিখের সকল মেমো ও বিক্রয় এন্ট্রির সম্মিলিত যোগফল'}
            </p>
          </div>
        </div>

        {/* Filter Controls Row */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Search Box */}
          <div className="relative flex-1 sm:w-56 min-w-[160px]">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              id="history-search-input"
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="পণ্য বা মেমো নম্বর খুঁজুন..."
              className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-xl pl-8 pr-7 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-blue-500/40 focus:bg-white dark:focus:bg-slate-800 transition"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-full cursor-pointer"
                title="সার্চ মুছুন"
              >
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Product Dropdown Filter */}
          <div className="relative min-w-[130px]">
            <Filter className="w-3 h-3 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <select
              id="history-product-filter-select"
              value={productFilter}
              onChange={(e) => onProductFilterChange(e.target.value)}
              aria-label="পণ্য অনুযায়ী ফিল্টার করুন"
              className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 rounded-xl pl-7 pr-6 py-1.5 text-xs font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500/40 cursor-pointer appearance-none"
            >
              <option value="all">সব পণ্য ({productOptions.length} টি)</option>
              {productOptions.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          {/* Clear Filters Button */}
          {isFiltered && (
            <button
              id="history-clear-filter-btn"
              type="button"
              onClick={onClearFilters}
              className="px-2.5 py-1.5 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-800/60 transition cursor-pointer flex items-center gap-1 shrink-0"
              title="সকল ফিল্টার রিসেট করুন"
            >
              <RotateCcw className="w-3 h-3" />
              <span className="hidden sm:inline">রিসেট</span>
            </button>
          )}
        </div>
      </div>

      {/* 3 Summary Metric Blocks Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {/* Metric 1: Total Number of Entries */}
        <div
          id="history-stat-entries"
          className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center gap-3.5 transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-blue-100 dark:bg-blue-900/50 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-700/60 flex items-center justify-center shrink-0 shadow-2xs">
            <Receipt className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              মোট এন্ট্রি সংখ্যা
            </div>
            <div className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-baseline gap-1 mt-0.5">
              <AnimatedCounter value={totalEntries} />
              <span className="text-xs font-bold text-slate-500 dark:text-slate-400">টি</span>
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
              {isFiltered ? 'ফিল্টারে পাওয়া রেকর্ড' : 'আজকের মোট রেকর্ড'}
            </div>
          </div>
        </div>

        {/* Metric 2: Total Items Sold */}
        <div
          id="history-stat-items-sold"
          className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center gap-3.5 transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-sky-100 dark:bg-sky-900/50 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-700/60 flex items-center justify-center shrink-0 shadow-2xs">
            <Package className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              মোট বিক্রীত পণ্য
            </div>
            <div className="text-xl sm:text-2xl font-black text-sky-700 dark:text-sky-400 tracking-tight flex items-baseline gap-1 mt-0.5">
              <AnimatedCounter value={totalItemsSold} />
              <span className="text-xs font-bold text-sky-600 dark:text-sky-400">পিস</span>
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
              {isFiltered ? 'ফিল্টার অনুযায়ী পণ্যের সংখ্যা' : 'মোট বিক্রয়কৃত আইটেম'}
            </div>
          </div>
        </div>

        {/* Metric 3: Total Revenue */}
        <div
          id="history-stat-revenue"
          className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 flex items-center gap-3.5 transition-all"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-700/60 flex items-center justify-center shrink-0 shadow-2xs">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wide">
              মোট রাজস্ব / বিক্রয়
            </div>
            <div className="text-xl sm:text-2xl font-black text-emerald-600 dark:text-emerald-400 tracking-tight flex items-baseline gap-1 mt-0.5">
              <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">৳</span>
              <AnimatedCounter value={totalRevenue} />
            </div>
            <div className="text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
              {isFiltered ? 'ফিল্টারকৃত মোট বিক্রয় মূল্য' : 'আজকের সর্বমোট বিক্রয়'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
