import React, { useState, useRef } from 'react';
import { Product } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { ProductArtwork } from './ProductArtwork';
import { SmartNameMatcherModal } from './SmartNameMatcherModal';
import { matchFileToProduct, FileMatchResult } from '../utils/nameMatcher';
import {
  ProductImageMap,
  saveSingleProductImage,
  compressImageFile,
  saveStoredProductImages,
  exportAllPhotosJSON,
  requestPersistentStorage
} from '../utils/productImages';
import {
  Search,
  Camera,
  Plus,
  Minus,
  Check,
  UploadCloud,
  FileText,
  Flame,
  Cookie,
  UtensilsCrossed,
  Apple,
  Sparkles,
  Candy,
  CupSoda,
  GlassWater,
  Boxes,
  PackagePlus,
  ArrowRight,
  Layers,
  X,
  RotateCcw,
  CheckCircle2,
  Image as ImageIcon,
  Smartphone,
  ExternalLink,
  Download,
  Upload
} from 'lucide-react';

interface ProductCatalogViewProps {
  products: Product[];
  inputs: number[];
  onInputChange: (index: number, value: number) => void;
  onOpenSummaryApp: () => void;
  onAddAll?: () => void;
  currentDate: string;
  imageMap: ProductImageMap;
  onUpdateImageMap: (updated: ProductImageMap) => void;
  showToast: (msg: string) => void;
}

export const ProductCatalogView: React.FC<ProductCatalogViewProps> = ({
  products,
  inputs,
  onInputChange,
  onOpenSummaryApp,
  onAddAll,
  currentDate,
  imageMap,
  onUpdateImageMap,
  showToast
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isBatchModalOpen, setIsBatchModalOpen] = useState<boolean>(false);
  const [isMatcherModalOpen, setIsMatcherModalOpen] = useState<boolean>(false);
  const [pendingMatches, setPendingMatches] = useState<FileMatchResult[]>([]);
  const [activeUploadProductId, setActiveUploadProductId] = useState<number | null>(null);
  const [isProcessingImage, setIsProcessingImage] = useState<boolean>(false);
  const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const batchFileInputRef = useRef<HTMLInputElement>(null);
  const photosRestoreInputRef = useRef<HTMLInputElement>(null);

  // Calculate totals
  const totalSelectedItems = inputs.reduce((acc, qty) => acc + (qty > 0 ? qty : 0), 0);
  const totalSelectedKinds = inputs.reduce((acc, qty) => acc + (qty > 0 ? 1 : 0), 0);

  // Category Icon Resolver
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Flame': return <Flame className="w-4 h-4" />;
      case 'Cookie': return <Cookie className="w-4 h-4" />;
      case 'UtensilsCrossed': return <UtensilsCrossed className="w-4 h-4" />;
      case 'Apple': return <Apple className="w-4 h-4" />;
      case 'Sparkles': return <Sparkles className="w-4 h-4" />;
      case 'Candy': return <Candy className="w-4 h-4" />;
      case 'CupSoda': return <CupSoda className="w-4 h-4" />;
      case 'GlassWater': return <GlassWater className="w-4 h-4" />;
      case 'Boxes': return <Boxes className="w-4 h-4" />;
      default: return <PackagePlus className="w-4 h-4" />;
    }
  };

  // Filter products by selected category and search query
  const filteredProducts = products.filter((p, index) => {
    // Category check
    if (selectedCategory !== 'all') {
      const catDef = CATEGORIES.find((c) => c.key === selectedCategory);
      if (catDef) {
        if (catDef.isOthers) {
          if (p.categoryKey !== 'others' && catDef.productIds.includes(p.id)) return false;
        } else if (!catDef.productIds.includes(p.id) && p.categoryKey !== selectedCategory) {
          return false;
        }
      }
    }

    // Search query check
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchName = p.name.toLowerCase().includes(q);
      const matchPrice = p.price.toString().includes(q);
      const matchIndex = (index + 1).toString() === q;
      return matchName || matchPrice || matchIndex;
    }

    return true;
  });

  // Handle single photo upload for a product
  const handleSinglePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0 || activeUploadProductId === null) return;

    try {
      setIsProcessingImage(true);
      const file = files[0];
      const base64 = await compressImageFile(file, 480, 480, 0.85);
      const updated = saveSingleProductImage(activeUploadProductId, base64);
      onUpdateImageMap(updated);
      showToast(`'${products.find((p) => p.id === activeUploadProductId)?.name || 'পণ্য'}' এর ছবি সফলভাবে যুক্ত হয়েছে!`);
    } catch (err) {
      console.error(err);
      showToast('ছবি প্রসেসিংয়ে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    } finally {
      setIsProcessingImage(false);
      setActiveUploadProductId(null);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  // Process incoming files through the Name-Based Matcher
  const processIncomingFilesForMatching = (fileList: File[]) => {
    if (fileList.length === 0) return;

    // Filter only image files
    const imageFiles = fileList.filter((f) => f.type.startsWith('image/') || /\.(jpe?g|png|webp|gif)$/i.test(f.name));
    if (imageFiles.length === 0) {
      showToast('অনুগ্রহ করে সঠিক ছবির ফাইল নির্বাচন করুন।');
      return;
    }

    const assignedIds = new Set<number>();
    const results: FileMatchResult[] = [];

    // Sort files to preserve order if named with numbers
    const sortedFiles = [...imageFiles].sort((a, b) =>
      a.name.localeCompare(b.name, undefined, { numeric: true })
    );

    sortedFiles.forEach((file, index) => {
      const match = matchFileToProduct(file, index, products, assignedIds);
      assignedIds.add(match.matchedProductId);
      results.push(match);
    });

    setPendingMatches(results);
    setIsBatchModalOpen(false);
    setIsMatcherModalOpen(true);
  };

  // Handle batch photo uploads
  const handleBatchPhotosSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    processIncomingFilesForMatching(Array.from(files) as File[]);
    if (batchFileInputRef.current) batchFileInputRef.current.value = '';
  };

  // Drag & drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDraggingOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processIncomingFilesForMatching(Array.from(e.dataTransfer.files) as File[]);
    }
  };

  // Reset all uploaded photos
  const handleClearAllPhotos = () => {
    if (window.confirm('আপনি কি নিশ্চিত যে সকল প্রোডাক্টের কাস্টম ছবি মুছে ডিফল্ট আর্টওয়ার্কে ফিরে যেতে চান?')) {
      saveStoredProductImages({});
      onUpdateImageMap({});
      showToast('সকল কাস্টম ছবি মুছে ফেলা হয়েছে।');
      setIsBatchModalOpen(false);
    }
  };

  // 1-Click Permanent Save to device storage & export download
  const handlePermanentSaveAndDownload = () => {
    requestPersistentStorage();
    saveStoredProductImages(imageMap);
    exportAllPhotosJSON(imageMap, products);
    const count = Object.keys(imageMap).length;
    showToast(`সব ছবি (${count} টি) ডিভাইসের স্টোরেজে পার্মানেন্টলি সেভ ও ব্যাকআপ ফাইল ডাউনলোড হয়েছে!`);
  };

  // Restore photos from backup JSON file
  const handleRestorePhotos = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        const imagesToRestore = parsed.images || parsed.imageMap;
        if (imagesToRestore && typeof imagesToRestore === 'object') {
          const count = Object.keys(imagesToRestore).length;
          const merged = { ...imageMap, ...imagesToRestore };
          onUpdateImageMap(merged);
          saveStoredProductImages(merged);
          requestPersistentStorage();
          showToast(`${count} টি পণ্যের ছবি সফলভাবে রিস্টোর ও পার্মানেন্টলি সেভ হয়েছে!`);
        } else {
          showToast('ফাইলে কোনো ছবির তথ্য পাওয়া যায়নি।');
        }
      } catch (err) {
        showToast('ফাইল পড়তে সমস্যা হয়েছে: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Render Category Visual Themed Artwork for Fallback
  const renderFallbackIllustration = (p: Product) => {
    const catKey = p.categoryKey || 'drinks';
    switch (catKey) {
      case 'sauce':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 p-2 select-none">
            <Flame className="w-12 h-12 stroke-[1.5] animate-pulse" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">সস ভ্যারাইটি</span>
          </div>
        );
      case 'chocolate':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400 p-2 select-none">
            <Candy className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">চকলেট বার</span>
          </div>
        );
      case 'edible_gel':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 p-2 select-none">
            <CupSoda className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">এডিবল জেলি</span>
          </div>
        );
      case 'drinks':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-cyan-50 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-400 p-2 select-none">
            <GlassWater className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">আইসবার / ড্রিংক</span>
          </div>
        );
      case 'pickle':
      case 'chutney':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 p-2 select-none">
            <Apple className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">আচার ও চাটনি</span>
          </div>
        );
      case 'snacks':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 p-2 select-none">
            <Cookie className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">টোস্ট ও স্ন্যাক্স</span>
          </div>
        );
      case 'semai':
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-purple-50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400 p-2 select-none">
            <UtensilsCrossed className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">লাচ্ছা ও সেমাই</span>
          </div>
        );
      default:
        return (
          <div className="w-full h-full flex flex-col items-center justify-center bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 p-2 select-none">
            <Boxes className="w-12 h-12 stroke-[1.5]" />
            <span className="text-[10px] font-bold mt-1 tracking-wider uppercase">পণ্য সামগ্রী</span>
          </div>
        );
    }
  };

  return (
    <div
      className="w-full pb-36 animate-in fade-in duration-300 relative"
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {/* Drag & Drop Visual Indicator */}
      {isDraggingOver && (
        <div className="fixed inset-0 z-50 bg-emerald-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-white border-4 border-dashed border-emerald-400 m-4 rounded-3xl pointer-events-none animate-in zoom-in-95">
          <Sparkles className="w-16 h-16 text-amber-300 mb-3 animate-bounce" />
          <h2 className="text-2xl font-black text-center mb-1">
            ছবিগুলো এখানে ছেড়ে দিন!
          </h2>
          <p className="text-sm text-emerald-200 text-center max-w-md">
            ফাইলের নাম ও নম্বর অনুযায়ী স্বয়ংক্রিয়ভাবে সঠিক পণ্যের সাথে ছবিগুলো মিলে যাবে।
          </p>
        </div>
      )}

      {/* Hidden single photo input */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleSinglePhotoSelect}
        accept="image/*"
        className="hidden"
      />

      {/* Hidden batch photo input */}
      <input
        type="file"
        ref={batchFileInputRef}
        onChange={handleBatchPhotosSelect}
        accept="image/*"
        multiple
        className="hidden"
      />

      {/* Hidden photo backup restore input */}
      <input
        type="file"
        ref={photosRestoreInputRef}
        onChange={handleRestorePhotos}
        accept=".json"
        className="hidden"
      />

      {/* TOP HERO BAR: Direct Gateway to Summary App ("Amar ey samari apk") */}
      <section className="bg-gradient-to-r from-slate-900 via-blue-950 to-indigo-950 text-white rounded-2xl p-4 sm:p-5 mb-5 shadow-lg border border-slate-700/60 relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-10 -mt-10 w-44 h-44 bg-blue-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="bg-amber-400 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                পণ্য ক্যাটালগ
              </span>
              <span className="text-xs text-slate-300 font-medium">
                তারিখ: <strong className="text-amber-300">{currentDate}</strong>
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2">
              ছবিসহ প্রোডাক্ট গ্যালারি ও অর্ডার বুকিং
            </h1>
            <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
              এখানে ছবি দেখে সহজে পণ্যের পরিমাণ সিলেক্ট করুন। ডানপাশের অপশনে চাপ দিলে আপনার আসল{' '}
              <span className="text-amber-300 font-bold underline">দৈনিক সামারি ও মেমো কাউন্টার</span> অ্যাপ খুলে যাবে!
            </p>
          </div>

          {/* MAIN PROMINENT BUTTON TO OPEN SUMMARY APK */}
          <button
            id="open-summary-app-hero-btn"
            type="button"
            onClick={onOpenSummaryApp}
            className="w-full sm:w-auto px-5 py-3.5 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:from-amber-300 hover:to-amber-500 active:scale-98 text-slate-950 font-black rounded-xl text-sm sm:text-base flex items-center justify-center gap-2.5 shadow-md hover:shadow-xl transition-all cursor-pointer ring-2 ring-amber-400/50"
            title="আপনার দৈনিক সামারি ও মেমো হিসাব অ্যাপ খুলুন"
          >
            <Layers className="w-5 h-5 text-slate-950" />
            <div className="text-left leading-tight">
              <div className="text-xs uppercase font-extrabold tracking-wider text-slate-800">
                প্রয়োজনে চাপ দিন
              </div>
              <div className="text-sm sm:text-base font-black">
                আমার সামারি অ্যাপ খুলুন 📊
              </div>
            </div>
            <ArrowRight className="w-5 h-5 text-slate-950 ml-1" />
          </button>
        </div>

        {/* Live Order Ribbon inside Hero */}
        <div className="mt-4 pt-3 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5 flex-wrap">
            <div className="flex items-center gap-1.5 text-slate-200">
              <span className="text-slate-400">নির্বাচিত আইটেম:</span>
              <span className="font-black text-amber-300 text-sm bg-slate-800/80 px-2 py-0.5 rounded-md border border-slate-700">
                {totalSelectedKinds} প্রকার ({totalSelectedItems} টি পণ্য)
              </span>
            </div>

            {/* Instant Add All Directly Inside Catalog / Photos */}
            {totalSelectedItems > 0 && onAddAll && (
              <button
                type="button"
                id="catalog-hero-add-all-btn"
                onClick={onAddAll}
                className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white font-black text-xs flex items-center gap-1.5 transition cursor-pointer shadow-md active:scale-95 animate-pulse border border-blue-400"
                title="নির্বাচিত সকল পণ্য এক ক্লিকে আজকের মেমোতে যোগ করুন"
              >
                <Check className="w-3.5 h-3.5 text-amber-300 stroke-[3]" />
                <span>সব যোগ করুন ({totalSelectedItems} পিস)</span>
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              id="permanent-save-photos-btn"
              onClick={handlePermanentSaveAndDownload}
              className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 text-xs font-black flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
              title="সকল পণ্যের ছবি ডিভাইসের পার্মানেন্ট স্টোরেজে সেভ ও ব্যাকআপ ফাইল ডাউনলোড করুন"
            >
              <Download className="w-3.5 h-3.5 text-slate-950" />
              <span>ছবি পার্মানেন্ট সেভ ও ব্যাকআপ</span>
            </button>

            <button
              type="button"
              id="batch-photo-name-match-btn"
              onClick={() => batchFileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
              title="ফাইলের নাম অনুযায়ী স্বয়ংক্রিয়ভাবে ছবি বসান"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
              <span>নাম অনুযায়ী ছবি আপলোড</span>
            </button>

            <button
              type="button"
              id="batch-photo-manage-btn"
              onClick={() => setIsBatchModalOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer shadow-xs"
            >
              <Camera className="w-3.5 h-3.5 text-amber-400" />
              <span>ছবি পরিবর্তন ও রিস্টোর</span>
            </button>

            <button
              type="button"
              id="goto-counter-direct-btn"
              onClick={onOpenSummaryApp}
              className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer"
            >
              <span>মেমোতে যান</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>

      {/* TOP CONTROLS & CATEGORY TABS (CATEGORY-WISE TABS ON TOP) */}
      <div className="sticky top-0 z-30 bg-slate-50/95 dark:bg-slate-900/95 backdrop-blur-md pt-2 pb-3 mb-4 border-b border-slate-200 dark:border-slate-800">
        {/* Search and Filter Row */}
        <div className="flex items-center gap-2 mb-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              id="catalog-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="পণ্যের নাম বা নম্বর দিয়ে খুঁজুন (যেমন: সস, চকোলেড, ৫)..."
              className="w-full pl-9 pr-8 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 transition shadow-xs"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {totalSelectedItems > 0 && onAddAll && (
            <button
              type="button"
              id="sticky-catalog-add-all-btn"
              onClick={onAddAll}
              className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-black text-xs sm:text-sm flex items-center gap-1 shadow-sm transition whitespace-nowrap cursor-pointer active:scale-95 animate-pulse"
              title="নির্বাচিত সকল পণ্য একসাথে আজকের মেমোতে যোগ করুন"
            >
              <Check className="w-3.5 h-3.5 text-amber-300 stroke-[3]" />
              <span>সব যোগ ({totalSelectedItems})</span>
            </button>
          )}

          <button
            type="button"
            id="open-summary-app-header-btn"
            onClick={onOpenSummaryApp}
            className="px-3.5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs sm:text-sm flex items-center gap-1.5 shadow-sm transition whitespace-nowrap cursor-pointer"
            title="আমার দৈনিক সামারি অ্যাপে যান"
          >
            <FileText className="w-4 h-4" />
            <span className="hidden sm:inline">সামারি অ্যাপ</span>
            <span className="sm:hidden">সামারি</span>
            {totalSelectedItems > 0 && (
              <span className="bg-amber-400 text-slate-950 text-[11px] font-black rounded-full px-1.5 py-0.2">
                {totalSelectedItems}
              </span>
            )}
          </button>
        </div>

        {/* CATEGORY-WISE TABS ("keta gori wyaj diye den upore :") */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1 text-xs">
          {/* 1. All Category */}
          <button
            type="button"
            id="category-tab-all"
            onClick={() => setSelectedCategory('all')}
            className={`px-3 py-1.5 rounded-full font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer shrink-0 border ${
              selectedCategory === 'all'
                ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-950 border-slate-900 dark:border-white shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>সব পণ্য</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
              {products.length}
            </span>
          </button>

          {/* Individual Category Tabs */}
          {CATEGORIES.map((cat) => {
            const count = products.filter((p) => {
              if (cat.isOthers) return p.categoryKey === 'others';
              return cat.productIds.includes(p.id) || p.categoryKey === cat.key;
            }).length;

            const isSelected = selectedCategory === cat.key;

            return (
              <button
                key={cat.key}
                type="button"
                id={`category-tab-${cat.key}`}
                onClick={() => setSelectedCategory(cat.key)}
                className={`px-3 py-1.5 rounded-full font-bold flex items-center gap-1.5 transition-all whitespace-nowrap cursor-pointer shrink-0 border ${
                  isSelected
                    ? 'text-white shadow-sm'
                    : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
                style={{
                  backgroundColor: isSelected ? cat.color : undefined,
                  borderColor: isSelected ? cat.borderColor : undefined,
                }}
              >
                {getCategoryIcon(cat.iconName)}
                <span>{cat.nameBn}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected
                      ? 'bg-black/20 text-white'
                      : 'bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* PRODUCTS IMAGE GRID */}
      {filteredProducts.length === 0 ? (
        <div className="bg-white dark:bg-slate-800 rounded-2xl p-10 text-center border border-slate-200 dark:border-slate-700 my-8 shadow-xs">
          <Boxes className="w-12 h-12 text-slate-300 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-800 dark:text-slate-200">
            কোনো প্রোডাক্ট পাওয়া যায়নি
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            অনুগ্রহ করে অন্য নাম দিয়ে খুঁজুন অথবা &quot;সব পণ্য&quot; ক্যাটাগরি নির্বাচন করুন।
          </p>
          <button
            type="button"
            onClick={() => {
              setSelectedCategory('all');
              setSearchQuery('');
            }}
            className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-xl text-xs font-bold hover:bg-blue-500 cursor-pointer"
          >
            সব পণ্য দেখুন
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 sm:gap-4">
          {filteredProducts.map((p) => {
            const originalIndex = products.findIndex((prod) => prod.id === p.id);
            const currentQty = inputs[originalIndex] || 0;
            const hasCustomImage = !!imageMap[p.id];
            const isSelected = currentQty > 0;

            const categoryDef = CATEGORIES.find(
              (c) => c.key === (p.categoryKey || 'drinks') || c.productIds.includes(p.id)
            );

            return (
              <div
                key={p.id}
                id={`product-card-${p.id}`}
                className={`flex flex-col bg-white dark:bg-slate-800/90 rounded-2xl border transition-all duration-200 shadow-xs hover:shadow-md relative overflow-hidden group ${
                  isSelected
                    ? 'border-blue-500 dark:border-amber-400 ring-2 ring-blue-400/30 dark:ring-amber-400/20'
                    : 'border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
                }`}
              >
                {/* Visual Image Header */}
                <div className="relative w-full aspect-square bg-slate-50 dark:bg-slate-900/60 overflow-hidden flex items-center justify-center border-b border-slate-100 dark:border-slate-700/60">
                  <ProductArtwork
                    product={p}
                    customImage={imageMap[p.id]}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />

                  {/* Category Pill on top left of image */}
                  <span
                    className="absolute top-2 left-2 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-xs backdrop-blur-md"
                    style={{
                      backgroundColor: categoryDef ? `${categoryDef.color}dd` : '#3b82f6dd',
                      color: '#ffffff',
                    }}
                  >
                    {categoryDef?.nameBn || 'সাধারণ'}
                  </span>

                  {/* Camera / Change Photo Button */}
                  <button
                    type="button"
                    id={`upload-photo-btn-${p.id}`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setActiveUploadProductId(p.id);
                      if (fileInputRef.current) {
                        fileInputRef.current.click();
                      }
                    }}
                    className="absolute top-2 right-2 p-1.5 bg-slate-900/75 hover:bg-slate-900 text-white rounded-lg backdrop-blur-md shadow-xs transition active:scale-95 cursor-pointer"
                    title="এই পণ্যের ছবি যোগ বা পরিবর্তন করুন"
                  >
                    <Camera className="w-3.5 h-3.5 text-amber-300" />
                  </button>

                  {/* Selected count badge on top of image */}
                  {isSelected && (
                    <div className="absolute bottom-2 right-2 bg-blue-600 text-white font-black text-xs px-2 py-0.5 rounded-md shadow-md animate-in zoom-in-50">
                      {currentQty} টি
                    </div>
                  )}
                </div>

                {/* Card Body */}
                <div className="p-3 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <h4
                        className="text-sm font-extrabold text-slate-900 dark:text-slate-100 leading-tight line-clamp-2"
                        title={p.name}
                      >
                        {p.name}
                      </h4>
                    </div>

                    <div className="flex items-baseline justify-between gap-1 mb-2">
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                        আইটেম #{originalIndex + 1}
                      </span>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-medium">
                        {categoryDef?.nameBn || ''}
                      </span>
                    </div>
                  </div>

                  {/* Quantity Stepper & Add to Memo */}
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60">
                    <div className="flex items-center justify-between gap-1 mb-1.5">
                      <button
                        type="button"
                        id={`qty-minus-${p.id}`}
                        onClick={() => {
                          const next = Math.max(0, currentQty - 1);
                          onInputChange(originalIndex, next);
                        }}
                        disabled={currentQty <= 0}
                        className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-700 hover:bg-slate-200 dark:hover:bg-slate-600 disabled:opacity-40 disabled:hover:bg-slate-100 dark:disabled:hover:bg-slate-700 text-slate-700 dark:text-slate-200 flex items-center justify-center font-bold transition cursor-pointer active:scale-95"
                        title="১টি কমান"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>

                      <input
                        type="number"
                        id={`qty-input-${p.id}`}
                        min="0"
                        value={currentQty === 0 ? '' : currentQty}
                        onChange={(e) => {
                          const val = Math.max(0, parseInt(e.target.value, 10) || 0);
                          onInputChange(originalIndex, val);
                        }}
                        placeholder="0"
                        className="w-12 h-8 text-center text-sm font-black bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />

                      <button
                        type="button"
                        id={`qty-plus-${p.id}`}
                        onClick={() => {
                          onInputChange(originalIndex, currentQty + 1);
                        }}
                        className="w-8 h-8 rounded-lg bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white flex items-center justify-center font-bold transition cursor-pointer active:scale-95 shadow-xs"
                        title="১টি বাড়ান"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Quick Step Buttons (+1, +5, +10) */}
                    <div className="grid grid-cols-3 gap-1">
                      <button
                        type="button"
                        onClick={() => onInputChange(originalIndex, currentQty + 1)}
                        className="py-1 text-[10px] font-bold rounded bg-slate-100 dark:bg-slate-700/60 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                      >
                        +১
                      </button>
                      <button
                        type="button"
                        onClick={() => onInputChange(originalIndex, currentQty + 5)}
                        className="py-1 text-[10px] font-bold rounded bg-slate-100 dark:bg-slate-700/60 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                      >
                        +৫
                      </button>
                      <button
                        type="button"
                        onClick={() => onInputChange(originalIndex, currentQty + 10)}
                        className="py-1 text-[10px] font-bold rounded bg-slate-100 dark:bg-slate-700/60 hover:bg-slate-200 dark:hover:bg-slate-600 text-slate-700 dark:text-slate-300 transition cursor-pointer"
                      >
                        +১০
                      </button>
                    </div>

                    {/* Selected count preview */}
                    {isSelected && (
                      <div className="mt-1.5 text-center text-[10px] font-bold text-blue-600 dark:text-amber-400">
                        {currentQty} টি নির্বাচিত
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* FLOATING ACTION BOTTOM SUMMARY BAR */}
      {totalSelectedItems > 0 && (
        <aside
          aria-label="অর্ডার সামারি বার"
          className="fixed bottom-20 left-4 right-4 z-40 max-w-lg mx-auto bg-gradient-to-r from-slate-900 via-slate-950 to-blue-950 text-white rounded-2xl p-3.5 shadow-2xl border border-blue-500/50 flex items-center justify-between gap-3 animate-in slide-in-from-bottom-5 duration-200"
        >
          <div>
            <div className="text-[10px] text-amber-300 font-bold tracking-wider uppercase flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              অর্ডার নির্বাচিত
            </div>
            <div className="text-sm font-black text-white">
              {totalSelectedKinds} প্রকার ({totalSelectedItems} টি পণ্য)
            </div>
            <div className="text-xs text-slate-300">
              মেমো ও হিসাব দেখতে সামারি অ্যাপে যান
            </div>
          </div>

          <button
            type="button"
            id="floating-open-summary-app-btn"
            onClick={onOpenSummaryApp}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 active:scale-95 text-slate-950 font-black rounded-xl text-xs sm:text-sm flex items-center gap-1.5 shadow-md transition cursor-pointer whitespace-nowrap"
          >
            <span>সামারি অ্যাপে মেমো করুন</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </aside>
      )}

      {/* BATCH PHOTO UPLOAD & MANAGEMENT MODAL */}
      {isBatchModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5 text-amber-500" />
                <h3 className="text-base font-black text-slate-900 dark:text-white">
                  প্রোডাক্ট ছবি আপলোড ও ম্যানেজ
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsBatchModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
              <p>
                আপনার মোবাইল বা কম্পিউটার থেকে ছবিগুলো নির্বাচন করুন। সিস্টেম স্বয়ংক্রিয়ভাবে ফাইলের নাম (যেমন: <span className="font-bold text-amber-600 dark:text-amber-400">১৬০ সস</span>, <span className="font-bold text-amber-600 dark:text-amber-400">চকোলেড ২৪</span>, <span className="font-bold text-amber-600 dark:text-amber-400">টোস্ট</span> ইত্যাদি) বা নম্বরের সাথে মিলিয়ে বসিয়ে দেবে।
              </p>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/70 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-center">
                <UploadCloud className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <div className="font-bold text-slate-800 dark:text-slate-200 mb-1">
                  নাম অনুযায়ী ছবি আপলোড ও মেলান
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 mb-3">
                  ছবি নির্বাচন করার সাথে সাথে নামের তালিকা মিলিয়ে দেখার অপশন পাবেন।
                </p>
                <button
                  type="button"
                  id="batch-upload-trigger-btn"
                  onClick={() => batchFileInputRef.current?.click()}
                  disabled={isProcessingImage}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 mx-auto transition cursor-pointer disabled:opacity-50 shadow-md"
                >
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>ছবি নির্বাচন করুন (নাম অনুযায়ী বসবে)</span>
                </button>
              </div>

              {/* Permanent Backup & Restore Section */}
              <div className="p-3.5 bg-gradient-to-r from-amber-500/10 via-emerald-500/10 to-blue-500/10 rounded-xl border border-amber-300/80 dark:border-amber-600/50 space-y-2.5">
                <div className="font-black text-slate-800 dark:text-slate-100 flex items-center justify-between text-xs sm:text-sm">
                  <span className="flex items-center gap-1.5">
                    <Camera className="w-4 h-4 text-amber-500" />
                    ছবি পার্মানেন্ট সেভ ও রিস্টোর
                  </span>
                  <span className="text-[10px] font-bold bg-amber-500 text-slate-950 px-2 py-0.5 rounded-full">
                    চিরদিনের জন্য সুরক্ষিত
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 dark:text-slate-300">
                  আপনার ডিভাইসের পার্মানেন্ট স্টোরেজে (IndexedDB) সব ছবি সেভ রাখুন অথবা ১ ক্লিকে ব্যাকআপ ফাইল ডাউনলোড করে অন্য মোবাইলে পাঠান।
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={handlePermanentSaveAndDownload}
                    className="py-2 px-3 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ছবি ব্যাকআপ ডাউনলোড</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => photosRestoreInputRef.current?.click()}
                    className="py-2 px-3 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>ছবি রিস্টোর ফাইল দিন</span>
                  </button>
                </div>
              </div>

              <div className="text-[11px] text-slate-500 dark:text-slate-400 space-y-1 bg-slate-100 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200/50 dark:border-slate-700/50">
                <div className="font-bold text-slate-700 dark:text-slate-300 mb-0.5">সহজ টিপস:</div>
                <div>• ফাইলের নামে পণ্যের নাম (যেমন: সস, চকোলেড, টোস্ট, ফিডার ইত্যাদি) থাকলে তা স্বয়ংক্রিয়ভাবে মিলে যায়।</div>
                <div>• ছবিগুলো স্ক্রিনে ড্র্যাগ করে ছেড়ে দিয়েও আপলোড করা যায়।</div>
                <div>• বর্তমানে <strong>{Object.keys(imageMap).length}</strong> টি পণ্যে কাস্টম ছবি সংরক্ষিত আছে।</div>
              </div>

              {Object.keys(imageMap).length > 0 && (
                <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={handleClearAllPhotos}
                    className="w-full py-2 bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/50 text-rose-600 dark:text-rose-300 rounded-xl font-bold text-xs border border-rose-200 dark:border-rose-900 flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>সকল আপলোডকৃত কাস্টম ছবি মুছে ফেলুন</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* SMART NAME MATCHER REVIEW MODAL */}
      <SmartNameMatcherModal
        isOpen={isMatcherModalOpen}
        onClose={() => setIsMatcherModalOpen(false)}
        products={products}
        initialMatches={pendingMatches}
        imageMap={imageMap}
        onUpdateImageMap={onUpdateImageMap}
        showToast={showToast}
      />
    </div>
  );
};
