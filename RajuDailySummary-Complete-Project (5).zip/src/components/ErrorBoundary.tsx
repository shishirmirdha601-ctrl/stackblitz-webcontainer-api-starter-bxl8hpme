import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Download, Trash2 } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null
    };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, errorInfo: null };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error caught by ErrorBoundary:', error, errorInfo);
    this.setState({ errorInfo });
  }

  private handleReload = () => {
    window.location.reload();
  };

  private handleEmergencyExport = () => {
    try {
      const dump: Record<string, any> = {
        exportedAt: new Date().toISOString(),
        localStorage: {}
      };
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key && key.startsWith('raju_')) {
          try {
            dump.localStorage[key] = JSON.parse(localStorage.getItem(key) || 'null');
          } catch {
            dump.localStorage[key] = localStorage.getItem(key);
          }
        }
      }
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `raju-emergency-backup-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      alert('জরুরি ব্যাকআপ নিতে সমস্যা হয়েছে। অনুগ্রহ করে ব্রাউজার রিলোড দিন।');
    }
  };

  private handleClearCorruptCache = () => {
    if (window.confirm('ক্যাশ রিসেট করতে চান? আপনার মূল ডেটা মুছে যাবে না, শুধু ব্রাউজারের লোডিং সমস্যা ঠিক হবে।')) {
      try {
        sessionStorage.clear();
        window.location.reload();
      } catch {
        window.location.reload();
      }
    }
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4 text-center">
            <div className="w-14 h-14 mx-auto rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div>
              <h2 className="text-xl font-black text-white">
                সাময়িক লোডিং ত্রুটি সমাধান
              </h2>
              <p className="text-sm text-slate-400 mt-1">
                আপনার কোনো হিসাব হারায়নি। সাদা পর্দা বা ব্রাউজারের মেমোরি সমস্যার কারণে এটি হয়েছে।
              </p>
            </div>

            <div className="space-y-2 pt-2">
              <button
                type="button"
                onClick={this.handleReload}
                className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition"
              >
                <RefreshCw className="w-4 h-4" />
                <span>অ্যাপ পুনরায় লোড করুন</span>
              </button>

              <button
                type="button"
                onClick={this.handleEmergencyExport}
                className="w-full py-3 px-4 bg-emerald-700 hover:bg-emerald-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition"
              >
                <Download className="w-4 h-4" />
                <span>জরুরি ডেটা ব্যাকআপ ডাউনলোড</span>
              </button>

              <button
                type="button"
                onClick={this.handleClearCorruptCache}
                className="w-full py-2.5 px-4 bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium text-xs rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>ক্যাশ রিসেট ও রিফ্রেশ</span>
              </button>
            </div>

            {this.state.error && (
              <details className="text-left text-xs text-slate-500 bg-slate-950 p-2.5 rounded-lg border border-slate-800/80 overflow-auto max-h-24">
                <summary className="cursor-pointer font-bold text-slate-400">ত্রুটির বিবরণ (Technical)</summary>
                <pre className="mt-1 whitespace-pre-wrap">{this.state.error.toString()}</pre>
              </details>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
