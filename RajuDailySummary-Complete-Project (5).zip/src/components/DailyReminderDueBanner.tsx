import React from 'react';
import { BellRing, FileDown, FileSpreadsheet, X, Check } from 'lucide-react';

interface DailyReminderDueBannerProps {
  currentDate: string;
  onDownloadPDF: () => void;
  onDownloadCSV: () => void;
  onDismiss: () => void;
}

export const DailyReminderDueBanner: React.FC<DailyReminderDueBannerProps> = ({
  currentDate,
  onDownloadPDF,
  onDownloadCSV,
  onDismiss,
}) => {
  return (
    <div
      id="daily-summary-reminder-banner"
      className="fixed top-16 sm:top-20 left-1/2 -translate-x-1/2 z-50 w-full max-w-xl px-3 animate-fade-in no-print"
    >
      <div className="bg-slate-900 text-white rounded-2xl p-3.5 sm:p-4 shadow-2xl border-2 border-amber-400 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 backdrop-blur-md">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 font-bold shadow-md">
            <BellRing className="w-5 h-5 animate-wiggle" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="font-extrabold text-sm sm:text-base text-amber-400">
                দৈনিক বিক্রয় রিপোর্ট ডাউনলোড রিমাইন্ডার
              </h4>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded font-mono">
                {currentDate}
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-0.5 leading-snug">
              আজকের দিনশেষে সকল মেমো হিসাব সম্পন্ন হয়েছে? রিপোর্টগুলো ডাউনলোড করে আপনার ডিভাইসে ব্যাকআপ রাখুন।
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-center shrink-0 flex-wrap">
          <button
            type="button"
            onClick={() => {
              onDownloadPDF();
              onDismiss();
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
            title="আজকের PDF রিপোর্ট ডাউনলোড করুন"
          >
            <FileDown className="w-4 h-4" />
            <span>PDF রিপোর্ট</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onDownloadCSV();
              onDismiss();
            }}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
            title="আজকের Excel/CSV রিপোর্ট ডাউনলোড করুন"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Excel / CSV</span>
          </button>

          <button
            type="button"
            onClick={onDismiss}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition cursor-pointer"
            title="বাতিল করুন"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
