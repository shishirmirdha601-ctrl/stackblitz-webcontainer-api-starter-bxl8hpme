import React, { useState, useMemo, useRef } from 'react';
import { AppStorageData, DayData } from '../types';
import { Product } from '../data/products';
import { CATEGORIES } from '../data/categories';
import { AnimatedCounter } from './AnimatedCounter';
import {
  LayoutDashboard,
  Calendar,
  CalendarDays,
  TrendingUp,
  Package,
  Receipt,
  Clock,
  ChevronLeft,
  ChevronRight,
  ArrowRight,
  Sparkles,
  BarChart3,
  Layers,
  ArrowUpRight,
  Eye,
  FileSpreadsheet,
  Printer,
  RotateCcw,
  CheckCircle2,
  CalendarRange
} from 'lucide-react';

export interface DashboardViewProps {
  data: AppStorageData;
  products: Product[];
  currentDate: string;
  onSelectDate: (date: string) => void;
  onSwitchToCounter: () => void;
  onToast: (msg: string) => void;
  onAddSampleHistory?: () => void;
  onClearSampleHistory?: () => void;
  hasSampleData?: boolean;
}

export interface DayStats {
  date: string;
  items: number;
  sales: number;
  memos: number;
}

export interface PeriodSummary {
  key: string;
  type: 'week' | 'month';
  title: string;
  subtitle: string;
  isCurrent: boolean;
  totalItems: number;
  totalSales: number;
  totalMemos: number;
  daysCount: number;
  dates: string[];
  dayBreakdown: DayStats[];
  topProducts: {
    id: number;
    name: string;
    quantity: number;
    amount: number;
    categoryKey?: string;
  }[];
  categoryTotals: {
    categoryKey: string;
    nameBn: string;
    color: string;
    quantity: number;
    amount: number;
  }[];
}

interface DaySummaryStats {
  date: string;
  items: number;
  sales: number;
  memos: number;
  productSales: Record<number, number>;
  categorySales: Record<string, { quantity: number; amount: number }>;
}

function money(n: number | string): string {
  return Number(n || 0).toLocaleString('en-US');
}

const BANGLA_MONTHS = [
  'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
  'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
];

function formatDisplayDate(dateStr: string): string {
  try {
    const [y, m, d] = dateStr.split('-');
    const monthName = BANGLA_MONTHS[parseInt(m, 10) - 1] || m;
    return `${d} ${monthName} ${y}`;
  } catch {
    return dateStr;
  }
}

// Helper to calculate Monday-Sunday week boundaries for any YYYY-MM-DD
function getWeekInfo(dateStr: string): {
  weekKey: string;
  startDate: string;
  endDate: string;
  title: string;
  subtitle: string;
} {
  const d = new Date(dateStr + 'T12:00:00');
  const day = d.getDay(); // 0 is Sunday, 1 is Monday...
  // Consider Monday as week start
  const diffToMonday = day === 0 ? -6 : 1 - day;
  const monday = new Date(d);
  monday.setDate(d.getDate() + diffToMonday);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  const formatISO = (date: Date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const dt = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${dt}`;
  };

  const startIso = formatISO(monday);
  const endIso = formatISO(sunday);

  const startDay = monday.getDate();
  const endDay = sunday.getDate();
  const startMonth = BANGLA_MONTHS[monday.getMonth()];
  const endMonth = BANGLA_MONTHS[sunday.getMonth()];
  const year = sunday.getFullYear();

  let dateRangeLabel = '';
  if (startMonth === endMonth) {
    dateRangeLabel = `${startDay} - ${endDay} ${startMonth} ${year}`;
  } else {
    dateRangeLabel = `${startDay} ${startMonth} - ${endDay} ${endMonth} ${year}`;
  }

  return {
    weekKey: `${startIso}_${endIso}`,
    startDate: startIso,
    endDate: endIso,
    title: `সপ্তাহ: ${dateRangeLabel}`,
    subtitle: `${startIso} থেকে ${endIso}`,
  };
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  data,
  products,
  currentDate,
  onSelectDate,
  onSwitchToCounter,
  onToast,
  onAddSampleHistory,
  onClearSampleHistory,
  hasSampleData,
}) => {
  const [periodType, setPeriodType] = useState<'week' | 'month'>('week');
  const [cardLayout, setCardLayout] = useState<'scroll' | 'grid'>('scroll');
  const [expandedCardKey, setExpandedCardKey] = useState<string | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Compute stats for every recorded date in data
  const dateSummaries = useMemo(() => {
    const map: Record<string, DaySummaryStats> = {};

    (Object.entries(data) as [string, DayData][]).forEach(([dateStr, dayData]) => {
      let dayItems = 0;
      let daySales = 0;
      const productSales: Record<number, number> = {};
      const categorySales: Record<string, { quantity: number; amount: number }> = {};

      // Regular catalog products
      if (Array.isArray(dayData.sum)) {
        dayData.sum.forEach((qty, idx) => {
          if (qty > 0) {
            dayItems += qty;
            const p = products[idx];
            const price = p?.price || 0;
            const amount = qty * price;
            daySales += amount;
            productSales[idx] = (productSales[idx] || 0) + qty;

            const catKey = p?.categoryKey || 'others';
            if (!categorySales[catKey]) {
              categorySales[catKey] = { quantity: 0, amount: 0 };
            }
            categorySales[catKey].quantity += qty;
            categorySales[catKey].amount += amount;
          }
        });
      }

      // Unlisted items
      if (Array.isArray(dayData.unlistedItems)) {
        dayData.unlistedItems.forEach((u) => {
          const q = u.quantity || 0;
          const amt = q * (u.price || 0);
          dayItems += q;
          daySales += amt;

          if (!categorySales['others']) {
            categorySales['others'] = { quantity: 0, amount: 0 };
          }
          categorySales['others'].quantity += q;
          categorySales['others'].amount += amt;
        });
      }

      // Memos count: distinct notes like "মেমো-০১" or entry count
      let memosCount = 0;
      if (Array.isArray(dayData.history) && dayData.history.length > 0) {
        const uniqueNotes = new Set(
          dayData.history.map((h) => h.note?.trim() || h.id)
        );
        memosCount = uniqueNotes.size;
      } else if (dayItems > 0) {
        memosCount = 1;
      }

      map[dateStr] = {
        date: dateStr,
        items: dayItems,
        sales: daySales,
        memos: memosCount,
        productSales,
        categorySales,
      };
    });

    return map;
  }, [data, products]);

  // Group into Weeks
  const weeklySummaries = useMemo<PeriodSummary[]>(() => {
    const todayWeek = getWeekInfo(currentDate);
    const groups: Record<
      string,
      {
        info: ReturnType<typeof getWeekInfo>;
        dates: string[];
        isCurrent: boolean;
      }
    > = {};

    // Ensure current week is present even if no sales recorded yet
    groups[todayWeek.weekKey] = {
      info: todayWeek,
      dates: [],
      isCurrent: true,
    };

    // Populate all dates from storage
    Object.keys(dateSummaries).forEach((dateStr) => {
      const info = getWeekInfo(dateStr);
      if (!groups[info.weekKey]) {
        groups[info.weekKey] = {
          info,
          dates: [],
          isCurrent: info.weekKey === todayWeek.weekKey,
        };
      }
      if (!groups[info.weekKey].dates.includes(dateStr)) {
        groups[info.weekKey].dates.push(dateStr);
      }
    });

    const result: PeriodSummary[] = Object.values(groups).map((group) => {
      let totalItems = 0;
      let totalSales = 0;
      let totalMemos = 0;
      const combinedProducts: Record<number, number> = {};
      const combinedCategories: Record<string, { quantity: number; amount: number }> = {};
      const dayBreakdown: DayStats[] = [];

      group.dates.sort().reverse().forEach((d) => {
        const stats = dateSummaries[d];
        if (stats) {
          totalItems += stats.items;
          totalSales += stats.sales;
          totalMemos += stats.memos;

          dayBreakdown.push({
            date: d,
            items: stats.items,
            sales: stats.sales,
            memos: stats.memos,
          });

          (Object.entries(stats.productSales) as [string, number][]).forEach(([pId, qty]) => {
            const id = Number(pId);
            combinedProducts[id] = (combinedProducts[id] || 0) + qty;
          });

          (Object.entries(stats.categorySales) as [string, { quantity: number; amount: number }][]).forEach(([cKey, val]) => {
            if (!combinedCategories[cKey]) {
              combinedCategories[cKey] = { quantity: 0, amount: 0 };
            }
            combinedCategories[cKey].quantity += val.quantity;
            combinedCategories[cKey].amount += val.amount;
          });
        }
      });

      // Top 3 Products
      const topProducts = Object.entries(combinedProducts)
        .map(([idStr, qty]) => {
          const id = Number(idStr);
          const p = products[id];
          return {
            id,
            name: p?.name || `পণ্য #${id + 1}`,
            quantity: qty,
            amount: qty * (p?.price || 0),
            categoryKey: p?.categoryKey,
          };
        })
        .sort((a, b) => b.quantity - a.quantity)
        .slice(0, 4);

      // Category breakdown
      const categoryTotals = Object.entries(combinedCategories).map(([cKey, val]) => {
        const catDef = CATEGORIES.find((c) => c.key === cKey);
        return {
          categoryKey: cKey,
          nameBn: catDef?.nameBn || (cKey === 'others' ? 'অন্যান্য' : cKey),
          color: catDef?.color || '#64748b',
          quantity: val.quantity,
          amount: val.amount,
        };
      }).sort((a, b) => b.amount - a.amount);

      return {
        key: group.info.weekKey,
        type: 'week',
        title: group.isCurrent ? `চলতি সপ্তাহ (${group.info.title.replace('সপ্তাহ: ', '')})` : group.info.title,
        subtitle: group.info.subtitle,
        isCurrent: group.isCurrent,
        totalItems,
        totalSales,
        totalMemos,
        daysCount: group.dates.length,
        dates: group.dates,
        dayBreakdown,
        topProducts,
        categoryTotals,
      };
    });

    // Sort newest weeks first
    return result.sort((a, b) => b.subtitle.localeCompare(a.subtitle));
  }, [dateSummaries, products, currentDate]);

  // Group into Months
  const monthlySummaries = useMemo<PeriodSummary[]>(() => {
    const currentYearMonth = currentDate.slice(0, 7); // YYYY-MM
    const groups: Record<
      string,
      {
        monthKey: string;
        year: number;
        month: number;
        dates: string[];
        isCurrent: boolean;
      }
    > = {};

    // Ensure current month is present
    const [curY, curM] = currentYearMonth.split('-');
    groups[currentYearMonth] = {
      monthKey: currentYearMonth,
      year: parseInt(curY, 10),
      month: parseInt(curM, 10),
      dates: [],
      isCurrent: true,
    };

    // Populate all dates from storage
    Object.keys(dateSummaries).forEach((dateStr) => {
      const ym = dateStr.slice(0, 7);
      if (!groups[ym]) {
        const [y, m] = ym.split('-');
        groups[ym] = {
          monthKey: ym,
          year: parseInt(y, 10),
          month: parseInt(m, 10),
          dates: [],
          isCurrent: ym === currentYearMonth,
        };
      }
      if (!groups[ym].dates.includes(dateStr)) {
        groups[ym].dates.push(dateStr);
      }
    });

    const result: PeriodSummary[] = Object.values(groups).map((group) => {
      let totalItems = 0;
      let totalSales = 0;
      let totalMemos = 0;
      const combinedProducts: Record<number, number> = {};
      const combinedCategories: Record<string, { quantity: number; amount: number }> = {};
      const dayBreakdown: DayStats[] = [];

      group.dates.sort().reverse().forEach((d) => {
        const stats = dateSummaries[d];
        if (stats) {
          totalItems += stats.items;
          totalSales += stats.sales;
          totalMemos += stats.memos;

          dayBreakdown.push({
            date: d,
            items: stats.items,
            sales: stats.sales,
            memos: stats.memos,
          });

          (Object.entries(stats.productSales) as [string, number][]).forEach(([pId, qty]) => {
            const id = Number(pId);
            combinedProducts[id] = (combinedProducts[id] || 0) + qty;
          });

          (Object.entries(stats.categorySales) as [string, { quantity: number; amount: number }][]).forEach(([cKey, val]) => {
            if (!combinedCategories[cKey]) {
              combinedCategories[cKey] = { quantity: 0, amount: 0 };
            }
            combinedCategories[cKey].quantity += val.quantity;
            combinedCategories[cKey].amount += val.amount;
          });
        }
      });

      const topProducts = Object.entries(combinedProducts)
        .map(([idStr, qty]) => {
          const id = Number(idStr);
          const p = products[id];
          return {
            id,
            name: p?.name || `পণ্য #${id + 1}`,
            quantity: qty,
            amount: qty * (p?.price || 0),
            categoryKey: p?.categoryKey,
          };
        })
        .sort((a, b) => b.quantity - a.quantity)
        .slice(0, 5);

      const categoryTotals = Object.entries(combinedCategories).map(([cKey, val]) => {
        const catDef = CATEGORIES.find((c) => c.key === cKey);
        return {
          categoryKey: cKey,
          nameBn: catDef?.nameBn || (cKey === 'others' ? 'অন্যান্য' : cKey),
          color: catDef?.color || '#64748b',
          quantity: val.quantity,
          amount: val.amount,
        };
      }).sort((a, b) => b.amount - a.amount);

      const monthName = BANGLA_MONTHS[group.month - 1] || String(group.month);
      const title = group.isCurrent
        ? `চলতি মাস: ${monthName} ${group.year}`
        : `${monthName} ${group.year}`;

      return {
        key: group.monthKey,
        type: 'month',
        title,
        subtitle: `${group.monthKey} (০১-${monthName}-${group.year} হতে শেষ দিন)`,
        isCurrent: group.isCurrent,
        totalItems,
        totalSales,
        totalMemos,
        daysCount: group.dates.length,
        dates: group.dates,
        dayBreakdown,
        topProducts,
        categoryTotals,
      };
    });

    // Sort newest months first
    return result.sort((a, b) => b.key.localeCompare(a.key));
  }, [dateSummaries, products, currentDate]);

  // Select active list
  const activePeriods = periodType === 'week' ? weeklySummaries : monthlySummaries;

  // Overall Global KPI calculation
  const overallStats = useMemo(() => {
    let allItems = 0;
    let allSales = 0;
    let allMemos = 0;
    let maxDay = { date: '', sales: 0, items: 0 };
    const recordedDays = Object.values(dateSummaries) as DaySummaryStats[];

    recordedDays.forEach((d) => {
      allItems += d.items;
      allSales += d.sales;
      allMemos += d.memos;
      if (d.sales > maxDay.sales) {
        maxDay = { date: d.date, sales: d.sales, items: d.items };
      }
    });

    const activeDaysCount = recordedDays.filter((d) => d.items > 0).length || 1;
    const avgDailySales = Math.round(allSales / activeDaysCount);

    return {
      allItems,
      allSales,
      allMemos,
      activeDaysCount,
      avgDailySales,
      maxDay,
    };
  }, [dateSummaries]);

  // Scroll controls
  const handleScroll = (direction: 'left' | 'right') => {
    if (!scrollContainerRef.current) return;
    const amount = scrollContainerRef.current.clientWidth * 0.75 || 340;
    scrollContainerRef.current.scrollBy({
      left: direction === 'left' ? -amount : amount,
      behavior: 'smooth',
    });
  };

  // Export summary to CSV
  const handleExportCSV = () => {
    try {
      const headers = ['পিরিয়ড (Period)', 'তারিখ সীমা (Range)', 'মোট পণ্য পিস (Items)', 'মোট বিক্রয় টাকা (Sales Amount)', 'মেমো সংখ্যা (Memos)', 'সক্রিয় দিন (Days)'];
      const rows = activePeriods.map((p) => [
        `"${p.title.replace(/"/g, '""')}"`,
        `"${p.subtitle}"`,
        p.totalItems,
        p.totalSales,
        p.totalMemos,
        p.daysCount,
      ]);

      const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Raju_Sales_Dashboard_${periodType}_${currentDate}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      onToast(`${periodType === 'week' ? 'সাপ্তাহিক' : 'মাসিক'} সামারি Excel/CSV ফাইলে এক্সপোর্ট হয়েছে!`);
    } catch {
      onToast('CSV এক্সপোর্ট করতে সমস্যা হয়েছে');
    }
  };

  return (
    <div id="dashboard-view-container" className="space-y-4 animate-fadeIn">
      {/* Top Banner & Mode Toggle */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 transition-colors">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-blue-600/10 dark:bg-blue-500/20 text-blue-600 dark:text-blue-400 border border-blue-500/30 flex items-center justify-center shrink-0">
              <LayoutDashboard className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                  বিক্রয় ও পণ্য ড্যাশবোর্ড (Sales Analytics)
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                  {periodType === 'week' ? 'সাপ্তাহিক মোড' : 'মাসিক মোড'}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                স্ক্রোল কার্ড ফরম্যাটে সাপ্তাহিক ও মাসিক মোট বিক্রয় টাকা ও আইটেমের সম্পূর্ণ হিসাব
              </p>
            </div>
          </div>

          {/* Quick Action Controls */}
          <div className="flex items-center gap-2 w-full sm:w-auto flex-wrap justify-end">
            <button
              type="button"
              id="back-to-counter-btn"
              onClick={onSwitchToCounter}
              className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer border border-slate-300 dark:border-slate-700 active:scale-95"
            >
              <Layers className="w-4 h-4 text-amber-500" />
              <span>দৈনিক কাউন্টারে ফিরুন</span>
            </button>

            <button
              type="button"
              id="export-dashboard-csv-btn"
              onClick={handleExportCSV}
              className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs active:scale-95"
              title="ড্যাশবোর্ডের ডেটা এক্সেলে ডাউনলোড করুন"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
              <span className="hidden sm:inline">Excel</span> এক্সপোর্ট
            </button>

            <button
              type="button"
              id="print-dashboard-btn"
              onClick={() => window.print()}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 text-white text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
              title="ড্যাশবোর্ড প্রিন্ট করুন"
            >
              <Printer className="w-4 h-4 text-slate-300" />
              <span>প্রিন্ট</span>
            </button>
          </div>
        </div>

        {/* Aggregate KPI Ribbon */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 mt-4 pt-4 border-t border-slate-200/80 dark:border-slate-800">
          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold mb-1">
              <span>সর্বমোট বিক্রয় টাকা</span>
              <TrendingUp className="w-4 h-4 text-emerald-500" />
            </div>
            <div className="text-lg sm:text-xl font-black text-emerald-600 dark:text-emerald-400 tracking-tight">
              ৳ <AnimatedCounter value={overallStats.allSales} formatter={money} />
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              মোট রেকর্ডকৃত {overallStats.activeDaysCount} দিনের বিক্রয়
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold mb-1">
              <span>সর্বমোট বিক্রিত পণ্য</span>
              <Package className="w-4 h-4 text-blue-500" />
            </div>
            <div className="text-lg sm:text-xl font-black text-blue-600 dark:text-blue-400 tracking-tight">
              <AnimatedCounter value={overallStats.allItems} formatter={money} /> <span className="text-xs font-semibold text-slate-500">পিস</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              মোট মেমো কাটা হয়েছে {overallStats.allMemos} টি
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold mb-1">
              <span>গড় দৈনিক বিক্রয়</span>
              <BarChart3 className="w-4 h-4 text-amber-500" />
            </div>
            <div className="text-lg sm:text-xl font-black text-amber-600 dark:text-amber-400 tracking-tight">
              ৳ {money(overallStats.avgDailySales)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5">
              প্রতি সক্রিয় দিনে গড়ে বিক্রয়
            </div>
          </div>

          <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold mb-1">
              <span>সর্বোচ্চ বিক্রির দিন</span>
              <Sparkles className="w-4 h-4 text-purple-500" />
            </div>
            <div className="text-lg sm:text-xl font-black text-purple-600 dark:text-purple-400 tracking-tight">
              ৳ {money(overallStats.maxDay.sales)}
            </div>
            <div className="text-[11px] text-slate-400 mt-0.5 truncate" title={overallStats.maxDay.date}>
              {overallStats.maxDay.date ? formatDisplayDate(overallStats.maxDay.date) : 'কোনো ডাটা নেই'}
            </div>
          </div>
        </div>
      </section>

      {/* Period Selection Tabs & Scroll Controls */}
      <section className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 transition-colors">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
          {/* Weekly vs Monthly Selector */}
          <div className="flex items-center p-1 bg-slate-100 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              id="period-toggle-week-btn"
              onClick={() => setPeriodType('week')}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-black transition cursor-pointer flex items-center gap-1.5 ${
                periodType === 'week'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>সাপ্তাহিক হিসাব ({weeklySummaries.length}টি সপ্তাহ)</span>
            </button>
            <button
              type="button"
              id="period-toggle-month-btn"
              onClick={() => setPeriodType('month')}
              className={`px-3.5 py-1.5 rounded-lg text-xs sm:text-sm font-black transition cursor-pointer flex items-center gap-1.5 ${
                periodType === 'month'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100'
              }`}
            >
              <CalendarDays className="w-4 h-4" />
              <span>মাসিক হিসাব ({monthlySummaries.length}টি মাস)</span>
            </button>
          </div>

          {/* View format & Scroll Helper Controls */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                id="layout-scroll-btn"
                onClick={() => setCardLayout('scroll')}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  cardLayout === 'scroll'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
                title="কার্ড স্ক্রোল ফরম্যাট"
              >
                স্ক্রোল কার্ড
              </button>
              <button
                type="button"
                id="layout-grid-btn"
                onClick={() => setCardLayout('grid')}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  cardLayout === 'grid'
                    ? 'bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
                title="গ্রিড ফরম্যাট"
              >
                গ্রিড ভিউ
              </button>
            </div>

            {/* Left / Right Carousel Arrow Buttons */}
            {cardLayout === 'scroll' && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  id="scroll-cards-left-btn"
                  onClick={() => handleScroll('left')}
                  className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center transition cursor-pointer border border-slate-200 dark:border-slate-700 shadow-xs active:scale-95"
                  title="বামে স্ক্রোল করুন"
                  aria-label="Scroll left"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  id="scroll-cards-right-btn"
                  onClick={() => handleScroll('right')}
                  className="w-8 h-8 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 flex items-center justify-center transition cursor-pointer border border-slate-200 dark:border-slate-700 shadow-xs active:scale-95"
                  title="ডানে স্ক্রোল করুন"
                  aria-label="Scroll right"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Scroll Instructions badge for users */}
        {cardLayout === 'scroll' && activePeriods.length > 1 && (
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-2 px-1">
            <span className="flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping"></span>
              মাউস বা আঙুল দিয়ে ডানে-বামে কার্ডগুলো স্ক্রোল (Swipe) করুন
            </span>
            <span className="font-semibold">মোট {activePeriods.length}টি কার্ড</span>
          </div>
        )}

        {/* Card Deck: Scrollable horizontal carousel OR responsive grid */}
        <div
          ref={scrollContainerRef}
          className={
            cardLayout === 'scroll'
              ? 'flex gap-4 overflow-x-auto pt-3 pb-4 px-1 snap-x snap-mandatory scrollbar-thin scroll-smooth overscroll-x-contain'
              : 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-3'
          }
          style={cardLayout === 'scroll' ? { WebkitOverflowScrolling: 'touch' } : {}}
        >
          {activePeriods.map((period, idx) => {
            const isExpanded = expandedCardKey === period.key;
            const avgPerDay = period.daysCount > 0 ? Math.round(period.totalSales / period.daysCount) : 0;

            return (
              <div
                key={period.key}
                id={`card-${period.key}`}
                className={`${
                  cardLayout === 'scroll'
                    ? 'w-[320px] sm:w-[360px] md:w-[380px] shrink-0 snap-start'
                    : 'w-full'
                } bg-slate-50 dark:bg-slate-800/90 rounded-2xl p-4 sm:p-5 border ${
                  period.isCurrent
                    ? 'border-blue-500/80 shadow-md ring-1 ring-blue-500/30'
                    : 'border-slate-200 dark:border-slate-700/80 shadow-sm'
                } flex flex-col justify-between transition-all hover:shadow-lg relative overflow-hidden`}
              >
                {/* Background accent glow */}
                <div
                  className={`absolute -top-12 -right-12 w-32 h-32 rounded-full blur-2xl pointer-events-none opacity-20 ${
                    period.isCurrent ? 'bg-blue-500' : 'bg-amber-500'
                  }`}
                />

                {/* Card Top Header */}
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-black bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                      <CalendarRange className="w-3.5 h-3.5" />
                      <span>{period.type === 'week' ? `সপ্তাহ #${activePeriods.length - idx}` : 'মাসিক'}</span>
                    </span>

                    {period.isCurrent && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700 flex items-center gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                        চলতি সময়
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="text-base font-black text-slate-900 dark:text-slate-100 leading-snug">
                      {period.title}
                    </h3>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                      {period.subtitle}
                    </p>
                  </div>
                </div>

                {/* Primary Metrics: Total Sales & Total Items */}
                <div className="my-4 p-3 bg-white dark:bg-slate-900/90 rounded-xl border border-slate-200/80 dark:border-slate-800 space-y-2.5 shadow-xs">
                  {/* Total Sales Amount */}
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <TrendingUp className="w-4 h-4 text-emerald-500" />
                      মোট বিক্রয় টাকা:
                    </span>
                    <span className="text-lg sm:text-xl font-black text-emerald-600 dark:text-emerald-400">
                      ৳ {money(period.totalSales)}
                    </span>
                  </div>

                  <div className="border-t border-slate-100 dark:border-slate-800" />

                  {/* Total Items Sold */}
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                      <Package className="w-4 h-4 text-blue-500" />
                      মোট বিক্রিত পণ্য:
                    </span>
                    <span className="text-base sm:text-lg font-black text-blue-600 dark:text-blue-400">
                      {money(period.totalItems)} <span className="text-xs text-slate-500">পিস</span>
                    </span>
                  </div>
                </div>

                {/* Secondary Meta: Memos, Days, Average */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs py-2 bg-slate-100/70 dark:bg-slate-900/50 rounded-xl border border-slate-200/60 dark:border-slate-800/60">
                  <div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-bold">মোট মেমো</div>
                    <div className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">
                      {period.totalMemos} টি
                    </div>
                  </div>
                  <div className="border-x border-slate-200 dark:border-slate-800">
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-bold">হিসাবভুক্ত দিন</div>
                    <div className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">
                      {period.daysCount} দিন
                    </div>
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-bold">দৈনিক গড়</div>
                    <div className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">
                      ৳ {money(avgPerDay)}
                    </div>
                  </div>
                </div>

                {/* Top Selling Products in this Period */}
                <div className="mt-3 space-y-1.5">
                  <div className="text-[11px] font-bold text-slate-600 dark:text-slate-400 flex items-center justify-between">
                    <span>শীর্ষ বিক্রিত পণ্যসমূহ (Top Items)</span>
                    <span className="text-[10px] text-slate-400">{period.topProducts.length}টি প্রধান</span>
                  </div>
                  {period.topProducts.length > 0 ? (
                    <div className="space-y-1">
                      {period.topProducts.map((tp, rank) => (
                        <div
                          key={tp.id}
                          className="flex items-center justify-between text-xs px-2.5 py-1.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200/60 dark:border-slate-800/80"
                        >
                          <div className="flex items-center gap-1.5 truncate max-w-[65%]">
                            <span className="w-4 h-4 rounded-full bg-slate-200 dark:bg-slate-800 text-[10px] font-black text-slate-600 dark:text-slate-300 flex items-center justify-center shrink-0">
                              {rank + 1}
                            </span>
                            <span className="font-bold text-slate-800 dark:text-slate-200 truncate" title={tp.name}>
                              {tp.name}
                            </span>
                          </div>
                          <div className="text-right shrink-0">
                            <span className="font-extrabold text-blue-600 dark:text-blue-400">{tp.quantity}</span>
                            <span className="text-[10px] text-slate-500 dark:text-slate-400 ml-1">(৳{money(tp.amount)})</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-slate-400 italic py-2 text-center bg-white dark:bg-slate-900 rounded-lg">
                      এই সময়ে এখনো কোনো পণ্য বিক্রির হিসাব নেই
                    </div>
                  )}
                </div>

                {/* Category Breakdown Mini Pills */}
                {period.categoryTotals.length > 0 && (
                  <div className="mt-3 pt-2 border-t border-slate-200/70 dark:border-slate-800/70">
                    <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1.5">
                      ক্যাটাগরি বিক্রয় শেয়ার:
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {period.categoryTotals.slice(0, 4).map((c) => (
                        <span
                          key={c.categoryKey}
                          className="text-[10px] font-bold px-2 py-0.5 rounded-md border flex items-center gap-1"
                          style={{
                            borderColor: c.color,
                            color: c.color,
                            backgroundColor: `${c.color}15`,
                          }}
                        >
                          <span>{c.nameBn}</span>
                          <span className="font-extrabold">{c.quantity}টি</span>
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Card Action Buttons: View Day-by-Day Breakdown */}
                <div className="mt-4 pt-3 border-t border-slate-200/80 dark:border-slate-800 space-y-2">
                  <button
                    type="button"
                    onClick={() => setExpandedCardKey(isExpanded ? null : period.key)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-200/80 hover:bg-slate-300 dark:bg-slate-700/80 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer active:scale-95"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-500" />
                    <span>{isExpanded ? 'দিনভিত্তিক তালিকা লুকান' : 'দিনভিত্তিক বিস্তারিত দেখুন'}</span>
                  </button>

                  {/* Expanded Day Breakdown Table */}
                  {isExpanded && (
                    <div className="p-2.5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 mt-2 animate-fadeIn">
                      <div className="text-xs font-bold text-slate-700 dark:text-slate-300 pb-1 border-b border-slate-200 dark:border-slate-800 flex justify-between">
                        <span>তারিখ ও মেমো</span>
                        <span>পিস ও টাকা</span>
                      </div>
                      {period.dayBreakdown.length > 0 ? (
                        <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 text-xs scrollbar-thin">
                          {period.dayBreakdown.map((d) => (
                            <div
                              key={d.date}
                              className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/80 hover:bg-blue-50 dark:hover:bg-slate-700/50 transition cursor-pointer group"
                              onClick={() => {
                                onSelectDate(d.date);
                                onSwitchToCounter();
                                onToast(`${formatDisplayDate(d.date)}-এর দৈনিক কাউন্টারে লোড হয়েছে`);
                              }}
                              title="এই দিনের বিস্তারিত দেখতে কাউন্টারে যান"
                            >
                              <div>
                                <div className="font-extrabold text-slate-800 dark:text-slate-200 group-hover:text-blue-600 dark:group-hover:text-blue-400">
                                  {formatDisplayDate(d.date)}
                                </div>
                                <div className="text-[10px] text-slate-400">
                                  মেমো: {d.memos} টি
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-extrabold text-emerald-600 dark:text-emerald-400">
                                  ৳ {money(d.sales)}
                                </div>
                                <div className="text-[10px] text-blue-600 dark:text-blue-400 font-bold">
                                  {d.items} পিস →
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-xs text-slate-400 italic py-2 text-center">
                          কোনো দিনের ডাটা পাওয়া যায়নি
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Helpful Testing / Demo Past Data Notice if only 1 day is recorded */}
      {Object.keys(dateSummaries).length <= 2 && onAddSampleHistory && (
        <section className="bg-amber-50 dark:bg-amber-950/40 rounded-2xl p-4 border border-amber-200 dark:border-amber-800/60 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="space-y-0.5">
            <div className="font-black text-amber-950 dark:text-amber-300 text-sm flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>সাপ্তাহিক ও মাসিক কার্ড পরিপূর্ণ দেখতে চান?</span>
            </div>
            <p className="text-xs text-amber-800 dark:text-amber-300/90 leading-relaxed">
              বর্তমানে আপনার অ্যাপে কেবল আজকের বা অল্প দিনের হিসাব সংরক্ষিত আছে। বিগত কয়েক সপ্তাহের বিভিন্ন পণ্য বিক্রির নমুনা ডাটা যোগ করে আপনি পুরো স্ক্রোলিং কার্ড ফরম্যাটটি পরীক্ষা করতে পারেন।
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              id="add-sample-history-btn"
              onClick={onAddSampleHistory}
              className="px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 active:bg-amber-800 text-white font-bold text-xs sm:text-sm shadow-xs transition active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4 text-amber-200" />
              <span>নমুনা ডাটা লোড করুন</span>
            </button>
            {hasSampleData && onClearSampleHistory && (
              <button
                type="button"
                id="clear-sample-history-btn"
                onClick={onClearSampleHistory}
                className="px-3 py-2 rounded-xl bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs transition cursor-pointer"
              >
                নমুনা মুছুন
              </button>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
