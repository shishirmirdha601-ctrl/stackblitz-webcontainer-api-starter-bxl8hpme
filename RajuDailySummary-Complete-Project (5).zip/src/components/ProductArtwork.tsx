import React from 'react';
import { Product } from '../data/products';

interface ProductArtworkProps {
  product: Product;
  customImage?: string;
  className?: string;
}

export const ProductArtwork: React.FC<ProductArtworkProps> = ({
  product,
  customImage,
  className = 'w-full h-full',
}) => {
  // If user provided a real uploaded photo, render it
  if (customImage) {
    return (
      <img
        src={customImage}
        alt={product.name}
        className={`${className} object-cover object-center`}
        referrerPolicy="no-referrer"
        loading="lazy"
      />
    );
  }

  // Otherwise, render a high-fidelity, customized visual packaging graphic based on product ID
  const pId = product.id;
  const name = product.name;

  // 1. Sauces (IDs 22 to 29)
  if (pId >= 22 && pId <= 29) {
    const isNaga = pId === 29;
    const isPata = pId === 28;
    const isBig = pId >= 25 && pId <= 27;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none ${
        isNaga
          ? 'bg-gradient-to-b from-red-600 to-amber-800 text-white'
          : isPata
          ? 'bg-gradient-to-b from-emerald-600 to-teal-800 text-white'
          : 'bg-gradient-to-b from-rose-500 via-red-600 to-red-800 text-white'
      }`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isNaga ? '🔥 HOT' : isPata ? '🌿 FRESH' : '🍅 PREMIUM'}</span>
          <span>{isBig ? 'GALLON' : 'BOTTLE'}</span>
        </div>

        {/* Realistic Bottle/Jar SVG */}
        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 120" className="w-20 h-24 drop-shadow-md">
            {/* Cap */}
            <rect x="42" y="10" width="16" height="10" rx="2" fill="#FBBF24" />
            {/* Neck */}
            <path d="M44 20 L56 20 L60 38 L40 38 Z" fill="#991B1B" />
            {/* Body */}
            <rect x="25" y="36" width="50" height="74" rx="8" fill={isNaga ? '#7F1D1D' : isPata ? '#065F46' : '#B91C1C'} />
            {/* Gloss reflection */}
            <path d="M30 42 L34 42 L34 100 L30 100 Z" fill="white" opacity="0.2" rx="2" />
            {/* Front Label */}
            <rect x="28" y="52" width="44" height="42" rx="4" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1" />
            <circle cx="50" cy="64" r="7" fill={isNaga ? '#DC2626' : isPata ? '#10B981' : '#EF4444'} />
            <text x="50" y="86" fontSize="7" fontWeight="bold" textAnchor="middle" fill="#78350F">
              {name.split(' ')[0]}
            </text>
          </svg>
        </div>

        {/* Product Tag */}
        <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 2. Chocolates & Candies (IDs 10 to 21)
  if (pId >= 10 && pId <= 21) {
    const isLoveBox = pId === 14;
    const isCaramel = pId === 16;
    const isBelgio = pId >= 17 && pId <= 19;
    const isStrawberry = pId === 19;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none ${
        isLoveBox
          ? 'bg-gradient-to-b from-pink-500 via-rose-600 to-red-700 text-white'
          : isStrawberry
          ? 'bg-gradient-to-b from-rose-400 to-pink-600 text-white'
          : isCaramel
          ? 'bg-gradient-to-b from-amber-600 via-yellow-700 to-amber-900 text-white'
          : 'bg-gradient-to-b from-amber-800 via-amber-900 to-stone-900 text-amber-100'
      }`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isLoveBox ? '❤️ GIFT' : isBelgio ? 'BELGIAN' : 'CHOCO'}</span>
          <span>BAR / BOX</span>
        </div>

        {/* Realistic Chocolate SVG */}
        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {isLoveBox ? (
              // Heart shape for love box
              <path
                d="M50 85 C20 60 10 40 10 25 C10 12 25 5 40 15 C46 20 50 25 50 25 C50 25 54 20 60 15 C75 5 90 12 90 25 C90 40 80 60 50 85 Z"
                fill="#BE123C"
                stroke="#F43F5E"
                strokeWidth="2"
              />
            ) : (
              // Chocolate Bar with Foil wrapper
              <g>
                <rect x="20" y="20" width="60" height="75" rx="6" fill="#451A03" />
                {/* Chocolate Grid segments */}
                <rect x="26" y="26" width="21" height="18" rx="2" fill="#78350F" />
                <rect x="53" y="26" width="21" height="18" rx="2" fill="#78350F" />
                <rect x="26" y="48" width="21" height="18" rx="2" fill="#78350F" />
                <rect x="53" y="48" width="21" height="18" rx="2" fill="#78350F" />
                {/* Golden Foil Wrapper bottom */}
                <path d="M18 62 L82 62 L82 96 C82 99 79 101 76 101 L24 101 C21 101 18 99 18 96 Z" fill="#D97706" stroke="#FBBF24" strokeWidth="1" />
                <rect x="24" y="70" width="52" height="20" rx="3" fill="#FEF3C7" />
                <text x="50" y="83" fontSize="8" fontWeight="bold" textAnchor="middle" fill="#78350F">
                  {name.split(' ')[0]}
                </text>
              </g>
            )}
          </svg>
        </div>

        <div className="w-full text-center bg-black/35 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 3. Edible Gel, Pudding, Lychee (IDs 3, 4, 5, 7, 8, 9)
  if (pId === 3 || pId === 4 || pId === 5 || pId === 7 || pId === 8 || pId === 9) {
    const isPudding = pId === 7;
    const isLychee = pId === 8 || pId === 9;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none ${
        isPudding
          ? 'bg-gradient-to-b from-amber-400 via-orange-400 to-yellow-500 text-slate-900'
          : isLychee
          ? 'bg-gradient-to-b from-pink-400 via-rose-500 to-pink-600 text-white'
          : 'bg-gradient-to-b from-sky-400 via-cyan-500 to-blue-600 text-white'
      }`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isPudding ? '🍮 DESSERT' : isLychee ? '🍒 LYCHEE' : '🍧 JELLY'}</span>
          <span>SWEET</span>
        </div>

        {/* Jelly / Pudding Cup SVG */}
        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {/* Cup Body */}
            <path d="M22 35 L78 35 L70 90 L30 90 Z" fill={isPudding ? '#FDE68A' : isLychee ? '#FDA4AF' : '#BAE6FD'} stroke="white" strokeWidth="2" />
            {/* Caramel / Flavor Top */}
            <ellipse cx="50" cy="35" rx="28" ry="8" fill={isPudding ? '#B45309' : isLychee ? '#E11D48' : '#0284C7'} />
            <ellipse cx="50" cy="35" rx="24" ry="6" fill={isPudding ? '#D97706' : isLychee ? '#F43F5E' : '#38BDF8'} />
            {/* Cup label */}
            <rect x="34" y="52" width="32" height="24" rx="3" fill="white" opacity="0.9" />
            <text x="50" y="67" fontSize="7" fontWeight="bold" textAnchor="middle" fill="#0F172A">
              {name.split(' ')[0]}
            </text>
          </svg>
        </div>

        <div className="w-full text-center bg-black/25 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 4. Drinks & Icebar (IDs 0, 1, 2, 6)
  if (pId === 0 || pId === 1 || pId === 2 || pId === 6) {
    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-cyan-500 via-blue-500 to-indigo-700 text-white`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>❄️ COOL</span>
          <span>DRINK</span>
        </div>

        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {/* Ice Bar Tube / Can */}
            <rect x="36" y="15" width="28" height="85" rx="14" fill="#E0F2FE" stroke="#0284C7" strokeWidth="2" />
            <rect x="39" y="35" width="22" height="50" rx="4" fill="#0284C7" />
            <text x="50" y="60" fontSize="7" fontWeight="black" textAnchor="middle" fill="white">
              ICE
            </text>
            {/* Highlights */}
            <path d="M42 22 L44 22 L44 90 L42 90 Z" fill="white" opacity="0.6" rx="1" />
          </svg>
        </div>

        <div className="w-full text-center bg-black/25 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 5. Chutney & Pickles (IDs 30 to 33)
  if (pId >= 30 && pId <= 33) {
    const isJolpai = pId === 31;
    const isMango = pId === 32;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-emerald-600 via-green-700 to-teal-900 text-white`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isJolpai ? '🫒 OLIVE' : isMango ? '🥭 MANGO' : '🌶️ PICKLE'}</span>
          <span>SPICY</span>
        </div>

        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {/* Pickle Jar */}
            <rect x="35" y="15" width="30" height="10" rx="3" fill="#FBBF24" />
            <rect x="25" y="25" width="50" height="70" rx="8" fill="#14532D" stroke="#86EFAC" strokeWidth="1.5" />
            {/* Pickles inside */}
            <circle cx="40" cy="50" r="8" fill="#15803D" />
            <circle cx="60" cy="55" r="7" fill="#166534" />
            <circle cx="48" cy="72" r="9" fill="#15803D" />
            {/* Jar Label */}
            <rect x="28" y="45" width="44" height="30" rx="3" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="1" />
            <text x="50" y="62" fontSize="7" fontWeight="black" textAnchor="middle" fill="#78350F">
              {name.split(' ')[0]}
            </text>
          </svg>
        </div>

        <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 6. Toys & Gems (IDs 34 to 37)
  if (pId >= 34 && pId <= 37) {
    const isFeeder = pId === 35;
    const isGlasses = pId === 37;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-indigo-500 via-purple-600 to-pink-600 text-white`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isFeeder ? '🍼 FEEDER' : isGlasses ? '👓 GLASSES' : '🍬 GEMS / TOY'}</span>
          <span>FUN</span>
        </div>

        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {isFeeder ? (
              // Baby Feeder
              <g>
                <path d="M45 12 C45 8 55 8 55 12 L52 24 L48 24 Z" fill="#FDE047" />
                <rect x="36" y="24" width="28" height="8" rx="2" fill="#EC4899" />
                <rect x="38" y="32" width="24" height="60" rx="6" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="2" />
                {/* Feeder measurement lines */}
                <line x1="42" y1="45" x2="48" y2="45" stroke="#3B82F6" strokeWidth="1.5" />
                <line x1="42" y1="55" x2="52" y2="55" stroke="#3B82F6" strokeWidth="1.5" />
                <line x1="42" y1="65" x2="48" y2="65" stroke="#3B82F6" strokeWidth="1.5" />
                <line x1="42" y1="75" x2="52" y2="75" stroke="#3B82F6" strokeWidth="1.5" />
              </g>
            ) : (
              // Colorful gems or glasses
              <g>
                <circle cx="35" cy="45" r="14" fill="#EF4444" stroke="white" strokeWidth="2" />
                <circle cx="65" cy="45" r="14" fill="#3B82F6" stroke="white" strokeWidth="2" />
                <circle cx="50" cy="70" r="14" fill="#10B981" stroke="white" strokeWidth="2" />
                <text x="35" y="48" fontSize="7" fontWeight="bold" textAnchor="middle" fill="white">G</text>
                <text x="65" y="48" fontSize="7" fontWeight="bold" textAnchor="middle" fill="white">E</text>
                <text x="50" y="73" fontSize="7" fontWeight="bold" textAnchor="middle" fill="white">M</text>
              </g>
            )}
          </svg>
        </div>

        <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 7. Snacks, Toast, Chira Vaja (IDs 38 to 40)
  if (pId >= 38 && pId <= 40) {
    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-amber-500 via-orange-600 to-amber-800 text-white`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>🍪 CRISPY</span>
          <span>SNACKS</span>
        </div>

        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {/* Toast Rusks */}
            <rect x="25" y="30" width="50" height="40" rx="8" fill="#D97706" stroke="#B45309" strokeWidth="2" />
            <rect x="28" y="45" width="44" height="40" rx="8" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
            {/* Toast pores */}
            <circle cx="38" cy="55" r="2" fill="#78350F" opacity="0.6" />
            <circle cx="50" cy="62" r="2" fill="#78350F" opacity="0.6" />
            <circle cx="62" cy="56" r="2" fill="#78350F" opacity="0.6" />
            <circle cx="44" cy="72" r="2" fill="#78350F" opacity="0.6" />
            <circle cx="58" cy="74" r="2" fill="#78350F" opacity="0.6" />
          </svg>
        </div>

        <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // 8. Semai (IDs 41 & 42)
  if (pId >= 41 && pId <= 42) {
    const isLaccha = pId === 41;

    return (
      <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-purple-600 via-indigo-700 to-purple-900 text-white`}>
        <div className="w-full flex justify-between items-center text-[9px] font-bold opacity-80 uppercase tracking-wider px-1">
          <span>{isLaccha ? '🍜 LACCHA' : '🌾 VERMICELLI'}</span>
          <span>PREMIUM</span>
        </div>

        <div className="relative my-auto flex items-center justify-center">
          <svg viewBox="0 0 100 110" className="w-20 h-22 drop-shadow-md">
            {/* Semai Packet */}
            <rect x="22" y="20" width="56" height="75" rx="6" fill="#F3E8FF" stroke="#A855F7" strokeWidth="2" />
            {/* Noodle texture */}
            <path d="M28 35 Q35 30 42 35 T56 35 T70 35" fill="none" stroke="#EAB308" strokeWidth="1.5" />
            <path d="M28 45 Q35 40 42 45 T56 45 T70 45" fill="none" stroke="#CA8A04" strokeWidth="1.5" />
            <path d="M28 55 Q35 50 42 55 T56 55 T70 55" fill="none" stroke="#EAB308" strokeWidth="1.5" />
            {/* Center Label */}
            <rect x="26" y="65" width="48" height="22" rx="3" fill="#9333EA" />
            <text x="50" y="79" fontSize="7" fontWeight="bold" textAnchor="middle" fill="white">
              {isLaccha ? 'লাচ্ছা সেমাই' : 'ভার্মিসিলি'}
            </text>
          </svg>
        </div>

        <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
          {name}
        </div>
      </div>
    );
  }

  // Generic fallback
  return (
    <div className={`${className} flex flex-col items-center justify-between p-2 select-none bg-gradient-to-b from-slate-700 to-slate-900 text-white`}>
      <span className="text-[9px] font-bold opacity-75">আইটেম #{pId + 1}</span>
      <div className="text-xl font-bold">📦</div>
      <div className="w-full text-center bg-black/30 backdrop-blur-xs py-0.5 rounded-md text-[11px] font-black truncate px-1">
        {name}
      </div>
    </div>
  );
};
