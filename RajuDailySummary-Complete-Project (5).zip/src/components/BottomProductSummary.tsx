import React, { useState } from 'react';
import { Product } from '../data/products';
import { UnlistedItem } from '../types';
import { PackageCheck, Copy, Check, FileText, Share2 } from 'lucide-react';

interface BottomProductSummaryProps {
  products: Product[];
  daySum: number[];
  unlistedItems?: UnlistedItem[];
  currentDate: string;
  onCopyToast: (msg: string) => void;
}

export const BottomProductSummary: React.FC<BottomProductSummaryProps> = ({
  products,
  daySum,
  unlistedItems = [],
  currentDate,
  onCopyToast,
}) => {
  const [copied, setCopied] = useState(false);
  const [numMode, setNumMode] = useState<'en' | 'bn'>('en');

  // Format single digit with leading zero e.g. 2 -> "02", 100 -> "100"
  const formatQty = (qty: number, mode: 'en' | 'bn') => {
    const raw = qty < 10 ? `0${qty}` : `${qty}`;
    if (mode === 'bn') {
      const engToBangla: Record<string, string> = {
        '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
        '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
      };
      return raw.split('').map((c) => engToBangla[c] || c).join('');
    }
    return raw;
  };

  // Collect items with quantity > 0
  const activeItems = products
    .map((p) => {
      const qty = daySum[p.id] || 0;
      return {
        id: `prod-${p.id}`,
        name: p.name,
        groupColor: p.groupColor,
        quantity: qty,
        amount: qty * p.price,
        isUnlisted: false,
      };
    })
    .filter((item) => item.quantity > 0);

  // Also include unlisted items with quantity > 0
  const activeUnlisted = unlistedItems
    .filter((u) => u.quantity > 0)
    .map((u) => ({
      id: u.id,
      name: `${u.name} (অন্যান্য)`,
      groupColor: '#e0e7ff', // indigo-100
      quantity: u.quantity,
      amount: u.quantity * u.price,
      isUnlisted: true,
    }));

  const combinedItems = [...activeItems, ...activeUnlisted];

  const totalPieces = combinedItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalAmount = combinedItems.reduce((acc, item) => acc + item.amount, 0);

  // Generate plain text formatted summary e.g.:
  // আইসবার ৪৫ - 100
  // লিচু ৪৫ - 02
  const textSummary = combinedItems
    .map((item) => `${item.name} - ${formatQty(item.quantity, numMode)}`)
    .join('\n');

  const fullShareText = `📋 Raju Daily Summary (${currentDate})\n${textSummary}\n\nমোট পরিমাণ: ${totalPieces} পিস | মোট টাকা: ${totalAmount.toLocaleString()} টাকা`;

  const handleCopy = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(fullShareText);
      } else {
        const textarea = document.createElement('textarea');
        textarea.value = fullShareText;
        document.body.appendChild(textarea);
        textarea.select();
        document.execCommand('copy');
        document.body.removeChild(textarea);
      }
      setCopied(true);
      onCopyToast('সামারি টেক্সট ক্লিপবোর্ডে কপি করা হয়েছে!');
      setTimeout(() => setCopied(false), 2500);
    } catch {
      onCopyToast('কপি করতে সমস্যা হয়েছে, টেক্সট সিলেক্ট করে কপি করুন।');
    }
  };

  return (
    <section
      id="bottom-product-summary"
      className="bg-white dark:bg-slate-900 rounded-2xl p-3.5 sm:p-5 shadow-sm border-2 border-amber-300/80 dark:border-amber-500/40 space-y-4 transition-colors"
    >
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2.5 border-b border-slate-200 dark:border-slate-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-black shadow-xs shrink-0">
            <PackageCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-black text-slate-900 dark:text-slate-100 leading-tight">
              📦 আজকের মোট সামারি (পণ্যভিত্তিক তালিকা)
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              ফরম্যাট: <strong className="text-amber-800 dark:text-amber-400 font-bold">আইসবার - 100, লিচু - 02</strong> এমন আকারে
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Bengali / English numbers switch */}
          <div className="inline-flex rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-100 dark:bg-slate-800 p-0.5 text-xs font-bold">
            <button
              type="button"
              onClick={() => setNumMode('en')}
              className={`px-2 py-1 rounded-md transition cursor-pointer ${
                numMode === 'en'
                  ? 'bg-white dark:bg-slate-900 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="ইংলিশ সংখ্যা (02, 100)"
            >
              02 / 100
            </button>
            <button
              type="button"
              onClick={() => setNumMode('bn')}
              className={`px-2 py-1 rounded-md transition cursor-pointer ${
                numMode === 'bn'
                  ? 'bg-white dark:bg-slate-900 text-slate-950 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
              title="বাংলা সংখ্যা (০২, ১০০)"
            >
              ০২ / ১০০
            </button>
          </div>

          {activeItems.length > 0 && (
            <button
              type="button"
              onClick={handleCopy}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition active:scale-95 cursor-pointer shadow-xs ${
                copied
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 dark:hover:bg-amber-400 text-white dark:text-slate-950'
              }`}
              title="সম্পূর্ণ সামারি টেক্সট হোয়াটসঅ্যাপ বা মেসেজে পাঠাতে কপি করুন"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-300 dark:text-slate-950" />
                  <span>কপি হয়েছে</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5 text-amber-400 dark:text-slate-950" />
                  <span>সামারি কপি করুন</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {combinedItems.length === 0 ? (
        <div className="py-6 text-center text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 space-y-1">
          <FileText className="w-7 h-7 mx-auto text-slate-400 dark:text-slate-500" />
          <p className="text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300">
            আজ এখনো কোনো পণ্যের বিক্রয় যোগ করা হয়নি।
          </p>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
            উপরের টেবিলে Quantity লিখে <strong>"যোগ"</strong> বা <strong>"সব যোগ করুন"</strong> বাটনে চাপলে এখানে স্বয়ংক্রিয়ভাবে <strong>আইসবার - 100, লিচু - 02</strong> আকারে তালিকা তৈরি হবে।
          </p>
        </div>
      ) : (
        <div className="space-y-3.5">
          {/* Badges / Cards Grid formatted as Requested: 'নাম - পরিমাণ' */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
            {combinedItems.map((item) => (
              <div
                key={item.id}
                style={{ backgroundColor: item.groupColor }}
                className="p-2.5 rounded-xl border border-black/15 shadow-2xs flex flex-col justify-between transition hover:shadow-sm"
              >
                <div className="text-xs font-black text-slate-950 truncate" title={item.name}>
                  {item.name}
                </div>
                <div className="mt-1 flex items-baseline justify-between">
                  <span className="text-xs font-extrabold text-slate-800">পরিমাণ:</span>
                  <span className="text-sm font-black bg-white/95 text-slate-950 px-2 py-0.5 rounded-md border border-black/10 shadow-2xs tracking-wider">
                    - {formatQty(item.quantity, numMode)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Quick Copy / Plain Text Box */}
          <div className="bg-slate-50 dark:bg-slate-800/70 rounded-xl p-3 border border-slate-300 dark:border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-300 font-bold">
              <span className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200">
                <Share2 className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                মেসেজ / হোয়াটসঅ্যাপে পাঠানোর টেক্সট:
              </span>
              <span className="text-slate-500 dark:text-slate-400">
                মোট {combinedItems.length}টি পণ্য • {totalPieces} পিস
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-lg border border-slate-200 dark:border-slate-700 font-mono text-xs sm:text-sm text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed select-all">
              {textSummary}
            </div>

            <div className="flex items-center justify-between text-xs font-extrabold text-slate-900 dark:text-slate-100 pt-1">
              <span>সর্বমোট বিক্রয়:</span>
              <span className="text-amber-900 dark:text-amber-200 bg-amber-100 dark:bg-amber-950/60 border border-transparent dark:border-amber-700/50 px-2 py-0.5 rounded">
                {totalPieces} পিস | {totalAmount.toLocaleString()} টাকা
              </span>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
