import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Users,
  Receipt,
  Percent,
  Calculator,
  Copy,
  Check,
  Printer,
  Trash2,
  HelpCircle,
  ArrowRight,
  RefreshCw,
  Info,
  DollarSign
} from 'lucide-react';
import type { SplitterChatMessage, SplitterResult, SplitBillResponse } from '../types/splitter';

interface BillSplitterChatProps {
  currentDayTotal: number;
  currentDate: string;
  onToast: (msg: string) => void;
}

const INITIAL_MESSAGES: SplitterChatMessage[] = [
  {
    id: 'welcome-1',
    sender: 'assistant',
    timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
    text: 'স্বাগতম! আমি আপনার **Gemini AI বিল ও খরচ স্প্লিটার**। আপনি যেকোনো সাধারণ ভাষায় বিল বা খরচের বিভাজন লিখে পাঠাতে পারেন। যেমন:\n\n• *"Split this bill among 3 people, one owes 20% more"*\n• *"৪ জনের মধ্যে ৩৫০০ টাকা ভাগ করুন, একজন ৩০% দিবে এবং ১০% ভ্যাট যোগ হবে"*\n• *"আজকের মেমো মোট ৩ জনের মাঝে সমান ভাগ করুন"*\n\nআমি স্বয়ংক্রিয়ভাবে প্রত্যেকের জন্য নির্ভুল বেস বিল ও আনুপাতিক ট্যাক্স হিসাব করে দেব।',
    result: {
      title: 'উদাহরণ: ৩ জনের বিল বিভাজন (১ জন ২০% বেশি ও ৫% ট্যাক্স)',
      currency: '৳',
      subtotal: 1500,
      taxPercent: 5,
      taxAmount: 75,
      tipOrServicePercent: 0,
      tipOrServiceAmount: 0,
      grandTotal: 1575,
      taxCalculationMethod: 'প্রত্যেকের বেস বিল অনুপাত অনুযায়ী ভ্যাট বা ট্যাক্স আনুপাতিক হারে বণ্টিত হয়েছে (ন্যায্য আনুপাতিক নীতি)।',
      replyMessage: 'এখানে একটি নমুনা বিভাজন দেওয়া হলো: ১৫০০ টাকার বিলে ৫% ট্যাক্স সহ ৩ জনের মাঝে একজন ২০% বেশি অংশীদার হলে হিসাব কেমন হবে দেখুন:',
      participants: [
        {
          id: 'p1',
          name: 'ব্যক্তি ১ (+২০% বেশি)',
          baseShare: 562.5,
          taxShare: 28.13,
          totalToPay: 590.63,
          percentageOfTotal: 37.5,
          shareRatioDescription: 'মূল অংশ + ২০% অতিরিক্ত এবং আনুপাতিক কর',
          note: 'অন্যদের তুলনায় ২০% বেশি দায়ভার'
        },
        {
          id: 'p2',
          name: 'ব্যক্তি ২ (সাধারণ অংশ)',
          baseShare: 468.75,
          taxShare: 23.44,
          totalToPay: 492.19,
          percentageOfTotal: 31.25,
          shareRatioDescription: 'সাধারণ অংশ এবং আনুপাতিক কর'
        },
        {
          id: 'p3',
          name: 'ব্যক্তি ৩ (সাধারণ অংশ)',
          baseShare: 468.75,
          taxShare: 23.44,
          totalToPay: 492.18,
          percentageOfTotal: 31.25,
          shareRatioDescription: 'সাধারণ অংশ এবং আনুপাতিক কর'
        }
      ],
      suggestions: [
        'আজকের মেমোর মোট বিল ৫ জনের মাঝে ভাগ করুন',
        '১০% ভ্যাট যোগ করে আবার হিসাব করুন',
        '৪ জনের মধ্যে সমান ভাগ করুন'
      ]
    }
  }
];

const PRESET_PROMPTS = [
  'Split this bill among 3 people, one owes 20% more',
  'আজকের মোট বিল ৪ জনের মাঝে সমান ভাগ করুন, ৫% ট্যাক্স সহ',
  'মোট ৩,০০০ টাকা ৩ জন ভাগ করবে: ১ জন ২৫% বেশি দিবে, ১০% ভ্যাট',
  '৫ বন্ধু মিলে ৫,২০০ টাকা বিল: একজন অর্ধেক (৫০%) দিবে, বাকিরা সমান'
];

export const BillSplitterChat: React.FC<BillSplitterChatProps> = ({
  currentDayTotal,
  currentDate,
  onToast
}) => {
  const [messages, setMessages] = useState<SplitterChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('hubhub-splitter-chat-history');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {}
    return INITIAL_MESSAGES;
  });

  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Save chat history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('hubhub-splitter-chat-history', JSON.stringify(messages));
    } catch {}
  }, [messages]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    const userMessage: SplitterChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
      text
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputText('');
    setIsLoading(true);

    try {
      // Build lightweight conversation history for Gemini context
      const historyContext = messages.slice(-4).map((m) => ({
        role: m.sender === 'user' ? ('user' as const) : ('model' as const),
        text: m.text
      }));

      const res = await fetch('/api/split-bill', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          contextBillAmount: currentDayTotal > 0 ? currentDayTotal : 1500,
          history: historyContext
        })
      });

      if (!res.ok) {
        throw new Error(`Server returned status ${res.status}`);
      }

      const responseData: SplitBillResponse = await res.json();

      if (responseData.success && responseData.data) {
        const assistantMessage: SplitterChatMessage = {
          id: `assistant-${Date.now()}`,
          sender: 'assistant',
          timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
          text: responseData.data.replyMessage || 'হিসাব সম্পন্ন হয়েছে:',
          result: responseData.data
        };
        setMessages((prev) => [...prev, assistantMessage]);
      } else {
        throw new Error(responseData.error || 'Failed to calculate split');
      }
    } catch (err: any) {
      console.error('Error splitting bill:', err);
      const errorMessage: SplitterChatMessage = {
        id: `error-${Date.now()}`,
        sender: 'assistant',
        timestamp: new Date().toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' }),
        text: 'দুঃখিত, হিসাব করতে কিছুটা সমস্যা হয়েছে। দয়া করে আবার চেষ্টা করুন অথবা অনুরোধটি একটু পরিবর্তন করে লিখুন।',
        error: err.message
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopySummary = (result: SplitterResult, messageId: string) => {
    let summaryText = `📋 *${result.title}*\n`;
    summaryText += `--------------------------\n`;
    summaryText += `বেস বিল (Subtotal): ${result.currency} ${result.subtotal.toLocaleString()}\n`;
    if (result.taxPercent > 0) {
      summaryText += `ভ্যাট/ট্যাক্স (${result.taxPercent}%): ${result.currency} ${result.taxAmount.toLocaleString()}\n`;
    }
    if ((result.tipOrServiceAmount || 0) > 0) {
      summaryText += `সার্ভিস চার্জ / টিপ: ${result.currency} ${(result.tipOrServiceAmount || 0).toLocaleString()}\n`;
    }
    summaryText += `সর্বমোট বিল (Grand Total): ${result.currency} ${result.grandTotal.toLocaleString()}\n\n`;
    summaryText += `👥 *ব্যক্তিভিত্তিক বিভাজন (আনুপাতিক ট্যাক্স সহ):*\n`;

    result.participants.forEach((p, idx) => {
      summaryText += `${idx + 1}. *${p.name}*: ${result.currency} ${p.totalToPay.toLocaleString()}`;
      if (result.taxPercent > 0) {
        summaryText += ` (মূল: ${result.currency}${p.baseShare} + কর: ${result.currency}${p.taxShare})`;
      }
      summaryText += ` [${p.percentageOfTotal}%]\n`;
    });

    summaryText += `--------------------------\n`;
    summaryText += `তারিখ: ${currentDate} | হিসাব তৈরি: Raju Daily Summary AI Splitter`;

    navigator.clipboard.writeText(summaryText).then(() => {
      setCopiedId(messageId);
      onToast('বিল বিভাজন সামারি ক্লিপবোর্ডে কপি করা হয়েছে!');
      setTimeout(() => setCopiedId(null), 2500);
    });
  };

  const handlePrintSlip = (result: SplitterResult) => {
    const printWindow = window.open('', '_blank', 'width=450,height=600');
    if (!printWindow) {
      onToast('পপআপ ব্লক থাকায় প্রিন্ট উইন্ডো খোলা যায়নি। ব্রাউজার পারমিশন দিন।');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${result.title}</title>
          <style>
            body {
              font-family: monospace, sans-serif;
              padding: 20px;
              color: #111;
              max-width: 380px;
              margin: 0 auto;
            }
            .header {
              text-align: center;
              border-bottom: 1px dashed #444;
              padding-bottom: 10px;
              margin-bottom: 15px;
            }
            .title {
              font-size: 16px;
              font-weight: bold;
              margin-bottom: 4px;
            }
            .meta {
              font-size: 12px;
              color: #666;
            }
            .row {
              display: flex;
              justify-content: space-between;
              margin: 4px 0;
              font-size: 13px;
            }
            .total-row {
              border-top: 1px solid #111;
              border-bottom: 1px dashed #111;
              font-weight: bold;
              padding: 6px 0;
              margin: 8px 0;
            }
            .section-title {
              font-weight: bold;
              font-size: 14px;
              margin: 14px 0 8px 0;
              border-bottom: 1px solid #ccc;
              padding-bottom: 2px;
            }
            .person-box {
              border-bottom: 1px dotted #ccc;
              padding: 6px 0;
              font-size: 13px;
            }
            .person-header {
              display: flex;
              justify-content: space-between;
              font-weight: bold;
            }
            .person-sub {
              font-size: 11px;
              color: #555;
            }
            .footer {
              text-align: center;
              font-size: 11px;
              color: #888;
              margin-top: 20px;
              border-top: 1px dashed #444;
              padding-top: 10px;
            }
          </style>
        </head>
        <body>
          <div class="header">
            <div class="title">মেমো ও বিল বিভাজন স্লিপ</div>
            <div class="meta">${result.title}</div>
            <div class="meta">তারিখ: ${currentDate}</div>
          </div>

          <div class="row">
            <span>বেস বিল (Subtotal):</span>
            <span>${result.currency} ${result.subtotal.toLocaleString()}</span>
          </div>
          ${result.taxPercent > 0 ? `
          <div class="row">
            <span>ভ্যাট/ট্যাক্স (${result.taxPercent}%):</span>
            <span>${result.currency} ${result.taxAmount.toLocaleString()}</span>
          </div>` : ''}
          ${(result.tipOrServiceAmount || 0) > 0 ? `
          <div class="row">
            <span>সার্ভিস চার্জ:</span>
            <span>${result.currency} ${(result.tipOrServiceAmount || 0).toLocaleString()}</span>
          </div>` : ''}
          <div class="row total-row">
            <span>সর্বমোট পরিশোধ:</span>
            <span>${result.currency} ${result.grandTotal.toLocaleString()}</span>
          </div>

          <div class="section-title">ব্যক্তিভিত্তিক বণ্টন হিসাব</div>
          ${result.participants.map((p, i) => `
            <div class="person-box">
              <div class="person-header">
                <span>${i + 1}. ${p.name}</span>
                <span>${result.currency} ${p.totalToPay.toLocaleString()}</span>
              </div>
              <div class="person-sub">
                বেস: ${result.currency}${p.baseShare} + কর: ${result.currency}${p.taxShare} (${p.percentageOfTotal}%)
              </div>
            </div>
          `).join('')}

          <div class="footer">
            ধন্যবাদ! রাজু মেমো কাউন্টার ও এআই বিল স্প্লিটার<br/>
            সঠিক আনুপাতিক কর নীতি অনুযায়ী প্রস্তুত
          </div>
          <script>
            window.onload = function() { window.print(); }
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  const handleClearHistory = () => {
    if (window.confirm('আপনি কি স্প্লিটার চ্যাট হিস্ট্রি মুছে ডিফল্ট অবস্থায় ফিরিয়ে নিতে চান?')) {
      setMessages(INITIAL_MESSAGES);
      localStorage.removeItem('hubhub-splitter-chat-history');
      onToast('চ্যাট হিস্ট্রি রিসেট করা হয়েছে!');
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] sm:h-[calc(100vh-130px)] max-w-4xl mx-auto bg-slate-900/90 rounded-2xl border border-slate-800 shadow-xl overflow-hidden text-slate-100">
      {/* Top Banner / Context Info */}
      <div className="px-4 py-3 bg-slate-950/90 border-b border-slate-800 flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-amber-500 to-indigo-500 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-black text-white">
                Gemini AI বিল ও খরচ স্প্লিটার
              </h2>
              <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Proportional Tax Engine
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              ন্যায্য আনুপাতিক ভ্যাট ও বৈষম্যহীন বিল বিভাজন
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Quick Context Pill */}
          <button
            type="button"
            onClick={() => {
              const prompt = `আজকের মেমো মোট বিল (৳${currentDayTotal.toLocaleString()}) ৩ জনের মধ্যে ভাগ করুন, একজন ২০% বেশি দিবে এবং ৫% ট্যাক্স প্রযোজ্য।`;
              handleSendMessage(prompt);
            }}
            className="text-xs px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-amber-300 border border-slate-700 rounded-lg flex items-center gap-1.5 transition cursor-pointer"
            title="আজকের মেমোর মোট পরিমাণ দিয়ে স্বয়ংক্রিয় প্রম্পট পাঠান"
          >
            <Receipt className="w-3.5 h-3.5 text-amber-400" />
            <span>আজকের মেমো: <strong>৳{currentDayTotal.toLocaleString()}</strong></span>
          </button>

          <button
            type="button"
            onClick={handleClearHistory}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800/80 rounded-lg transition cursor-pointer"
            title="চ্যাট হিস্ট্রি রিসেট করুন"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Preset Suggestions Bar */}
      <div className="px-3 py-2 bg-slate-950/40 border-b border-slate-800/60 flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
        <span className="text-[11px] font-semibold text-slate-400 shrink-0 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-400" /> আইডিয়া:
        </span>
        {PRESET_PROMPTS.map((prompt, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => {
              setInputText(prompt);
              inputRef.current?.focus();
            }}
            className="text-[11px] whitespace-nowrap px-2.5 py-1 rounded-full bg-slate-800/80 hover:bg-amber-500/20 hover:text-amber-300 hover:border-amber-400/40 border border-slate-700/80 text-slate-300 transition cursor-pointer active:scale-95"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Messages Stream */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-4 overscroll-contain">
        {messages.map((message) => {
          const isUser = message.sender === 'user';
          return (
            <div
              key={message.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} space-y-1.5`}
            >
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 px-1">
                {isUser ? (
                  <span>আপনি • {message.timestamp}</span>
                ) : (
                  <span className="flex items-center gap-1 text-amber-400 font-semibold">
                    <Sparkles className="w-3 h-3" /> Gemini Splitter • {message.timestamp}
                  </span>
                )}
              </div>

              <div
                className={`max-w-[95%] sm:max-w-[85%] rounded-2xl p-3.5 sm:p-4 shadow-md ${
                  isUser
                    ? 'bg-amber-500 text-slate-950 font-medium rounded-tr-xs'
                    : 'bg-slate-800/90 border border-slate-700 text-slate-100 rounded-tl-xs'
                }`}
              >
                {/* Message Content */}
                <p className="text-xs sm:text-sm whitespace-pre-wrap leading-relaxed">
                  {message.text}
                </p>

                {/* Structured Bill Split Result Card */}
                {message.result && (
                  <div className="mt-3 pt-3 border-t border-slate-700/80 space-y-3">
                    {/* Grand Total & Tax Summary */}
                    <div className="p-3 bg-slate-900/90 rounded-xl border border-slate-700/90">
                      <div className="flex flex-wrap items-center justify-between gap-1.5 border-b border-slate-800 pb-2 mb-2">
                        <div className="font-bold text-xs sm:text-sm text-amber-400 flex items-center gap-1.5">
                          <Receipt className="w-4 h-4" />
                          <span>{message.result.title}</span>
                        </div>
                        <div className="text-right">
                          <span className="text-[10px] text-slate-400 block">সর্বমোট বিল</span>
                          <span className="text-base sm:text-lg font-black text-emerald-400">
                            {message.result.currency} {message.result.grandTotal.toLocaleString()}
                          </span>
                        </div>
                      </div>

                      {/* Subtotal, Tax and Tip row */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] sm:text-xs">
                        <div className="p-1.5 bg-slate-800/60 rounded-lg">
                          <span className="text-slate-400 block text-[10px]">বেস বিল (Subtotal):</span>
                          <span className="font-bold text-slate-200">
                            {message.result.currency} {message.result.subtotal.toLocaleString()}
                          </span>
                        </div>

                        <div className="p-1.5 bg-slate-800/60 rounded-lg">
                          <span className="text-slate-400 block text-[10px]">
                            ট্যাক্স/ভ্যাট ({message.result.taxPercent}%):
                          </span>
                          <span className="font-bold text-rose-400">
                            +{message.result.currency} {message.result.taxAmount.toLocaleString()}
                          </span>
                        </div>

                        {(message.result.tipOrServiceAmount || 0) > 0 && (
                          <div className="p-1.5 bg-slate-800/60 rounded-lg col-span-2 sm:col-span-1">
                            <span className="text-slate-400 block text-[10px]">সার্ভিস চার্জ:</span>
                            <span className="font-bold text-amber-300">
                              +{message.result.currency} {(message.result.tipOrServiceAmount || 0).toLocaleString()}
                            </span>
                          </div>
                        )}
                      </div>

                      {/* Fair Proportional Tax Policy note */}
                      {message.result.taxPercent > 0 && (
                        <div className="mt-2 text-[10px] text-emerald-300/90 bg-emerald-950/40 border border-emerald-800/40 px-2 py-1 rounded-md flex items-center gap-1.5">
                          <Info className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span>{message.result.taxCalculationMethod || 'ট্যাক্স সমান ভাগ না করে প্রত্যেকের খরচের অনুপাত অনুযায়ী বণ্টিত হয়েছে।'}</span>
                        </div>
                      )}
                    </div>

                    {/* Participant Individual Breakdown Cards */}
                    <div className="space-y-2">
                      <div className="text-[11px] font-bold text-slate-300 uppercase tracking-wider flex items-center justify-between">
                        <span className="flex items-center gap-1">
                          <Users className="w-3.5 h-3.5 text-amber-400" />
                          ব্যক্তিভিত্তিক পরিশোধ তালিকা ({message.result.participants.length} জন)
                        </span>
                        <span className="text-[10px] text-slate-400 font-normal">
                          মোট মিলানো: ১০০%
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {message.result.participants.map((p) => {
                          return (
                            <div
                              key={p.id}
                              className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-700/80 flex flex-col justify-between hover:border-amber-500/40 transition"
                            >
                              <div className="flex items-start justify-between gap-1 mb-1.5">
                                <div>
                                  <div className="font-bold text-xs text-white">
                                    {p.name}
                                  </div>
                                  <div className="text-[10px] text-slate-400">
                                    {p.shareRatioDescription || p.note || 'সাধারণ অংশ'}
                                  </div>
                                </div>
                                <div className="text-right">
                                  <div className="text-xs sm:text-sm font-black text-emerald-400">
                                    {message.result!.currency} {p.totalToPay.toLocaleString()}
                                  </div>
                                  <div className="text-[10px] text-amber-400/90 font-bold">
                                    {p.percentageOfTotal}% অংশ
                                  </div>
                                </div>
                              </div>

                              {/* Math breakdown line */}
                              <div className="text-[10px] text-slate-400 bg-slate-800/80 px-2 py-1 rounded-md flex items-center justify-between mb-1.5">
                                <span>বেস: {message.result!.currency}{p.baseShare.toLocaleString()}</span>
                                {message.result!.taxPercent > 0 && (
                                  <span>কর: +{message.result!.currency}{p.taxShare.toLocaleString()}</span>
                                )}
                              </div>

                              {/* Progress bar */}
                              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                                <div
                                  className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 rounded-full"
                                  style={{ width: `${Math.min(100, Math.max(5, p.percentageOfTotal))}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Actions: Copy Summary & Print Slip */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-slate-700/60">
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleCopySummary(message.result!, message.id)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
                          title="মেসেজ বা হোয়াটসঅ্যাপে পাঠানোর জন্য কপি করুন"
                        >
                          {copiedId === message.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span className="text-emerald-300">কপি হয়েছে!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-300" />
                              <span>সামারি কপি করুন</span>
                            </>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => handlePrintSlip(message.result!)}
                          className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer active:scale-95"
                          title="রিসিপ্ট স্লিপ প্রিন্ট করুন"
                        >
                          <Printer className="w-3.5 h-3.5 text-amber-400" />
                          <span>প্রিন্ট স্লিপ</span>
                        </button>
                      </div>

                      <div className="text-[10px] text-slate-400">
                        ∑ ব্যক্তি যোগফল = {message.result.currency}{' '}
                        {message.result.participants
                          .reduce((s, p) => s + p.totalToPay, 0)
                          .toFixed(2)}{' '}
                        (নির্ভুল)
                      </div>
                    </div>

                    {/* Suggested Next Adjustments */}
                    {message.result.suggestions && message.result.suggestions.length > 0 && (
                      <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] text-slate-400 flex items-center gap-1">
                          <ArrowRight className="w-3 h-3 text-amber-400" /> পরবর্তী অ্যাডজাস্ট:
                        </span>
                        {message.result.suggestions.map((suggestion, sIdx) => (
                          <button
                            key={sIdx}
                            type="button"
                            onClick={() => handleSendMessage(suggestion)}
                            className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition cursor-pointer"
                          >
                            {suggestion}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {/* Loading Bubble */}
        {isLoading && (
          <div className="flex flex-col items-start space-y-1">
            <div className="flex items-center gap-1.5 text-[11px] text-amber-400 font-semibold px-1">
              <Sparkles className="w-3 h-3 animate-spin" /> Gemini AI গণনা করছে...
            </div>
            <div className="p-3.5 bg-slate-800/90 border border-slate-700 rounded-2xl rounded-tl-xs flex items-center gap-2 text-slate-300 text-xs">
              <RefreshCw className="w-4 h-4 animate-spin text-amber-400" />
              <span>ন্যায্য অনুপাত ও আনুপাতিক কর বিশ্লেষণ হচ্ছে...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Chat Input Bar */}
      <div className="p-3 bg-slate-950 border-t border-slate-800 shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendMessage();
          }}
          className="flex items-center gap-2"
        >
          {/* Quick Insert Current Memo Amount Button */}
          <button
            type="button"
            onClick={() => {
              const textWithMemo = inputText
                ? `${inputText} (মোট বিল ৳${currentDayTotal})`
                : `আজকের বিল ৳${currentDayTotal} ৩ জনের মাঝে ভাগ করুন, একজন ২০% বেশি দিবে`;
              setInputText(textWithMemo);
              inputRef.current?.focus();
            }}
            className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-amber-400 border border-slate-700 transition cursor-pointer shrink-0"
            title={`আজকের মেমোর মোট বিল (৳${currentDayTotal.toLocaleString()}) যোগ করুন`}
          >
            <Receipt className="w-4 h-4" />
          </button>

          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="যেমন: Split this bill among 3 people, one owes 20% more..."
            disabled={isLoading}
            className="flex-1 bg-slate-900 border border-slate-700 focus:border-amber-400 focus:outline-hidden text-white placeholder-slate-500 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm transition disabled:opacity-50"
          />

          <button
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 active:from-amber-600 active:to-amber-700 text-slate-950 font-bold rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed shadow-md shrink-0"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">হিসাব করুন</span>
          </button>
        </form>
      </div>
    </div>
  );
};
