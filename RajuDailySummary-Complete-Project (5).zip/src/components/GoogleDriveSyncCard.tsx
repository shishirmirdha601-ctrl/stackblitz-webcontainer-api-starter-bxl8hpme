import React, { useState, useEffect } from 'react';
import {
  Cloud,
  CloudUpload,
  CloudOff,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  LogOut,
  Upload,
  Download,
  ShieldCheck,
  Share2,
  HardDrive,
  Mail,
  Info
} from 'lucide-react';
import {
  googleSignIn,
  googleSignOut,
  subscribeToDriveSyncState,
  DriveSyncState,
  uploadBackupToDrive,
  downloadBackupFromDrive
} from '../services/googleDriveService';
import { shareOrDownloadBackup } from '../utils/shareBackup';

interface GoogleDriveSyncCardProps {
  getBackupPayload: () => any;
  onRestoreData?: (restored: any) => void;
  onShowToast: (msg: string) => void;
}

export const GoogleDriveSyncCard: React.FC<GoogleDriveSyncCardProps> = ({
  getBackupPayload,
  onRestoreData,
  onShowToast
}) => {
  const [syncState, setSyncState] = useState<DriveSyncState>({
    status: 'unauthenticated',
    lastSyncedAt: null,
    userEmail: null,
    userName: null,
    userPhoto: null
  });
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [isManualSyncing, setIsManualSyncing] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [oauthBlockedNotice, setOauthBlockedNotice] = useState(false);

  useEffect(() => {
    const unsubscribe = subscribeToDriveSyncState((state) => {
      setSyncState(state);
    });
    return () => unsubscribe();
  }, []);

  const handleShareToDriveOrGmail = async () => {
    setIsSharing(true);
    try {
      const payload = getBackupPayload();
      const result = await shareOrDownloadBackup(payload);
      onShowToast(result.message);
    } catch (e: any) {
      onShowToast('শেয়ার করতে সমস্যা হয়েছে');
    } finally {
      setIsSharing(false);
    }
  };

  const handleSaveToFilesOffline = () => {
    try {
      const payload = getBackupPayload();
      const jsonStr = JSON.stringify(payload, null, 2);
      const dateStr = new Date().toISOString().split('T')[0];
      const filename = `raju-daily-summary-backup-${dateStr}.json`;
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      onShowToast('ব্যাকআপ ফাইলটি ডাউনলোড হয়ে আপনার ফোনের Files / Downloads ফোল্ডারে সেভ হয়েছে!');
    } catch {
      onShowToast('ফাইল সংরক্ষণ করতে সমস্যা হয়েছে');
    }
  };

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setOauthBlockedNotice(false);
    try {
      const res = await googleSignIn();
      if (res?.user) {
        onShowToast(`গুগল ড্রাইভে সফলভাবে কানেক্ট হয়েছে (${res.user.email})`);
        const payload = getBackupPayload();
        await uploadBackupToDrive(payload);
        onShowToast('গুগল ড্রাইভে প্রথম ব্যাকআপ সফলভাবে আপলোড হয়েছে!');
      }
    } catch (err: any) {
      console.error(err);
      const errStr = (err?.message || '').toLowerCase();
      if (errStr.includes('blocked') || errStr.includes('verification') || errStr.includes('403') || errStr.includes('access_denied')) {
        setOauthBlockedNotice(true);
        onShowToast('গুগল অ্যাকাউন্ট ভেরিফিকেশন প্রয়োজন। নিচের শেয়ার বাটন ব্যবহার করুন!');
      } else {
        onShowToast(`গুগল সাইন-ইন সম্পন্ন করা যায়নি: ${err.message || ''}`);
      }
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await googleSignOut();
      onShowToast('গুগল ড্রাইভ ডিসকানেক্ট করা হয়েছে');
    } catch (err: any) {
      onShowToast('সাইন-আউটে সমস্যা হয়েছে');
    }
  };

  const handleManualSync = async () => {
    setIsManualSyncing(true);
    try {
      const payload = getBackupPayload();
      const res = await uploadBackupToDrive(payload);
      if (res.success) {
        onShowToast('গুগল ড্রাইভে নতুন ব্যাকআপ সফলভাবে সেভ হয়েছে!');
      } else {
        onShowToast(`সিঙ্ক ব্যর্থ: ${res.error || 'অজানা ত্রুটি'}`);
      }
    } finally {
      setIsManualSyncing(false);
    }
  };

  const handleRestore = async () => {
    if (!window.confirm('আপনি কি গুগল ড্রাইভের ব্যাকআপ থেকে বর্তমান ডাটা রিস্টোর করতে চান? এটি বর্তমান অসংরক্ষিত ডাটাকে প্রতিস্থাপন করবে।')) {
      return;
    }

    setIsRestoring(true);
    try {
      const res = await downloadBackupFromDrive();
      if (res.success && res.data) {
        if (onRestoreData) {
          onRestoreData(res.data);
          onShowToast('গুগল ড্রাইভ থেকে সফলভাবে ডাটা রিস্টোর হয়েছে!');
        }
      } else {
        onShowToast(`রিস্টোর ব্যর্থ: ${res.error || 'ফাইল পাওয়া যায়নি'}`);
      }
    } finally {
      setIsRestoring(false);
    }
  };

  const isAuthenticated = syncState.status !== 'unauthenticated';

  return (
    <div className="p-4 bg-gradient-to-br from-indigo-50/90 via-sky-50/70 to-blue-50/90 dark:from-indigo-950/40 dark:via-slate-900/60 dark:to-blue-950/40 rounded-2xl border border-indigo-200 dark:border-indigo-800/60 shadow-sm space-y-3">
      {/* Header */}
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
            <Cloud className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-black text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
              Google Drive ও জিমেইল ব্যাকআপ
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700">
                ১০০% অফলাইন
              </span>
            </h4>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              ফোনের Files মেমোরি, জিমেইল বা ড্রাইভে সরাসরি হিসাব ব্যাকআপ রাখুন
            </p>
          </div>
        </div>

        {/* Sync Status Badge */}
        <div>
          {syncState.status === 'syncing' ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 dark:bg-amber-900/50 dark:text-amber-300 border border-amber-300 dark:border-amber-700 animate-pulse">
              <RefreshCw className="w-3 h-3 animate-spin" />
              ড্রাইভে আপলোড হচ্ছে...
            </span>
          ) : syncState.status === 'synced' ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/50 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              সিঙ্ক সম্পন্ন {syncState.lastSyncedAt ? `(${syncState.lastSyncedAt})` : ''}
            </span>
          ) : syncState.status === 'error' ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-rose-100 text-rose-800 dark:bg-rose-900/50 dark:text-rose-300 border border-rose-300 dark:border-rose-700">
              <AlertCircle className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
              সিঙ্ক ব্যর্থ
            </span>
          ) : isAuthenticated ? (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-800 dark:bg-blue-900/50 dark:text-blue-300 border border-blue-300 dark:border-blue-700">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
              ড্রাইভ সংযুক্ত
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
              <HardDrive className="w-3 h-3 text-slate-500" />
              লোকাল ও শেয়ার ব্যাকআপ
            </span>
          )}
        </div>
      </div>

      {/* Recommended 1-Click Zero-Error Options */}
      <div className="p-3 bg-white dark:bg-slate-900 rounded-xl border border-blue-200 dark:border-slate-700 space-y-2.5 shadow-xs">
        <div className="flex items-center justify-between text-xs font-bold text-blue-900 dark:text-blue-300">
          <span className="flex items-center gap-1.5">
            <Share2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            সহজ অফলাইন ব্যাকআপ (কোনো লগইন বা পাসওয়ার্ডের ঝামেলা নেই)
          </span>
          <span className="text-[10px] bg-emerald-600 text-white px-2 py-0.5 rounded-full font-black">
            সুপার ফাস্ট
          </span>
        </div>

        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
          আপনার ফোনের <strong>Gmail</strong>, <strong>Google Drive অ্যাপ</strong> অথবা <strong>Files ফোল্ডারে</strong> ১ ক্লিকে ব্যাকআপ পাঠাতে নিচের বাটন দুটি ব্যবহার করুন:
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
          <button
            type="button"
            onClick={handleShareToDriveOrGmail}
            disabled={isSharing}
            className="w-full py-2.5 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-black rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-md active:scale-95 transition"
          >
            <Mail className="w-4 h-4 text-amber-300" />
            <span>জিমেইল / ড্রাইভে শেয়ার করুন</span>
          </button>

          <button
            type="button"
            onClick={handleSaveToFilesOffline}
            className="w-full py-2.5 px-3 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 transition"
          >
            <HardDrive className="w-4 h-4 text-emerald-200" />
            <span>গুগল ফাইলস (Files) এ সেভ করুন</span>
          </button>
        </div>
      </div>

      {/* OAuth Blocked / Verification Explanation */}
      {oauthBlockedNotice && (
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700/70 rounded-xl space-y-1.5 text-xs text-amber-900 dark:text-amber-200 animate-fade-in">
          <div className="flex items-center gap-2 font-bold text-amber-950 dark:text-amber-100">
            <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            <span>Google Drive ভেরিফিকেশন নোটিশ (Error 403)</span>
          </div>
          <p className="text-[11px] leading-relaxed">
            গুগল ক্লাউড তাদের ড্রাইভ অ্যাক্সেস সরাসরি কানেক্ট করার জন্য অ্যাপ ভেরিফিকেশন চায়। 
            <strong> আপনার কোনো চিন্তা নেই!</strong> উপরের <strong>[জিমেইল / ড্রাইভে শেয়ার করুন]</strong> বাটন দিয়ে সরাসরি আপনার গুগল ড্রাইভ ও জিমেইলে ফাইল ব্যাকআপ রাখতে পারবেন সম্পূর্ণ ফ্রিতে।
          </p>
        </div>
      )}

      {/* Account Info & Direct Drive Connect */}
      {isAuthenticated ? (
        <div className="space-y-3 pt-1">
          <div className="flex items-center justify-between gap-2 p-2.5 bg-white dark:bg-slate-900/80 rounded-xl border border-slate-200/80 dark:border-slate-800 text-xs">
            <div className="flex items-center gap-2 overflow-hidden">
              {syncState.userPhoto ? (
                <img
                  src={syncState.userPhoto}
                  alt={syncState.userName || 'Google User'}
                  className="w-7 h-7 rounded-full border border-slate-300 dark:border-slate-700"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-blue-600 text-white font-black flex items-center justify-center text-xs">
                  {syncState.userName ? syncState.userName[0].toUpperCase() : 'G'}
                </div>
              )}
              <div className="truncate">
                <div className="font-bold text-slate-800 dark:text-slate-200 truncate">
                  {syncState.userName || 'গুগল ব্যবহারকারী'}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                  {syncState.userEmail || ''}
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={handleSignOut}
              className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-slate-600 hover:text-rose-600 dark:text-slate-300 dark:hover:text-rose-400 border border-slate-200 dark:border-slate-700 text-xs font-semibold flex items-center gap-1 transition cursor-pointer shrink-0"
              title="গুগল ড্রাইভ ডিসকানেক্ট করুন"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>ডিসকানেক্ট</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleManualSync}
              disabled={isManualSyncing || syncState.status === 'syncing'}
              className="w-full py-2 px-3 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isManualSyncing ? 'animate-spin' : ''}`} />
              <span>{isManualSyncing ? 'ড্রাইভে আপলোড হচ্ছে...' : 'এখনই ড্রাইভে সিঙ্ক করুন'}</span>
            </button>

            {onRestoreData && (
              <button
                type="button"
                onClick={handleRestore}
                disabled={isRestoring}
                className="w-full py-2 px-3 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-slate-100 font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs disabled:opacity-50 border border-slate-700"
              >
                <Download className={`w-3.5 h-3.5 ${isRestoring ? 'animate-spin' : ''}`} />
                <span>{isRestoring ? 'রিস্টোর হচ্ছে...' : 'ড্রাইভ থেকে ডাটা আনুন'}</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-2 pt-1 border-t border-indigo-200/60 dark:border-indigo-900/60 mt-2">
          <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
            <span>সরাসরি Google ক্লাউড ব্যাকআপ (ঐচ্ছিক):</span>
          </div>
          <button
            type="button"
            onClick={handleSignIn}
            disabled={isSigningIn}
            className="w-full py-2 px-3 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 active:scale-[0.98] border border-slate-300 dark:border-slate-700 rounded-xl shadow-xs text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center justify-center gap-2.5 transition cursor-pointer disabled:opacity-60"
          >
            <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            <span>{isSigningIn ? 'লগইন প্রক্রিয়া চলছে...' : 'গুগল একাউন্ট দিয়ে ড্রাইভ সিঙ্ক চেষ্টা করুন'}</span>
          </button>
        </div>
      )}
    </div>
  );
};

