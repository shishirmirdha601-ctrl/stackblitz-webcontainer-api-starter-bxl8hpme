import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, CheckCircle2, Share2, HelpCircle, X, Smartphone, Sparkles, Play } from 'lucide-react';

export const PWAInstallButton: React.FC<{ variant?: 'header' | 'banner' | 'play-ready' }> = ({
  variant = 'header'
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);

  // If already running as an installed Web APK / PWA
  if (isInstalled) {
    if (variant === 'play-ready') {
      return (
        <div
          id="pwa-installed-card"
          className="bg-emerald-900 text-emerald-100 p-4 rounded-2xl shadow-sm border border-emerald-700 flex items-center justify-between gap-3 flex-wrap"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-black">
              <CheckCircle2 className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="font-extrabold text-white text-sm sm:text-base flex items-center gap-2">
                <span>Raju Daily Summary ইনস্টল করা আছে</span>
                <span className="text-[10px] bg-emerald-500 text-slate-950 font-black px-1.5 py-0.5 rounded">
                  Play Ready
                </span>
              </div>
              <div className="text-xs text-emerald-200">
                অ্যাপটি আপনার ফোনে ইনস্টল রয়েছে এবং সম্পূর্ণ অফলাইনে চলছে।
              </div>
            </div>
          </div>
          <span className="text-xs font-bold bg-emerald-800 text-emerald-200 px-3 py-1.5 rounded-lg border border-emerald-600">
            অ্যাপ সক্রিয়
          </span>
        </div>
      );
    }

    return (
      <span
        id="pwa-installed-badge"
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700/80 text-emerald-100 text-xs font-semibold"
      >
        <CheckCircle2 className="w-4 h-4 text-emerald-300" />
        ইনস্টলড
      </span>
    );
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      await install();
    } else {
      setShowGuide(true);
    }
  };

  return (
    <>
      {variant === 'play-ready' ? (
        <div
          id="pwa-play-ready-card"
          className="bg-gradient-to-r from-slate-950 via-slate-900 to-indigo-950 text-white p-4 sm:p-5 rounded-2xl shadow-md border border-slate-700/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
        >
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-12 h-12 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-lg shrink-0 shadow-lg border-2 border-amber-300">
              RD
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="text-base sm:text-lg font-black text-white leading-tight">
                  Raju Daily Summary — ফোনে ইনস্টল করুন
                </h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black bg-emerald-500 text-slate-950 shadow-2xs">
                  <Sparkles className="w-3 h-3" />
                  অফলাইন অ্যাপ
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-normal max-w-xl">
                আপনার Android ফোনের হোমস্ক্রিনে অ্যাপ হিসেবে যুক্ত করুন। একবার ইনস্টল করলে কোনো ইন্টারনেট ছাড়াই সম্পূর্ণ অফলাইনে চলবে।
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto shrink-0 flex-wrap">
            <button
              id="pwa-play-download-btn"
              onClick={handleInstallClick}
              className="flex-1 sm:flex-none inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-md transition active:scale-95 cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-950" />
              <span>📲 ফোনে ইনস্টল করুন</span>
            </button>
            <button
              type="button"
              onClick={() => setShowGuide(true)}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition cursor-pointer"
              title="কীভাবে ইনস্টল করতে হবে দেখুন"
            >
              <HelpCircle className="w-4 h-4 text-amber-400" />
              <span>নিয়মাবলী</span>
            </button>
          </div>
        </div>
      ) : variant === 'banner' ? (
        <div
          id="pwa-install-banner"
          className="bg-gradient-to-r from-amber-600 via-amber-500 to-yellow-500 text-gray-950 p-3 sm:p-3.5 rounded-xl shadow-md flex items-center justify-between gap-3 flex-wrap"
        >
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-lg bg-gray-950 text-amber-400 flex items-center justify-center font-black text-sm shrink-0 shadow">
              RD
            </div>
            <div>
              <div className="font-extrabold text-sm sm:text-base leading-tight flex items-center gap-1.5 flex-wrap">
                <span>📲 ফোনে সরাসরি ইনস্টল করুন (Offline Ready)</span>
                <span className="bg-gray-950 text-amber-300 text-[10px] font-black px-1.5 py-0.2 rounded">
                  হোমস্ক্রিন
                </span>
              </div>
              <div className="text-xs text-gray-950/90 font-medium">
                ইন্টারনেট ছাড়াই ফোনে অ্যাপের মতো সরাসরি হিসাব রাখুন
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="pwa-banner-install-btn"
              onClick={handleInstallClick}
              className="px-4 py-2 bg-gray-950 hover:bg-gray-800 text-white font-bold text-xs sm:text-sm rounded-lg shadow transition flex items-center gap-1.5 cursor-pointer"
            >
              <Download className="w-4 h-4 text-amber-400" />
              হোমস্ক্রিনে ইনস্টল
            </button>
          </div>
        </div>
      ) : (
        <button
          id="pwa-header-install-btn"
          onClick={handleInstallClick}
          className="inline-flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-gray-950 font-black px-3 py-1.5 rounded-lg text-xs sm:text-sm shadow-sm transition active:scale-95 cursor-pointer"
          title="Install on phone or computer"
        >
          <Download className="w-4 h-4" />
          <span>📲 ফোনে ইনস্টল</span>
        </button>
      )}

      {/* Guide Modal for manual / iOS / Android installation */}
      {showGuide && (
        <div
          id="pwa-guide-modal"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
        >
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 p-5 shadow-2xl text-gray-900 dark:text-slate-100 border border-slate-200 dark:border-slate-800">
            <div className="flex items-start justify-between border-b pb-3 border-gray-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-gray-900 dark:text-slate-100 flex items-center gap-1.5">
                    <span>অ্যাপ ডাউনলোড ও ইনস্টল করার নিয়ম</span>
                  </h3>
                  <p className="text-xs text-emerald-700 dark:text-emerald-400 font-semibold">Google Play & Android Web APK Ready</p>
                </div>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="p-1 rounded-md text-gray-400 hover:text-gray-600 dark:hover:text-slate-200 hover:bg-gray-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3 text-sm text-gray-700 dark:text-slate-300">
              {isIOS ? (
                <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/60 rounded-xl space-y-2">
                  <p className="font-semibold text-blue-900 dark:text-blue-200 flex items-center gap-1.5">
                    <Share2 className="w-4 h-4" /> iPhone বা iPad এ ইনস্টল করতে:
                  </p>
                  <ol className="list-decimal list-inside space-y-1 text-xs text-blue-800 dark:text-blue-300 font-medium">
                    <li>Safari ব্রাউজারের নিচের <strong>Share (শেয়ার)</strong> বাটনে ট্যাপ করুন।</li>
                    <li>নিচে স্ক্রোল করে <strong>"Add to Home Screen"</strong> নির্বাচন করুন।</li>
                    <li>উপরে <strong>"Add"</strong> চাপলে হোমস্ক্রিনে অ্যাপ তৈরি হবে।</li>
                  </ol>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 rounded-xl space-y-2">
                  <p className="font-semibold text-amber-950 dark:text-amber-200 flex items-center gap-1.5">
                    <HelpCircle className="w-4 h-4 text-amber-700 dark:text-amber-400" /> Android ফোনে সরাসরি অ্যাপ ইনস্টল ও ডাউনলোড করতে:
                  </p>
                  <ol className="list-decimal list-inside space-y-2 text-xs text-amber-900 dark:text-amber-300 font-medium">
                    <li>Chrome ব্রাউজারের উপরে ডানদিকের <strong>তিনটি ডট (⋮)</strong> মেনুতে চাপুন।</li>
                    <li>মেনু থেকে <strong>"Install app"</strong> অথবা <strong>"Add to Home screen"</strong> নির্বাচন করুন।</li>
                    <li>পপ-আপে <strong>"Install"</strong> বাটনে চাপ দিলেই মোবাইলের অ্যাপ তালিকায় <strong>Raju Daily Summary</strong> যুক্ত হয়ে যাবে।</li>
                    <li><strong>সম্পূর্ণ অফলাইন রান:</strong> একবার ইনস্টল হয়ে গেলে ইন্টারনেট / Wi-Fi পুরোপুরি বন্ধ রাখলেও অ্যাপটি প্লে-স্টোর অ্যাপের মতো দ্রুত কাজ করবে।</li>
                  </ol>
                </div>
              )}

              <div className="bg-emerald-50 dark:bg-emerald-950/40 p-3 rounded-lg border border-emerald-200 dark:border-emerald-800/60 text-xs text-emerald-800 dark:text-emerald-300 space-y-1">
                <div className="font-bold flex items-center gap-1.5 text-emerald-950 dark:text-emerald-200">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" /> ১০০% অফলাইন সাপোর্ট (Offline Ready):
                </div>
                <div>
                  সকল পণ্যের তালিকা, Quantity, মেমো নম্বর, হিস্ট্রি এবং সামারি আপনার মোবাইলের লোকাল স্টোরেজে সরাসরি সেভ থাকে। তাই নেট না থাকলেও কোনো হিসাব হারিয়ে যাবে না।
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowGuide(false)}
              className="mt-4 w-full rounded-xl bg-gray-900 dark:bg-slate-800 hover:bg-gray-800 dark:hover:bg-slate-700 py-2.5 text-sm font-bold text-white cursor-pointer transition border border-transparent dark:border-slate-700"
            >
              বুঝেছি / বন্ধ করুন
            </button>
          </div>
        </div>
      )}
    </>
  );
};

