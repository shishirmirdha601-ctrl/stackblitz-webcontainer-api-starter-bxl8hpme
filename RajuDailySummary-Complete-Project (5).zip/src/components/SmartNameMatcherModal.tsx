import React, { useState } from 'react';
import { Product } from '../data/products';
import { FileMatchResult } from '../utils/nameMatcher';
import { compressImageFile, ProductImageMap, saveStoredProductImages } from '../utils/productImages';
import {
  Check,
  CheckCircle2,
  AlertCircle,
  X,
  Upload,
  Sparkles,
  ArrowRight,
  Image as ImageIcon,
  Loader2
} from 'lucide-react';

interface SmartNameMatcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  initialMatches: FileMatchResult[];
  imageMap: ProductImageMap;
  onUpdateImageMap: (map: ProductImageMap) => void;
  showToast: (msg: string) => void;
}

export const SmartNameMatcherModal: React.FC<SmartNameMatcherModalProps> = ({
  isOpen,
  onClose,
  products,
  initialMatches,
  imageMap,
  onUpdateImageMap,
  showToast,
}) => {
  const [matches, setMatches] = useState<FileMatchResult[]>(initialMatches);
  const [isApplying, setIsApplying] = useState(false);

  // Sync if initial matches change
  React.useEffect(() => {
    setMatches(initialMatches);
  }, [initialMatches]);

  if (!isOpen) return null;

  const handleProductChange = (index: number, newProdId: number) => {
    const prod = products.find((p) => p.id === newProdId);
    if (!prod) return;

    setMatches((prev) => {
      const copy = [...prev];
      copy[index] = {
        ...copy[index],
        matchedProductId: prod.id,
        matchedProductName: prod.name,
        confidence: 'high',
        matchReason: 'ম্যানুয়ালি নির্ধারিত',
      };
      return copy;
    });
  };

  const handleApplyAll = async () => {
    try {
      setIsApplying(true);
      showToast(`${matches.length} টি ছবি প্রসেস ও কম্প্রেস করা হচ্ছে...`);

      const updatedMap: ProductImageMap = { ...imageMap };

      for (const item of matches) {
        const base64 = await compressImageFile(item.file, 450, 450, 0.82);
        updatedMap[item.matchedProductId] = base64;
      }

      saveStoredProductImages(updatedMap);
      onUpdateImageMap(updatedMap);
      showToast(`মোট ${matches.length} টি পণ্যের ছবি নাম অনুযায়ী সফলভাবে সেট করা হয়েছে!`);
      onClose();
    } catch (err) {
      console.error(err);
      showToast('ছবি সংরক্ষণে ত্রুটি দেখা দিয়েছে।');
    } finally {
      setIsApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-3xl w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-emerald-600 via-teal-600 to-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-white/10 backdrop-blur-xs">
              <Sparkles className="w-5 h-5 text-amber-300 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black leading-tight flex items-center gap-1.5">
                <span>নাম অনুযায়ী ছবি মেলানো হয়েছে</span>
                <span className="text-[11px] bg-amber-400 text-slate-950 font-black px-2 py-0.5 rounded-full">
                  {matches.length} টি ছবি
                </span>
              </h2>
              <p className="text-xs text-emerald-100 mt-0.5">
                ফাইলের নাম ও নম্বরের সাথে পণ্য স্বয়ংক্রিয়ভাবে মিলিয়ে দেওয়া হয়েছে। প্রয়োজনে পরিবর্তন করতে পারেন।
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* List of matched items */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3 divide-y divide-slate-100 dark:divide-slate-800/60">
          {matches.length === 0 ? (
            <div className="text-center py-12 text-slate-400 text-sm">
              কোনো ছবি নির্বাচন করা হয়নি।
            </div>
          ) : (
            matches.map((item, idx) => (
              <div key={idx} className="pt-3 first:pt-0 flex items-center gap-3 sm:gap-4">
                {/* Thumbnail Preview */}
                <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 shadow-xs">
                  <img
                    src={item.previewUrl}
                    alt={item.file.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute bottom-0 inset-x-0 bg-black/60 text-[9px] text-white text-center py-0.5 truncate px-1">
                    #{idx + 1}
                  </div>
                </div>

                {/* Match Information & Dropdown */}
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-1.5 mb-1">
                    <span className="text-xs font-mono font-bold text-slate-500 dark:text-slate-400 truncate max-w-[180px] sm:max-w-[260px]">
                      {item.file.name}
                    </span>
                    <span
                      className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                        item.confidence === 'high'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : item.confidence === 'medium'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {item.matchReason}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <ArrowRight className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <div className="flex-1">
                      <label className="text-[10px] font-bold text-slate-400 block mb-0.5">
                        নির্ধারিত পণ্য:
                      </label>
                      <select
                        value={item.matchedProductId}
                        onChange={(e) => handleProductChange(idx, Number(e.target.value))}
                        className="w-full py-1.5 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm font-bold text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer"
                      >
                        {products.map((p) => (
                          <option key={p.id} value={p.id}>
                            #{p.id + 1} {p.name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer actions */}
        <div className="p-4 sm:p-5 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            disabled={isApplying}
            className="px-4 py-2 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-xl hover:bg-slate-200 dark:hover:bg-slate-700 transition cursor-pointer"
          >
            বাতিল
          </button>

          <button
            type="button"
            onClick={handleApplyAll}
            disabled={isApplying || matches.length === 0}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black text-xs sm:text-sm rounded-xl shadow-md flex items-center gap-2 transition cursor-pointer disabled:opacity-50"
          >
            {isApplying ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>ছবি বসানো হচ্ছে...</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-200" />
                <span>নাম অনুযায়ী সব ছবি বসিয়ে দিন ({matches.length})</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
