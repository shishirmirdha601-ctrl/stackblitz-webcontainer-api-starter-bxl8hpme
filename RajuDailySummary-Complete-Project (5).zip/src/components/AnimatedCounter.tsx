import React, { useEffect, useState, useRef } from 'react';

interface AnimatedCounterProps {
  value: number;
  duration?: number;
  formatter?: (val: number) => string;
  className?: string;
  id?: string;
}

export const AnimatedCounter: React.FC<AnimatedCounterProps> = ({
  value,
  duration = 600,
  formatter = (v) => v.toLocaleString('en-US'),
  className = '',
  id,
}) => {
  const [displayValue, setDisplayValue] = useState<number>(value);
  const prevValueRef = useRef<number>(value);
  const [direction, setDirection] = useState<'up' | 'down' | null>(null);

  useEffect(() => {
    const startValue = prevValueRef.current;
    const endValue = value;
    prevValueRef.current = value;

    if (startValue === endValue) {
      return;
    }

    const diff = endValue - startValue;
    setDirection(diff > 0 ? 'up' : 'down');

    const startTime = performance.now();
    let frameId: number;
    let timeoutId: NodeJS.Timeout;

    const tick = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      // Ease out cubic function for smooth, fluid counting
      const easeOutCubic = 1 - Math.pow(1 - progress, 3);
      const current = Math.round(startValue + diff * easeOutCubic);

      setDisplayValue(current);

      if (progress < 1) {
        frameId = requestAnimationFrame(tick);
      } else {
        setDisplayValue(endValue);
        timeoutId = setTimeout(() => {
          setDirection(null);
        }, 400);
      }
    };

    frameId = requestAnimationFrame(tick);

    return () => {
      cancelAnimationFrame(frameId);
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [value, duration]);

  const highlightClass =
    direction === 'up'
      ? 'scale-105 text-amber-300'
      : direction === 'down'
      ? 'scale-95 text-red-400'
      : 'scale-100 text-white';

  return (
    <span
      id={id}
      className={`inline-block tabular-nums transition-all duration-300 ease-out transform ${highlightClass} ${className}`}
    >
      {formatter(displayValue)}
    </span>
  );
};
