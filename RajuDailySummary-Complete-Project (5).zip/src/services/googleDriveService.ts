import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
  User
} from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

// Initialize Firebase App instance safely
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);

// Configure Google Auth Provider with Google Drive file scope
const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/drive.file');
// Prompt user to select account if needed
provider.setCustomParameters({
  prompt: 'select_account'
});

export const SCOPES = ['https://www.googleapis.com/auth/drive.file'];

export const DRIVE_BACKUP_FILENAME = 'raju-daily-summary-backup.json';

// In-memory cache for OAuth Access Token (strictly in-memory as per security guidelines)
let cachedAccessToken: string | null = null;
let isSigningIn = false;
let syncTimeoutId: ReturnType<typeof setTimeout> | null = null;
let lastKnownDriveFileId: string | null = null;

export interface DriveSyncState {
  status: 'idle' | 'syncing' | 'synced' | 'error' | 'unauthenticated';
  lastSyncedAt: string | null;
  errorMessage?: string;
  fileId?: string;
  userEmail?: string | null;
  userName?: string | null;
  userPhoto?: string | null;
}

let currentSyncState: DriveSyncState = {
  status: 'unauthenticated',
  lastSyncedAt: null,
  errorMessage: undefined,
  fileId: undefined,
  userEmail: null,
  userName: null,
  userPhoto: null
};

const listeners: Set<(state: DriveSyncState) => void> = new Set();

function notifyListeners() {
  listeners.forEach((listener) => {
    try {
      listener({ ...currentSyncState });
    } catch (e) {
      console.error('Error in DriveSync listener:', e);
    }
  });
}

export function subscribeToDriveSyncState(callback: (state: DriveSyncState) => void): () => void {
  listeners.add(callback);
  callback({ ...currentSyncState });
  return () => {
    listeners.delete(callback);
  };
}

export function getDriveSyncState(): DriveSyncState {
  return { ...currentSyncState };
}

export function getDriveAccessToken(): string | null {
  return cachedAccessToken;
}

export function isGoogleDriveConnected(): boolean {
  return Boolean(cachedAccessToken && auth.currentUser);
}

/**
 * Initialize Firebase Auth listener.
 */
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        currentSyncState = {
          ...currentSyncState,
          status: currentSyncState.status === 'unauthenticated' ? 'idle' : currentSyncState.status,
          userEmail: user.email,
          userName: user.displayName,
          userPhoto: user.photoURL
        };
        notifyListeners();
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // User is remembered by Firebase Auth, but OAuth access token needs a fresh session or login
        currentSyncState = {
          ...currentSyncState,
          status: 'unauthenticated',
          userEmail: user.email,
          userName: user.displayName,
          userPhoto: user.photoURL
        };
        notifyListeners();
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      currentSyncState = {
        status: 'unauthenticated',
        lastSyncedAt: null,
        userEmail: null,
        userName: null,
        userPhoto: null
      };
      notifyListeners();
      if (onAuthFailure) onAuthFailure();
    }
  });
};

/**
 * Sign in with Google to obtain Drive OAuth access token
 */
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('গুগল ড্রাইভ অ্যাক্সেস টোকেন পাওয়া যায়নি');
    }

    cachedAccessToken = credential.accessToken;
    currentSyncState = {
      ...currentSyncState,
      status: 'idle',
      userEmail: result.user.email,
      userName: result.user.displayName,
      userPhoto: result.user.photoURL,
      errorMessage: undefined
    };
    notifyListeners();
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-in error:', error);
    currentSyncState = {
      ...currentSyncState,
      status: 'error',
      errorMessage: error?.message || 'গুগল সাইন-ইন ব্যর্থ হয়েছে'
    };
    notifyListeners();
    throw error;
  } finally {
    isSigningIn = false;
  }
};

/**
 * Sign out and clear in-memory tokens
 */
export const googleSignOut = async () => {
  if (syncTimeoutId) {
    clearTimeout(syncTimeoutId);
    syncTimeoutId = null;
  }
  await signOut(auth);
  cachedAccessToken = null;
  lastKnownDriveFileId = null;
  currentSyncState = {
    status: 'unauthenticated',
    lastSyncedAt: null,
    errorMessage: undefined,
    fileId: undefined,
    userEmail: null,
    userName: null,
    userPhoto: null
  };
  notifyListeners();
};

/**
 * Find existing backup file on Google Drive
 */
async function findBackupFile(token: string): Promise<string | null> {
  if (lastKnownDriveFileId) {
    // Quickly verify if this file is still accessible
    try {
      const verifyRes = await fetch(
        `https://www.googleapis.com/drive/v3/files/${lastKnownDriveFileId}?fields=id,trashed`,
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      if (verifyRes.ok) {
        const fileData = await verifyRes.json();
        if (!fileData.trashed) {
          return lastKnownDriveFileId;
        }
      }
    } catch {
      // Ignore and fallback to search
    }
  }

  const query = encodeURIComponent(`name = '${DRIVE_BACKUP_FILENAME}' and trashed = false`);
  const response = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,modifiedTime)&spaces=drive`,
    {
      headers: { Authorization: `Bearer ${token}` }
    }
  );

  if (!response.ok) {
    const errText = await response.text();
    console.error('Error searching Drive files:', errText);
    return null;
  }

  const result = await response.json();
  if (result.files && result.files.length > 0) {
    lastKnownDriveFileId = result.files[0].id;
    return lastKnownDriveFileId;
  }

  return null;
}

/**
 * Direct upload/update of backup payload to Google Drive
 */
export async function uploadBackupToDrive(payload: any): Promise<{
  success: boolean;
  fileId?: string;
  error?: string;
}> {
  if (!cachedAccessToken) {
    currentSyncState = {
      ...currentSyncState,
      status: 'unauthenticated',
      errorMessage: 'গুগল ড্রাইভ সংযুক্ত নয়। দয়া করে সাইন ইন করুন।'
    };
    notifyListeners();
    return { success: false, error: 'Not authenticated with Google Drive' };
  }

  currentSyncState = {
    ...currentSyncState,
    status: 'syncing',
    errorMessage: undefined
  };
  notifyListeners();

  try {
    const token = cachedAccessToken;
    const jsonString = JSON.stringify(payload, null, 2);
    const existingFileId = await findBackupFile(token);

    let targetFileId = existingFileId;

    if (existingFileId) {
      // Update existing file content
      const updateRes = await fetch(
        `https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=media`,
        {
          method: 'PATCH',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json; charset=UTF-8'
          },
          body: jsonString
        }
      );

      if (!updateRes.ok) {
        // If file not found or expired, fallback to creating a new file
        if (updateRes.status === 404) {
          targetFileId = null;
        } else {
          const errBody = await updateRes.text();
          throw new Error(`ড্রাইভ আপডেট ব্যর্থ (${updateRes.status}): ${errBody}`);
        }
      } else {
        const updateData = await updateRes.json();
        targetFileId = updateData.id || existingFileId;
      }
    }

    if (!targetFileId) {
      // Create new backup file via multipart upload
      const boundary = '-------314159265358979323846';
      const delimiter = '\r\n--' + boundary + '\r\n';
      const closeDelim = '\r\n--' + boundary + '--';

      const metadata = {
        name: DRIVE_BACKUP_FILENAME,
        mimeType: 'application/json',
        description: 'Raju Daily Summary Automatic Sync Backup (মেমো ও হিসাব ক্লাউড ব্যাকআপ)'
      };

      const multipartRequestBody =
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        JSON.stringify(metadata) +
        delimiter +
        'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
        jsonString +
        closeDelim;

      const createRes = await fetch(
        'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': `multipart/related; boundary=${boundary}`
          },
          body: multipartRequestBody
        }
      );

      if (!createRes.ok) {
        const errBody = await createRes.text();
        throw new Error(`নতুন ব্যাকআপ ফাইল তৈরিতে ব্যর্থ (${createRes.status}): ${errBody}`);
      }

      const createData = await createRes.json();
      targetFileId = createData.id;
      lastKnownDriveFileId = targetFileId;
    }

    const nowStr = new Date().toLocaleTimeString('bn-BD', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });

    currentSyncState = {
      ...currentSyncState,
      status: 'synced',
      lastSyncedAt: nowStr,
      fileId: targetFileId || undefined,
      errorMessage: undefined
    };
    notifyListeners();

    return { success: true, fileId: targetFileId || undefined };
  } catch (error: any) {
    console.error('Failed to sync data to Google Drive:', error);
    currentSyncState = {
      ...currentSyncState,
      status: 'error',
      errorMessage: error?.message || 'গুগল ড্রাইভে আপলোড ব্যর্থ হয়েছে'
    };
    notifyListeners();
    return { success: false, error: error?.message };
  }
}

/**
 * Debounced automatic data sync trigger for state changes (data / globalHistory)
 */
export function triggerDebouncedDriveSync(payloadGetter: () => any, delayMs = 2000) {
  if (!cachedAccessToken) {
    return;
  }

  if (syncTimeoutId) {
    clearTimeout(syncTimeoutId);
  }

  currentSyncState = {
    ...currentSyncState,
    status: 'syncing'
  };
  notifyListeners();

  syncTimeoutId = setTimeout(async () => {
    try {
      const payload = payloadGetter();
      await uploadBackupToDrive(payload);
    } catch (e) {
      console.error('Debounced drive sync error:', e);
    } finally {
      syncTimeoutId = null;
    }
  }, delayMs);
}

/**
 * Fetch backup data from Google Drive (for manual restore)
 */
export async function downloadBackupFromDrive(): Promise<{
  success: boolean;
  data?: any;
  error?: string;
}> {
  if (!cachedAccessToken) {
    return { success: false, error: 'গুগল ড্রাইভ সংযুক্ত নয়' };
  }

  try {
    const token = cachedAccessToken;
    const fileId = await findBackupFile(token);
    if (!fileId) {
      return { success: false, error: 'গুগল ড্রাইভে কোনো পূর্ববর্তী ব্যাকআপ ফাইল খুঁজে পাওয়া যায়নি' };
    }

    const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!res.ok) {
      throw new Error(`ব্যাকআপ ফাইল লোড করা যায়নি (${res.status})`);
    }

    const json = await res.json();
    return { success: true, data: json };
  } catch (err: any) {
    console.error('Error fetching drive backup:', err);
    return { success: false, error: err?.message || 'ব্যাকআপ ফাইল ডাউনলোডে সমস্যা হয়েছে' };
  }
}
