import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import {ErrorBoundary} from './components/ErrorBoundary.tsx';
import './index.css';
import {registerSW} from 'virtual:pwa-register';

// Register service worker for offline Web APK functionality
if ('serviceWorker' in navigator && typeof window !== 'undefined') {
  registerSW({
    immediate: true,
    onRegisterError() {
      // Benign in sandboxed iframe or development environments
    },
    onNeedRefresh() {
      console.log('New content available, auto-updating...');
    },
    onOfflineReady() {
      console.log('Raju Daily Summary is ready to run offline.');
    },
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </StrictMode>,
);

