import React, { useState, useEffect, useMemo } from 'react';
import {
  PRODUCT_DATA,
  GROUP_COLORS,
  GROUP_RANGES,
  DEFAULT_PRODUCTS,
  getStoredProducts,
  saveStoredProducts,
  resetStoredProducts,
  Product
} from './data/products';
import { AppStorageData, DayData, HistoryEntry, UnlistedItem } from './types';
import { PWAInstallButton } from './components/PWAInstallButton';
import { OfflineIndicator } from './components/OfflineIndicator';
import { BottomProductSummary } from './components/BottomProductSummary';
import { CategoryOrderSummary } from './components/CategoryOrderSummary';
import { ProductPriceManagerModal } from './components/ProductPriceManagerModal';
import { DashboardView } from './components/DashboardView';
import { CATEGORIES } from './data/categories';
import { AnimatedCounter } from './components/AnimatedCounter';
import { generateDailySummaryPDF } from './utils/pdfReport';
import { DailyNotificationSettings } from './components/DailyNotificationSettings';
import { DailyReminderDueBanner } from './components/DailyReminderDueBanner';
import { useDailyNotification } from './hooks/useDailyNotification';
import { BillSplitterChat } from './components/BillSplitterChat';
import { ProductCatalogView } from './components/ProductCatalogView';
import { GoogleDriveSyncCard } from './components/GoogleDriveSyncCard';
import { HistorySummaryCard } from './components/HistorySummaryCard';
import {
  initAuth as initDriveAuth,
  subscribeToDriveSyncState,
  triggerDebouncedDriveSync,
  isGoogleDriveConnected,
  getDriveSyncState,
  DriveSyncState
} from './services/googleDriveService';
import {
  getStoredProductImages,
  saveStoredProductImages,
  requestPersistentStorage,
  loadImagesFromIndexedDB,
  exportAllPhotosJSON,
  ProductImageMap
} from './utils/productImages';
import {
  Calendar,
  Plus,
  RotateCcw,
  Printer,
  Search,
  CheckCheck,
  History,
  Trash2,
  Download,
  Upload,
  Layers,
  LayoutDashboard,
  ShoppingBag,
  X,
  PlusCircle,
  MinusCircle,
  Edit3,
  FileText,
  FileDown,
  Loader2,
  CheckSquare,
  FileSpreadsheet,
  AlertTriangle,
  Flame,
  Wifi,
  WifiOff,
  Settings2,
  Sliders,
  Sun,
  Moon,
  Tag,
  PackagePlus,
  Check,
  FolderArchive,
  Code,
  Bell,
  BellRing,
  BellOff,
  Sparkles,
  Smartphone,
  Camera,
  Cloud,
  CloudUpload,
  CloudOff,
  RefreshCw,
  FileCode
} from 'lucide-react';

const STORAGE_KEY_DATA = 'hubhub-counter-data';
const STORAGE_KEY_HISTORY = 'hubhub-counter-history';
const STORAGE_KEY_AUTO_CALC_SYNC = 'raju-auto-calc-sync';
const STORAGE_KEY_THEME = 'raju-theme';

function getTodayString(): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function money(n: number | string): string {
  return Number(n || 0).toLocaleString('en-US');
}

export default function App() {
  const [currentDate, setCurrentDate] = useState<string>(getTodayString());
  // Persistent dynamic products catalog
  const [products, setProducts] = useState<Product[]>(() => getStoredProducts());
  const [inputs, setInputs] = useState<number[]>(() => Array(products.length).fill(0));
  const [notes, setNotes] = useState<string[]>(() => Array(products.length).fill(''));
  const [isPriceManagerOpen, setIsPriceManagerOpen] = useState<boolean>(false);
  const [quickEditProductId, setQuickEditProductId] = useState<number | null>(null);
  const [quickEditPrice, setQuickEditPrice] = useState<string>('');
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editingNoteText, setEditingNoteText] = useState<string>('');
  const [isSelectionMode, setIsSelectionMode] = useState<boolean>(false);
  const [selectedEntryIds, setSelectedEntryIds] = useState<string[]>([]);
  const [showAllHistory, setShowAllHistory] = useState<boolean>(false);
  const [data, setData] = useState<AppStorageData>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_DATA);
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  const [globalHistory, setGlobalHistory] = useState<HistoryEntry[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [searchQuery, setSearchQuery] = useState('');
  const [historySearchQuery, setHistorySearchQuery] = useState('');
  const [historyProductFilter, setHistoryProductFilter] = useState('all');
  const [selectedGroup, setSelectedGroup] = useState<number | 'all' | 'most-frequent'>('all');
  const [showBackupModal, setShowBackupModal] = useState(false);
  const [showProductManagerModal, setShowProductManagerModal] = useState(false);
  const [activeViewMode, setActiveViewMode] = useState<'catalog' | 'counter' | 'dashboard' | 'history' | 'splitter'>('catalog');
  const [imageMap, setImageMap] = useState<ProductImageMap>(() => getStoredProductImages());
  const [hasSampleData, setHasSampleData] = useState<boolean>(false);
  const [autoCalcSync, setAutoCalcSync] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_AUTO_CALC_SYNC);
      return saved !== null ? saved === 'true' : true;
    } catch {
      return true;
    }
  });

  // Handler to add sample history across past weeks for testing Dashboard weekly/monthly cards
  const handleAddSampleHistory = () => {
    const today = new Date();
    const updated = { ...data };
    let addedCount = 0;

    for (let offset = 1; offset <= 28; offset++) {
      // Skip weekends (Friday/Saturday) to simulate a realistic business week
      if (offset % 7 === 0 || offset % 7 === 6) continue;

      const d = new Date(today);
      d.setDate(today.getDate() - offset);
      const y = d.getFullYear();
      const m = String(d.getMonth() + 1).padStart(2, '0');
      const dt = String(d.getDate()).padStart(2, '0');
      const dateStr = `${y}-${m}-${dt}`;

      if (!updated[dateStr] || !updated[dateStr].sum || updated[dateStr].sum.reduce((a, b) => a + b, 0) === 0) {
        addedCount++;
        const sumArray = Array(products.length).fill(0);
        const seed = (offset * 17) % products.length;

        // Populate realistic sold quantities for 8 to 14 products
        for (let i = 0; i < 10; i++) {
          const pIdx = (seed + i * 3) % products.length;
          const qty = ((i * 7 + offset * 3) % 20) + 4;
          sumArray[pIdx] = qty;
        }

        const history: HistoryEntry[] = [];
        for (let mIdx = 1; mIdx <= 3; mIdx++) {
          const pIdx = (seed + mIdx) % products.length;
          const p = products[pIdx];
          const qty = 10 + mIdx * 2;
          history.push({
            id: `sample-${dateStr}-${mIdx}`,
            date: dateStr,
            time: `${9 + mIdx * 2}:30 AM`,
            productIndex: pIdx,
            productName: p?.name || 'পণ্য',
            quantity: qty,
            amount: qty * (p?.price || 10),
            note: `মেমো-০${mIdx}`,
          });
        }

        updated[dateStr] = {
          sum: sumArray,
          history,
          unlistedItems: offset % 5 === 0 ? [
            {
              id: `unlisted-${dateStr}`,
              name: 'স্পেশাল বিস্কুট',
              quantity: 8,
              price: 35,
              timestamp: `${dateStr} 11:30`,
            }
          ] : [],
        };
      }
    }

    setData(updated);
    try {
      localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(updated));
    } catch {
      // ignore
    }
    setHasSampleData(true);
    showToast(`বিগত ৪ সপ্তাহের (${addedCount} দিনের) নমুনা বিক্রয় ডাটা লোড হয়েছে!`);
  };

  const handleClearSampleHistory = () => {
    const updated: AppStorageData = {};
    if (data[currentDate]) {
      updated[currentDate] = data[currentDate];
    }
    setData(updated);
    try {
      localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(updated));
    } catch {
      // ignore
    }
    setHasSampleData(false);
    showToast('নমুনা ডাটা মুছে ফেলা হয়েছে।');
  };

  // Handler for product updates (price change, name change, add product, delete product)
  const handleUpdateProducts = (newProducts: Product[], message?: string) => {
    setProducts(newProducts);
    saveStoredProducts(newProducts);
    setInputs((prev) => {
      const copy = [...prev];
      while (copy.length < newProducts.length) copy.push(0);
      return copy;
    });
    setNotes((prev) => {
      const copy = [...prev];
      while (copy.length < newProducts.length) copy.push('');
      return copy;
    });
    if (message) {
      showToast(message);
    }
  };

  // Reset to default 43 products
  const handleResetProducts = () => {
    const resetList = resetStoredProducts();
    setProducts(resetList);
    setInputs(Array(resetList.length).fill(0));
    setNotes(Array(resetList.length).fill(''));
    showToast('মূল ৪৩টি পণ্যের ডিফল্ট প্রাইজ ও তালিকা সফলভাবে রিস্টোর করা হয়েছে!');
  };

  // Inline Quick Price Edit
  const handleStartInlineEdit = (p: Product) => {
    setQuickEditProductId(p.id);
    setQuickEditPrice(p.price.toString());
  };

  const handleSaveInlineEdit = (productId: number) => {
    const parsed = parseFloat(quickEditPrice);
    if (isNaN(parsed) || parsed < 0) {
      showToast('অনুগ্রহ করে সঠিক মূল্য প্রদান করুন');
      return;
    }
    const updated = products.map((p) => (p.id === productId ? { ...p, price: parsed } : p));
    const prodName = products[productId]?.name || `পণ্য ${productId + 1}`;
    handleUpdateProducts(updated, `"${prodName}" এর প্রাইজ ৳ ${parsed} টাকা নির্ধারণ করা হয়েছে!`);
    setQuickEditProductId(null);
  };

  // Global theme state with localStorage persistence and system fallback
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_THEME);
      if (saved === 'dark' || saved === 'light') {
        return saved;
      }
      return typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches
        ? 'dark'
        : 'light';
    } catch {
      return 'light';
    }
  });

  // Sync theme class on documentElement and persist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_THEME, theme);
    } catch (e) {
      console.error('Failed to save theme setting', e);
    }
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Hydrate persistent images from IndexedDB and request browser persistence
  useEffect(() => {
    requestPersistentStorage();
    loadImagesFromIndexedDB().then((idbImages) => {
      if (idbImages && Object.keys(idbImages).length > 0) {
        setImageMap((current) => {
          const merged = { ...idbImages, ...current };
          saveStoredProductImages(merged);
          return merged;
        });
      }
    });
  }, []);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  // Persist autoCalcSync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_AUTO_CALC_SYNC, String(autoCalcSync));
    } catch (e) {
      console.error('Failed to save autoCalcSync setting', e);
    }
  }, [autoCalcSync]);

  const [manualOverrideModal, setManualOverrideModal] = useState<{
    isOpen: boolean;
    product: Product;
    currentQty: number;
    newQty: string;
  } | null>(null);

  const [deleteModal, setDeleteModal] = useState<{
    isOpen: boolean;
    type: 'single' | 'bulk' | 'reset-product';
    entry?: HistoryEntry;
    entries?: HistoryEntry[];
    product?: Product;
  } | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [pdfProgressStatus, setPdfProgressStatus] = useState('');
  const parseBanglaOrEnglishNumber = (str: string): number => {
    const banglaToEng: Record<string, string> = {
      '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
      '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
    };
    const engStr = str.split('').map((c) => banglaToEng[c] || c).join('');
    return parseInt(engStr, 10);
  };

  const getNextMemoForDate = (targetDate: string, sourceData?: AppStorageData): string => {
    try {
      const savedForDate = localStorage.getItem(`raju-active-memo-${targetDate}`);
      if (savedForDate && savedForDate.trim()) {
        return savedForDate;
      }
    } catch {}

    const storage = sourceData || data;
    const day = storage[targetDate];
    if (day && Array.isArray(day.history) && day.history.length > 0) {
      const memoNums: number[] = [];
      day.history.forEach((h) => {
        if (h.note) {
          const match = h.note.match(/(\d+|[০-৯]+)$/);
          if (match) {
            const n = parseBanglaOrEnglishNumber(match[1]);
            if (!isNaN(n) && n > 0) memoNums.push(n);
          }
        }
      });
      if (memoNums.length > 0) {
        const maxNum = Math.max(...memoNums);
        const nextNum = maxNum + 1;
        const formatted = nextNum < 10 ? `0${nextNum}` : `${nextNum}`;
        return `মেমো নাম্বার.${formatted}`;
      }
    }

    return 'মেমো নাম্বার.01';
  };

  const [activeMemo, setActiveMemo] = useState<string>(() => {
    try {
      const today = new Date();
      const y = today.getFullYear();
      const m = String(today.getMonth() + 1).padStart(2, '0');
      const d = String(today.getDate()).padStart(2, '0');
      const todayStr = `${y}-${m}-${d}`;
      const savedForDate = localStorage.getItem(`raju-active-memo-${todayStr}`);
      if (savedForDate && savedForDate.trim()) {
        return savedForDate;
      }
    } catch {}
    return 'মেমো নাম্বার.01';
  });

  const updateActiveMemo = (val: string, forDate: string = currentDate) => {
    setActiveMemo(val);
    try {
      localStorage.setItem('raju-active-memo', val);
      localStorage.setItem(`raju-active-memo-${forDate}`, val);
    } catch {}
  };

  const incrementMemoString = (memo: string): string => {
    const raw = (memo || '').trim();
    if (!raw) return 'মেমো নাম্বার.02';

    const banglaToEng: Record<string, string> = {
      '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
      '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9'
    };
    const engToBangla: Record<string, string> = {
      '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪',
      '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯'
    };

    const regex = /(\d+|[০-৯]+)$/;
    const match = raw.match(regex);
    if (match) {
      const numStr = match[1];
      const isBangla = /[০-৯]/.test(numStr);
      const engNumStr = numStr.split('').map((c) => banglaToEng[c] || c).join('');
      const nextNum = parseInt(engNumStr, 10) + 1;
      const padded = (numStr.length >= 2 || nextNum < 10) ? (nextNum < 10 ? `0${nextNum}` : `${nextNum}`) : `${nextNum}`;
      const formatted = isBangla
        ? padded.split('').map((c) => engToBangla[c] || c).join('')
        : padded;
      return raw.replace(regex, formatted);
    }

    return `${raw}.02`;
  };

  // Reset or initialize memo counter scoped per day whenever currentDate changes
  useEffect(() => {
    const memoForDate = getNextMemoForDate(currentDate);
    setActiveMemo(memoForDate);
    try {
      localStorage.setItem('raju-active-memo', memoForDate);
      localStorage.setItem(`raju-active-memo-${currentDate}`, memoForDate);
    } catch {}
  }, [currentDate]);

  // Show temporary toast feedback
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Daily Summary Notification hook (PWA Notification API & In-App Reminder)
  const {
    config: notificationConfig,
    inAppReminderDue,
    dismissInAppReminder,
  } = useDailyNotification(() => {
    showToast('🔔 দৈনিক সামারি নোটিফিকেশন: আজকের বিক্রয় রিপোর্ট ডাউনলোডের সময় হয়েছে!');
  });

  // Offline status detection for Web APK
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      showToast('ইন্টারনেট সংযুক্ত (অনলাইন)');
    };
    const handleOffline = () => {
      setIsOnline(false);
      showToast('📶 অফলাইন মোড সক্রিয় — নেট ছাড়াই অ্যাপ সম্পূর্ণ সচল আছে');
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Ensure current day exists in storage state
  const currentDayData: DayData = useMemo(() => {
    if (data[currentDate] && Array.isArray(data[currentDate].sum)) {
      const prevSum = data[currentDate].sum;
      if (prevSum.length === products.length) {
        return {
          ...data[currentDate],
          unlistedItems: data[currentDate].unlistedItems || []
        };
      }
      const adjustedSum = Array(products.length).fill(0);
      for (let i = 0; i < Math.min(prevSum.length, products.length); i++) {
        adjustedSum[i] = prevSum[i] || 0;
      }
      return {
        ...data[currentDate],
        sum: adjustedSum,
        unlistedItems: data[currentDate].unlistedItems || []
      };
    }
    return {
      sum: Array(products.length).fill(0),
      history: [],
      unlistedItems: []
    };
  }, [data, currentDate, products.length]);

  // Persist to localStorage whenever data or globalHistory changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save data to localStorage', e);
    }
  }, [data]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(globalHistory));
    } catch (e) {
      console.error('Failed to save history to localStorage', e);
    }
  }, [globalHistory]);

  // Google Drive Auth & Sync State Subscription
  const [driveSyncState, setDriveSyncState] = useState<DriveSyncState>(() => getDriveSyncState());

  useEffect(() => {
    const unsubscribeAuth = initDriveAuth();
    const unsubscribeSync = subscribeToDriveSyncState((state) => {
      setDriveSyncState(state);
    });

    return () => {
      unsubscribeAuth();
      unsubscribeSync();
    };
  }, []);

  // Data-sync listener that automatically triggers an upload to Google Drive whenever 'data' or 'globalHistory' changes
  const isInitialSyncMount = React.useRef(true);
  useEffect(() => {
    if (isInitialSyncMount.current) {
      isInitialSyncMount.current = false;
      return;
    }

    if (isGoogleDriveConnected()) {
      triggerDebouncedDriveSync(() => ({
        version: 2,
        appName: 'Raju Daily Summary',
        exportDate: new Date().toISOString(),
        currentDate,
        data,
        globalHistory,
        products,
        imageMap
      }), 1500);
    }
  }, [data, globalHistory]);

  // Update input quantity for product i
  const handleInputChange = (index: number, val: number) => {
    const qty = Math.max(0, isNaN(val) ? 0 : Math.floor(val));
    setInputs((prev) => {
      const copy = [...prev];
      copy[index] = qty;
      return copy;
    });
  };

  // Update note/remark for product i
  const handleNoteChange = (index: number, val: string) => {
    setNotes((prev) => {
      const copy = [...prev];
      copy[index] = val;
      return copy;
    });
  };

  // Quick increment
  const handleQuickAdd = (index: number, amount: number) => {
    setInputs((prev) => {
      const copy = [...prev];
      copy[index] = Math.max(0, (copy[index] || 0) + amount);
      return copy;
    });
  };

  // Add single product quantity to current day sum
  const addOne = (index: number) => {
    const qty = inputs[index] || 0;
    if (qty <= 0) return;

    const prod = products[index];
    if (!prod) return;
    const amount = qty * prod.price;
    const now = new Date();
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    const rawNote = (notes[index] || '').trim();
    const memoText = rawNote || (activeMemo.trim() ? activeMemo.trim() : undefined);

    const newEntry: HistoryEntry = {
      id: `${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      date: currentDate,
      time: timeStr,
      productIndex: index,
      productName: prod.name,
      quantity: qty,
      amount,
      note: memoText
    };

    setData((prev) => {
      const prevDay = prev[currentDate] || {
        sum: Array(products.length).fill(0),
        history: []
      };
      const newSum = [...prevDay.sum];
      newSum[index] = (newSum[index] || 0) + qty;
      const newHistory = [newEntry, ...prevDay.history];

      return {
        ...prev,
        [currentDate]: {
          sum: newSum,
          history: newHistory
        }
      };
    });

    setGlobalHistory((prev) => [newEntry, ...prev]);

    // Reset this input to 0 and note to empty immediately
    setInputs((prev) => {
      const copy = [...prev];
      copy[index] = 0;
      return copy;
    });
    setNotes((prev) => {
      const copy = [...prev];
      copy[index] = '';
      return copy;
    });

    showToast(`যোগ হয়েছে: ${prod.name} (${qty} পিস = ${money(amount)} টাকা)${memoText ? ` [${memoText}]` : ''}`);
  };

  // Deduct / Subtract one (in case of mistake)
  const removeOne = (index: number) => {
    const currentSum = currentDayData.sum[index] || 0;
    if (currentSum <= 0) {
      showToast('এই পণ্যের কোনো জমা নেই!');
      return;
    }

    const qtyToSubtract = inputs[index] > 0 ? inputs[index] : 1;
    const actualSubtracted = Math.min(qtyToSubtract, currentSum);
    const prod = products[index];
    if (!prod) return;

    setData((prev) => {
      const prevDay = prev[currentDate];
      if (!prevDay) return prev;
      const newSum = [...prevDay.sum];
      newSum[index] = Math.max(0, newSum[index] - actualSubtracted);
      return {
        ...prev,
        [currentDate]: {
          ...prevDay,
          sum: newSum
        }
      };
    });

    setInputs((prev) => {
      const copy = [...prev];
      copy[index] = 0;
      return copy;
    });

    showToast(`কমানো হয়েছে: ${prod.name} (-${actualSubtracted} পিস)`);
  };

  // Start new memo: clears inputs and increments active memo number (scoped to currentDate)
  const startNewMemo = (customToast?: string | unknown, fromMemo?: string) => {
    setInputs(Array(products.length).fill(0));
    setNotes(Array(products.length).fill(''));
    const baseMemo = (typeof fromMemo === 'string' && fromMemo.trim() ? fromMemo : activeMemo).trim() || 'মেমো নাম্বার.01';
    const nextMemo = incrementMemoString(baseMemo);
    updateActiveMemo(nextMemo, currentDate);
    const toastMsg = typeof customToast === 'string' && customToast ? customToast : `নতুন মেমো শুরু হয়েছে: ${nextMemo}`;
    showToast(toastMsg);
  };

  // Add all non-zero inputs at once
  const addAll = () => {
    const toAdd: { index: number; qty: number }[] = [];
    inputs.forEach((qty, idx) => {
      if (qty > 0) {
        toAdd.push({ index: idx, qty });
      }
    });

    if (toAdd.length === 0) {
      showToast('কোনো Quantity দেওয়া হয়নি!');
      return;
    }

    const now = new Date();
    const timeStr = now.toLocaleTimeString('bn-BD', { hour: '2-digit', minute: '2-digit' });
    const newEntries: HistoryEntry[] = [];

    // Current batch memo - guaranteed to start with a valid memo like 'মেমো নাম্বার.01'
    const currentBatchMemo = activeMemo.trim() || 'মেমো নাম্বার.01';

    setData((prev) => {
      const prevDay = prev[currentDate] || {
        sum: Array(products.length).fill(0),
        history: []
      };
      const newSum = [...prevDay.sum];

      toAdd.forEach(({ index, qty }) => {
        newSum[index] = (newSum[index] || 0) + qty;
        const rawNote = (notes[index] || '').trim();
        const memoText = rawNote || currentBatchMemo;
        const prod = products[index] || { name: `পণ্য ${index + 1}`, price: 0 };
        const entry: HistoryEntry = {
          id: `${Date.now()}-${index}-${Math.random().toString(36).substr(2, 4)}`,
          date: currentDate,
          time: timeStr,
          productIndex: index,
          productName: prod.name,
          quantity: qty,
          amount: qty * prod.price,
          note: memoText
        };
        newEntries.push(entry);
      });

      return {
        ...prev,
        [currentDate]: {
          sum: newSum,
          history: [...newEntries, ...prevDay.history]
        }
      };
    });

    setGlobalHistory((prev) => [...newEntries, ...prev]);

    // Automatically trigger startNewMemo logic once all items are successfully added to history
    startNewMemo(
      `মেমো [${currentBatchMemo}] এর ${toAdd.length}টি পণ্য সফলভাবে যোগ হয়েছে! পরবর্তী মেমো: ${incrementMemoString(currentBatchMemo)}`,
      currentBatchMemo
    );
  };

  // Reset current uncommitted inputs
  const resetCurrentInputs = () => {
    setInputs(Array(products.length).fill(0));
    setNotes(Array(products.length).fill(''));
    showToast('সব Quantity ও মেমো ঘর রিসেট করা হয়েছে।');
  };

  // Save edited note for a history entry
  const saveEditedNote = (entryId: string) => {
    const trimmed = editingNoteText.trim();
    const updatedVal = trimmed.length > 0 ? trimmed : undefined;

    setData((prev) => {
      const updated = { ...prev };
      for (const d of Object.keys(updated)) {
        if (updated[d].history.some((h) => h.id === entryId)) {
          updated[d] = {
            ...updated[d],
            history: updated[d].history.map((h) =>
              h.id === entryId ? { ...h, note: updatedVal } : h
            )
          };
        }
      }
      return updated;
    });

    setGlobalHistory((prev) =>
      prev.map((h) => (h.id === entryId ? { ...h, note: updatedVal } : h))
    );

    setEditingNoteId(null);
    setEditingNoteText('');
    showToast('মেমো নম্বর সফলভাবে আপডেট করা হয়েছে!');
  };

  // Clear selected history entries if current date changes
  useEffect(() => {
    setSelectedEntryIds([]);
  }, [currentDate]);

  // Unique products present in current day's history for dropdown filtering
  const historyProductOptions = useMemo(() => {
    const set = new Set<string>();
    (currentDayData.history || []).forEach((h) => {
      if (h.productName) set.add(h.productName);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, 'bn'));
  }, [currentDayData.history]);

  // Filtered history entries for History View
  const filteredHistory = useMemo(() => {
    let list = currentDayData.history || [];
    if (historySearchQuery.trim()) {
      const q = historySearchQuery.toLowerCase().trim();
      list = list.filter(
        (h) =>
          h.productName.toLowerCase().includes(q) ||
          (h.note && h.note.toLowerCase().includes(q)) ||
          String(h.quantity).includes(q) ||
          String(h.amount).includes(q) ||
          (h.time && h.time.toLowerCase().includes(q))
      );
    }
    if (historyProductFilter !== 'all') {
      list = list.filter((h) => h.productName === historyProductFilter);
    }
    return list;
  }, [currentDayData.history, historySearchQuery, historyProductFilter]);

  // Summary card stats for the currently filtered result set in History View
  const filteredHistorySummary = useMemo(() => {
    let totalEntries = filteredHistory.length;
    let totalItemsSold = 0;
    let totalRevenue = 0;
    for (const h of filteredHistory) {
      totalItemsSold += (Number(h.quantity) || 0);
      totalRevenue += (Number(h.amount) || 0);
    }
    return {
      totalEntries,
      totalItemsSold,
      totalRevenue
    };
  }, [filteredHistory]);

  // History entries displayed in the History View table (with 50 items slice unless showAllHistory)
  const displayedHistoryViewList = useMemo(() => {
    if (showAllHistory || filteredHistory.length <= 50) {
      return filteredHistory;
    }
    return filteredHistory.slice(0, 50);
  }, [filteredHistory, showAllHistory]);

  const toggleSelectAllInHistoryView = () => {
    if (displayedHistoryViewList.length === 0) return;
    const visibleIds = displayedHistoryViewList.map((h) => h.id);
    const allVisibleSelected = visibleIds.every((id) => selectedEntryIds.includes(id));
    if (allVisibleSelected) {
      setSelectedEntryIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      setSelectedEntryIds((prev) => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  // Visible history considering 50 limit or show all, and search filter
  const visibleHistory = useMemo(() => {
    let list = currentDayData.history;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(
        (h) =>
          h.productName.toLowerCase().includes(q) ||
          (h.note && h.note.toLowerCase().includes(q)) ||
          String(h.quantity).includes(q) ||
          String(h.amount).includes(q)
      );
    }
    if (showAllHistory || list.length <= 50) {
      return list;
    }
    return list.slice(0, 50);
  }, [currentDayData.history, showAllHistory, searchQuery]);

  // Calculate selected summary
  const selectedSummary = useMemo(() => {
    if (selectedEntryIds.length === 0) return { count: 0, pieces: 0, amount: 0 };
    const selectedSet = new Set(selectedEntryIds);
    let pieces = 0;
    let amount = 0;
    let count = 0;
    currentDayData.history.forEach((h) => {
      if (selectedSet.has(h.id)) {
        count++;
        pieces += h.quantity;
        amount += h.amount;
      }
    });
    return { count, pieces, amount };
  }, [selectedEntryIds, currentDayData.history]);

  const toggleSelectEntry = (id: string) => {
    setSelectedEntryIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (visibleHistory.length === 0) return;
    const visibleIds = visibleHistory.map((h) => h.id);
    const allVisibleSelected = visibleIds.every((id) => selectedEntryIds.includes(id));
    if (allVisibleSelected) {
      setSelectedEntryIds((prev) => prev.filter((id) => !visibleIds.includes(id)));
    } else {
      setSelectedEntryIds((prev) => Array.from(new Set([...prev, ...visibleIds])));
    }
  };

  // Helper to reliably find product index by stored index, name, or unit price
  const resolveProductIndex = (entry: HistoryEntry): number => {
    // 1. By stored index if valid and name matches
    if (
      typeof entry.productIndex === 'number' &&
      entry.productIndex >= 0 &&
      entry.productIndex < products.length &&
      products[entry.productIndex].name === entry.productName
    ) {
      return entry.productIndex;
    }

    // 2. By exact product name
    const byExact = products.findIndex((p) => p.name === entry.productName);
    if (byExact !== -1) return byExact;

    // 3. By normalized name
    const clean = (str: string) => (str || '').replace(/[\s_\-–]+/g, '').toLowerCase();
    const byClean = products.findIndex((p) => clean(p.name) === clean(entry.productName));
    if (byClean !== -1) return byClean;

    // 4. By partial match
    const byPartial = products.findIndex(
      (p) => p.name.includes(entry.productName) || entry.productName.includes(p.name)
    );
    if (byPartial !== -1) return byPartial;

    // 5. By unit price (amount / quantity)
    if (entry.quantity > 0 && entry.amount > 0) {
      const unitPrice = Math.round(entry.amount / entry.quantity);
      const byPrice = products.findIndex((p) => p.price === unitPrice);
      if (byPrice !== -1) return byPrice;
    }

    // 6. Fallback to index if within bounds
    if (typeof entry.productIndex === 'number' && entry.productIndex >= 0 && entry.productIndex < products.length) {
      return entry.productIndex;
    }

    return -1;
  };

  // Manual override of a product's cumulative total quantity (for complex reporting / inventory adjustment)
  const handleManualOverrideQty = (productId: number, customQty: number) => {
    const qty = Math.max(0, isNaN(customQty) ? 0 : Math.floor(customQty));
    setData((prev) => {
      const prevDay = prev[currentDate] || {
        sum: Array(products.length).fill(0),
        history: []
      };
      const newSum = [...prevDay.sum];
      newSum[productId] = qty;
      return {
        ...prev,
        [currentDate]: {
          ...prevDay,
          sum: newSum
        }
      };
    });
    const pName = products[productId]?.name || `পণ্য ${productId + 1}`;
    showToast(`"${pName}" এর মোট সংখ্যা ম্যানুয়ালি ${qty} পিস নির্ধারণ করা হয়েছে (ওভাররাইড)।`);
  };

  // Delete a history entry and deduct from current sum (if autoCalcSync is enabled)
  const executeDeleteHistoryEntry = (entry: HistoryEntry) => {
    const targetDate = entry.date || currentDate;
    const pIdx = resolveProductIndex(entry);

    setData((prev) => {
      const targetDay = prev[targetDate] || prev[currentDate];
      if (!targetDay) return prev;

      const newSum = Array(products.length).fill(0);
      for (let i = 0; i < products.length; i++) {
        newSum[i] = (targetDay.sum && targetDay.sum[i]) || 0;
      }

      // Only automatically deduct if autoCalcSync is enabled
      if (autoCalcSync) {
        if (pIdx >= 0 && pIdx < products.length) {
          newSum[pIdx] = Math.max(0, newSum[pIdx] - entry.quantity);
        }
      }

      const newHist = (targetDay.history || []).filter((h) => h.id !== entry.id);

      return {
        ...prev,
        [targetDate]: {
          sum: newSum,
          history: newHist
        }
      };
    });

    setGlobalHistory((prev) => prev.filter((h) => h.id !== entry.id));
    setSelectedEntryIds((prev) => prev.filter((id) => id !== entry.id));
    setDeleteModal(null);
    if (autoCalcSync) {
      showToast(`"${entry.productName}" (${entry.quantity} পিস) মুছে ফেলা হয়েছে এবং মোট হিসাব থেকে বাদ গেছে।`);
    } else {
      showToast(`"${entry.productName}" মেমো এন্ট্রি মুছে ফেলা হয়েছে (অটো সিঙ্ক বন্ধ থাকায় ম্যানুয়াল রিপোর্ট মোট অপরিবর্তিত)।`);
    }
  };

  // Add an unlisted item (Others / লিস্টের বাইরে)
  const handleAddUnlistedItem = (item: Omit<UnlistedItem, 'id' | 'timestamp'>) => {
    const newItem: UnlistedItem = {
      id: 'unlisted-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      name: item.name,
      quantity: item.quantity,
      price: item.price,
      note: item.note,
      timestamp: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
    };

    setData((prev) => {
      const prevDay = prev[currentDate] || {
        sum: Array(products.length).fill(0),
        history: [],
        unlistedItems: []
      };
      const prevUnlisted = prevDay.unlistedItems || [];
      return {
        ...prev,
        [currentDate]: {
          ...prevDay,
          unlistedItems: [newItem, ...prevUnlisted]
        }
      };
    });
  };

  // Delete an unlisted item
  const handleDeleteUnlistedItem = (id: string) => {
    setData((prev) => {
      const prevDay = prev[currentDate];
      if (!prevDay) return prev;
      const prevUnlisted = prevDay.unlistedItems || [];
      return {
        ...prev,
        [currentDate]: {
          ...prevDay,
          unlistedItems: prevUnlisted.filter((u) => u.id !== id)
        }
      };
    });
    showToast('আনলিস্টেড পণ্যটি মুছে ফেলা হয়েছে।');
  };

  // Delete all selected history entries at once
  const executeBulkDelete = (entriesToDelete: HistoryEntry[]) => {
    if (entriesToDelete.length === 0) return;

    const idsSet = new Set(entriesToDelete.map((e) => e.id));
    const targetDate = currentDate;

    setData((prev) => {
      const prevDay = prev[targetDate];
      if (!prevDay) return prev;

      const newSum = Array(products.length).fill(0);
      for (let i = 0; i < products.length; i++) {
        newSum[i] = (prevDay.sum && prevDay.sum[i]) || 0;
      }

      if (autoCalcSync) {
        entriesToDelete.forEach((entry) => {
          const pIdx = resolveProductIndex(entry);
          if (pIdx >= 0 && pIdx < products.length) {
            newSum[pIdx] = Math.max(0, newSum[pIdx] - entry.quantity);
          }
        });
      }

      const newHist = (prevDay.history || []).filter((h) => !idsSet.has(h.id));

      return {
        ...prev,
        [targetDate]: {
          sum: newSum,
          history: newHist
        }
      };
    });

    setGlobalHistory((prev) => prev.filter((h) => !idsSet.has(h.id)));
    setSelectedEntryIds([]);
    setIsSelectionMode(false);
    setDeleteModal(null);
    if (autoCalcSync) {
      showToast(`নির্বাচিত ${entriesToDelete.length}টি এন্ট্রি মুছে ফেলা হয়েছে এবং মোট হিসাব আপডেট হয়েছে!`);
    } else {
      showToast(`নির্বাচিত ${entriesToDelete.length}টি এন্ট্রি মুছে ফেলা হয়েছে (অটো সিঙ্ক বন্ধ থাকায় ম্যানুয়াল রিপোর্ট মোট অপরিবর্তিত)।`);
    }
  };

  // Reset a specific product's sum to 0 directly from top table
  const executeResetProduct = (product: Product) => {
    setData((prev) => {
      const prevDay = prev[currentDate];
      if (!prevDay) return prev;

      const newSum = Array(products.length).fill(0);
      for (let i = 0; i < products.length; i++) {
        newSum[i] = (prevDay.sum && prevDay.sum[i]) || 0;
      }
      newSum[product.id] = 0;

      // Also clean matching history entries for today
      const newHist = (prevDay.history || []).filter((h) => {
        const pIdx = resolveProductIndex(h);
        return pIdx !== product.id;
      });

      return {
        ...prev,
        [currentDate]: {
          sum: newSum,
          history: newHist
        }
      };
    });

    setGlobalHistory((prev) =>
      prev.filter((h) => {
        if ((h.date || currentDate) !== currentDate) return true;
        const pIdx = resolveProductIndex(h);
        return pIdx !== product.id;
      })
    );

    setDeleteModal(null);
    showToast(`"${product.name}" এর আজকের মোট জমা মুছে ০ করা হয়েছে।`);
  };

  // Re-sync today's product sums from history entries
  const resyncCurrentDay = () => {
    setData((prev) => {
      const prevDay = prev[currentDate];
      if (!prevDay) return prev;

      const newSum = Array(products.length).fill(0);
      (prevDay.history || []).forEach((entry) => {
        const pIdx = resolveProductIndex(entry);
        if (pIdx >= 0 && pIdx < products.length) {
          newSum[pIdx] += entry.quantity || 0;
        }
      });

      return {
        ...prev,
        [currentDate]: {
          sum: newSum,
          history: prevDay.history || []
        }
      };
    });
    showToast('মেমো হিস্ট্রি অনুযায়ী উপরের মোট হিসাব সিঙ্ক ও রিক্যালকুলেট হয়েছে!');
  };

  // Calculate day totals
  const totalDayMoney = useMemo(() => {
    const listSum = currentDayData.sum.reduce((acc, qty, idx) => {
      const price = products[idx]?.price || 0;
      return acc + (qty || 0) * price;
    }, 0);
    const unlistedSum = (currentDayData.unlistedItems || []).reduce((acc, u) => {
      return acc + (u.quantity || 0) * (u.price || 0);
    }, 0);
    return listSum + unlistedSum;
  }, [currentDayData, products]);

  const totalDayPieces = useMemo(() => {
    const listPieces = currentDayData.sum.reduce((acc, qty) => acc + (qty || 0), 0);
    const unlistedPieces = (currentDayData.unlistedItems || []).reduce((acc, u) => acc + (u.quantity || 0), 0);
    return listPieces + unlistedPieces;
  }, [currentDayData]);

  // Uncommitted inputs total
  const uncommittedTotal = useMemo(() => {
    let pieces = 0;
    let moneyAmt = 0;
    inputs.forEach((qty, idx) => {
      if (qty > 0) {
        pieces += qty;
        const price = products[idx]?.price || 0;
        moneyAmt += qty * price;
      }
    });
    return { pieces, moneyAmt };
  }, [inputs, products]);

  // Group calculations
  const groupSummaries = useMemo(() => {
    return [0, 1, 2, 3, 4, 5, 6, 7].map((groupIdx) => {
      let pieces = 0;
      let amount = 0;
      products.forEach((p) => {
        if (p.groupIndex === groupIdx) {
          const q = currentDayData.sum[p.id] || 0;
          pieces += q;
          amount += q * p.price;
        }
      });
      return {
        groupIdx,
        name: `Group ${groupIdx + 1}`,
        color: GROUP_COLORS[groupIdx] || '#ffffff',
        pieces,
        amount
      };
    });
  }, [currentDayData, products]);

  // Product frequency calculation: how many times each product has been added to history today
  const productFrequencyMap = useMemo(() => {
    const counts = Array(products.length).fill(0);
    (currentDayData.history || []).forEach((entry) => {
      const pIdx = resolveProductIndex(entry);
      if (pIdx >= 0 && pIdx < products.length) {
        counts[pIdx] += 1;
      }
    });
    return counts;
  }, [currentDayData.history, products.length]);

  // Maximum addition frequency today
  const maxFrequency = useMemo(() => {
    return Math.max(0, ...productFrequencyMap);
  }, [productFrequencyMap]);

  // Products added the most times today (Most Frequent Products)
  const mostFrequentProducts = useMemo(() => {
    if (maxFrequency <= 0) return [];
    return products.filter((p) => productFrequencyMap[p.id] === maxFrequency);
  }, [productFrequencyMap, maxFrequency, products]);

  // Memo Counter Scope: 'day' (default) or 'all'
  const [memoCounterScope, setMemoCounterScope] = useState<'day' | 'all'>('day');

  // Day's Memo Counter (strictly count of saved memos & sum of quantities, NO money/sales amount):
  // If one memo contains multiple products (same memo note or batch), their quantities add together.
  const dayMemoStats = useMemo(() => {
    const history = currentDayData.history || [];
    const memoMap = new Map<string, number>();

    history.forEach((entry) => {
      const qty = Number(entry.quantity) || 0;
      const note = (entry.note || '').trim();
      // If note exists (e.g., "Memo 1", "01"), group all items under that memo identifier;
      // otherwise, group by unique entry ID so unnoted transactions each count as 1 memo.
      const key = note ? `note_${note.toLowerCase()}` : `id_${entry.id}`;
      memoMap.set(key, (memoMap.get(key) || 0) + qty);
    });

    const totalMemos = memoMap.size;
    let totalItems = 0;
    memoMap.forEach((qty) => {
      totalItems += qty;
    });

    return { totalMemos, totalItems };
  }, [currentDayData.history]);

  // All-time saved memos across all dates in the database (NO money/sales amount):
  const allTimeMemoStats = useMemo(() => {
    const memoMap = new Map<string, number>();

    Object.entries(data as Record<string, DayData>).forEach(([dateKey, dayObj]) => {
      const hist = (dayObj?.history || []) as HistoryEntry[];
      hist.forEach((entry) => {
        const qty = Number(entry.quantity) || 0;
        const note = (entry.note || '').trim();
        const key = note ? `${dateKey}_note_${note.toLowerCase()}` : `id_${entry.id}`;
        memoMap.set(key, (memoMap.get(key) || 0) + qty);
      });
    });

    const totalMemos = memoMap.size;
    let totalItems = 0;
    memoMap.forEach((qty) => {
      totalItems += qty;
    });

    return { totalMemos, totalItems };
  }, [data]);

  const displayMemos = memoCounterScope === 'day' ? dayMemoStats.totalMemos : allTimeMemoStats.totalMemos;
  const displayItems = memoCounterScope === 'day' ? dayMemoStats.totalItems : allTimeMemoStats.totalItems;

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesSearch =
        searchQuery === '' ||
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        String(p.price).includes(searchQuery);

      const matchesGroup =
        selectedGroup === 'all'
          ? true
          : selectedGroup === 'most-frequent'
          ? maxFrequency > 0 && productFrequencyMap[p.id] === maxFrequency
          : p.groupIndex === selectedGroup;

      return matchesSearch && matchesGroup;
    });
  }, [searchQuery, selectedGroup, productFrequencyMap, maxFrequency, products]);

  // Export current day's summary and history to CSV for Excel
  const exportDayCSV = () => {
    const escapeCSV = (val: string | number | undefined | null): string => {
      if (val === undefined || val === null) return '""';
      const str = String(val);
      if (str.includes(',') || str.includes('"') || str.includes('\n') || str.includes('\r')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      return `"${str}"`;
    };

    const lines: string[] = [];

    // Header & Meta Info
    lines.push('Raju Daily Summary (দৈনিক হিসাব ও মেমো হিস্ট্রি রিপোর্ট)');
    lines.push(`তারিখ (Date),${escapeCSV(currentDate)}`);
    lines.push(`রিপোর্ট তৈরির সময় (Generated At),${escapeCSV(new Date().toLocaleString('bn-BD'))}`);
    lines.push(`দিনের মোট বিক্রিত পরিমাণ (Total Pieces),${escapeCSV(totalDayPieces)}`);
    lines.push(`দিনের মোট বিক্রয় মূল্য (Total Amount),${escapeCSV(totalDayMoney + ' টাকা')}`);
    lines.push('');

    // SECTION 1: গ্রুপভিত্তিক সংক্ষেপ (Group Summary)
    lines.push('--- ১. গ্রুপভিত্তিক সারসংক্ষেপ (Group Summary) ---');
    lines.push(['গ্রুপ নং', 'গ্রুপ বিবরণ', 'পণ্য রেঞ্জ', 'মোট বিক্রয় (পিস)', 'মোট টাকা (টাকা)'].map(escapeCSV).join(','));
    groupSummaries.forEach((g) => {
      const range = (GROUP_RANGES && GROUP_RANGES[g.groupIdx]) || [0, 0];
      const [start, end] = range;
      lines.push([
        `গ্রুপ ${g.groupIdx + 1}`,
        `গ্রুপ ${g.groupIdx + 1} (${start + 1} থেকে ${end} নং পণ্য)`,
        `${start + 1} - ${end}`,
        g.pieces,
        g.amount
      ].map(escapeCSV).join(','));
    });
    lines.push(['সর্বমোট', 'সকল গ্রুপ মিলিয়ে', '-', totalDayPieces, totalDayMoney].map(escapeCSV).join(','));
    lines.push('');

    // SECTION 1.5: ক্যাটাগরি অনুযায়ী অর্ডার সামারি (Category-wise Order Summary)
    lines.push('--- ১.৫ ক্যাটাগরিভিত্তিক অর্ডার ও বিক্রয় সামারি (Category-Wise Summary) ---');
    lines.push(['ক্যাটাগরি নাম', 'ইংরেজি নাম', 'মোট অর্ডার (পিস)', 'মোট টাকা (টাকা)', 'প্যাকেজিং / নোট'].map(escapeCSV).join(','));
    CATEGORIES.forEach((cat) => {
      let pieces = 0;
      let amount = 0;
      let extra = '';

      if (cat.isOthers) {
        (currentDayData.unlistedItems || []).forEach((u) => {
          pieces += u.quantity || 0;
          amount += (u.quantity || 0) * (u.price || 0);
        });
        extra = `${(currentDayData.unlistedItems || []).length} টি আনলিস্টেড পণ্য`;
      } else {
        const catProducts = products.filter(
          (p) => (p.categoryKey && p.categoryKey === cat.key) || cat.productIds.includes(p.id)
        );
        catProducts.forEach((p) => {
          const q = currentDayData.sum[p.id] || 0;
          pieces += q;
          amount += q * p.price;
        });

        if (cat.isSemai) {
          const semaiPack = parseInt(localStorage.getItem('semai_pack_size') || '24', 10);
          const fulls = Math.floor(pieces / semaiPack);
          const rem = pieces % semaiPack;
          extra = `${fulls} ফুল (${semaiPack} পিস/ফুল) + ${rem} পিস`;
        }
      }

      lines.push([
        cat.nameBn,
        cat.nameEn,
        pieces,
        amount,
        extra
      ].map(escapeCSV).join(','));
    });
    lines.push(['সর্বমোট', '১০টি ক্যাটাগরি মিলিয়ে', totalDayPieces, totalDayMoney, '-'].map(escapeCSV).join(','));
    lines.push('');

    // SECTION 2: পণ্যভিত্তিক মোট বিক্রয় ও যোগ সংখ্যা (Product-wise Sales Summary & Frequency)
    lines.push('--- ২. পণ্যভিত্তিক মোট বিক্রয় ও যোগ সংখ্যা (Product-wise Sales & Frequency) ---');
    lines.push(['ক্রমিক', 'পণ্যের নাম', 'গ্রুপ নং', 'একক দর (টাকা)', 'মোট বিক্রিত পরিমাণ (পিস)', 'মোট টাকা (টাকা)', 'আজকের যোগ সংখ্যা (বার)', 'সর্বাধিক যোগ স্ট্যাটাস'].map(escapeCSV).join(','));
    products.forEach((prod, idx) => {
      const qty = currentDayData.sum[prod.id] || 0;
      const freq = productFrequencyMap[prod.id] || 0;
      const isTop = maxFrequency > 0 && freq === maxFrequency;
      lines.push([
        idx + 1,
        prod.name,
        `গ্রুপ ${prod.groupIndex + 1}`,
        prod.price,
        qty,
        qty * prod.price,
        freq,
        isTop ? 'শীর্ষ পণ্য (Most Frequent)' : '-'
      ].map(escapeCSV).join(','));
    });
    lines.push(['সর্বমোট', 'সকল পণ্য মিলিয়ে', '-', '-', totalDayPieces, totalDayMoney, '-', '-'].map(escapeCSV).join(','));
    lines.push('');

    // SECTION 3: বিস্তারিত মেমো ট্রানজ্যাকশন হিস্ট্রি (Chronological Memo History)
    lines.push('--- ৩. বিস্তারিত মেমো হিস্ট্রি (Detailed Memo Transactions) ---');
    lines.push(['ক্রমিক', 'সময়', 'পণ্যের নাম', 'পরিমাণ (পিস)', 'একক দর (টাকা)', 'মোট টাকা (টাকা)', 'মেমো নম্বর'].map(escapeCSV).join(','));
    if (currentDayData.history.length === 0) {
      lines.push(['-', '-', 'আজকের দিনে এখনো কোনো মেমো যোগ করা হয়নি', '0', '0', '0', '-'].map(escapeCSV).join(','));
    } else {
      currentDayData.history.forEach((item, index) => {
        const unitPrice =
          products[item.productIndex]?.price ||
          (item.quantity > 0 ? Math.round(item.amount / item.quantity) : 0);
        lines.push([
          index + 1,
          item.time,
          item.productName,
          item.quantity,
          unitPrice,
          item.amount,
          item.note || ''
        ].map(escapeCSV).join(','));
      });
      lines.push(['সর্বমোট', '-', '-', totalDayPieces, '-', totalDayMoney, '-'].map(escapeCSV).join(','));
    }

    // Prepend UTF-8 Byte Order Mark (BOM) \uFEFF so Excel opens Unicode Bangla correctly without mojibake
    const csvContent = '\uFEFF' + lines.join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raju-daily-summary-${currentDate}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Excel/CSV ফাইল সফলভাবে ডাউনলোড হয়েছে!');
  };

  // Generate & Download high-formatted browser PDF report
  const handleDownloadPDF = async () => {
    if (isGeneratingPdf) return;
    try {
      setIsGeneratingPdf(true);
      setPdfProgressStatus('রিপোর্ট তৈরি করা হচ্ছে...');
      await generateDailySummaryPDF(
        {
          currentDate,
          totalDayPieces,
          totalDayMoney,
          groupSummaries,
          products: products,
          currentDayData,
          productFrequencyMap,
        },
        (status) => setPdfProgressStatus(status)
      );
      showToast('PDF রিপোর্ট সফলভাবে ডাউনলোড হয়েছে!');
    } catch (err) {
      console.error('Failed to generate PDF:', err);
      showToast('পিডিএফ তৈরিতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      setIsGeneratingPdf(false);
      setPdfProgressStatus('');
    }
  };

  // Backup & restore functions (Full permanent backup including images & state)
  const exportBackupJSON = () => {
    requestPersistentStorage();
    saveStoredProductImages(imageMap);
    const photoCount = Object.keys(imageMap).length;
    const backupData = {
      version: 2,
      appName: 'Raju Daily Summary',
      exportDate: new Date().toISOString(),
      currentDate,
      photoCount,
      imageMap,
      images: imageMap,
      products,
      data,
      globalHistory
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `raju-daily-summary-complete-backup-${currentDate}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast(`সকল ছবি (${photoCount} টি) ও মেমো ডেটা সম্পূর্ণ সুরক্ষিতভাবে ডাউনলোড হয়েছে!`);
  };

  const getBackupPayload = () => ({
    version: 2,
    appName: 'Raju Daily Summary',
    exportDate: new Date().toISOString(),
    currentDate,
    photoCount: Object.keys(imageMap).length,
    data,
    globalHistory,
    products,
    imageMap,
    images: imageMap
  });

  const handleRestorePayload = (parsed: any) => {
    if (!parsed) return;
    if (parsed.data) {
      setData(parsed.data);
      try {
        localStorage.setItem(STORAGE_KEY_DATA, JSON.stringify(parsed.data));
      } catch {}
    }
    if (Array.isArray(parsed.globalHistory)) {
      setGlobalHistory(parsed.globalHistory);
      try {
        localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(parsed.globalHistory));
      } catch {}
    }
    if (Array.isArray(parsed.products)) {
      handleUpdateProducts(parsed.products);
    }
    const incomingImages = parsed.imageMap || parsed.images;
    if (incomingImages && typeof incomingImages === 'object') {
      const merged = { ...imageMap, ...incomingImages };
      setImageMap(merged);
      saveStoredProductImages(merged);
      requestPersistentStorage();
    }
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.data || parsed.imageMap || parsed.images || Array.isArray(parsed.products)) {
          handleRestorePayload(parsed);
          showToast('ব্যাকআপ ফাইল থেকে সকল ডেটা ও ছবি সফলভাবে রিস্টোর হয়েছে!');
          setShowBackupModal(false);
        } else {
          alert('ভুল ফাইল ফরম্যাট! সঠিক Raju Daily Summary ব্যাকআপ ফাইল দিন।');
        }
      } catch (err) {
        alert('ফাইল পড়তে সমস্যা হয়েছে: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const pendingInputsCount = useMemo(() => {
    return inputs.reduce((acc, q) => acc + (q > 0 ? q : 0), 0);
  }, [inputs]);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased pb-24 transition-colors duration-200">
      {/* PWA / Web APK Header - Single Clean Row, Zero Overflow */}
      <header className="bg-slate-900 text-white shadow-md sticky top-0 z-40 w-full overflow-hidden">
        <div className="max-w-5xl mx-auto px-3 sm:px-4 py-2 sm:py-3 flex items-center justify-between gap-2 w-full flex-nowrap">
          {/* Left: App Identity */}
          <div className="flex items-center gap-2 min-w-0 shrink">
            <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow-inner shrink-0">
              RD
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 min-w-0">
                <h1 className="text-sm sm:text-base font-black tracking-tight text-white truncate whitespace-nowrap">
                  Raju Daily Summary
                </h1>
                <span
                  className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 inline-block animate-pulse"
                  title={isOnline ? 'ইন্টারনেট সংযুক্ত ও অফলাইন প্রস্তুত' : 'অফলাইন মোড'}
                />
              </div>
              <p className="text-[10px] text-slate-400 truncate hidden lg:block">
                Quantity লিখুন → যোগ করুন → Quantity ঘর 0 • Product ও Price লক
              </p>
            </div>
          </div>

          {/* Right: Clean, Single-Line Actions */}
          <div className="flex items-center gap-1 sm:gap-2 shrink-0">
            {/* Sticky Header "সব যোগ" button (Whenever inputs are pending in any view) */}
            {pendingInputsCount > 0 && (
              <button
                id="header-sticky-add-all-btn"
                type="button"
                onClick={addAll}
                className="px-2.5 py-1.5 rounded-lg text-xs font-black flex items-center gap-1 transition cursor-pointer shadow-sm active:scale-95 bg-blue-600 hover:bg-blue-500 text-white border border-blue-400 ring-2 ring-blue-300 animate-pulse shrink-0"
                title="সব ইনপুট এক ক্লিকে যোগ করুন"
              >
                <Check className="w-3.5 h-3.5 text-amber-300 stroke-[3]" />
                <span className="font-black text-xs">সব যোগ</span>
                <span className="bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded-full font-black text-[10px]">
                  {pendingInputsCount}
                </span>
              </button>
            )}

            {/* Project ZIP Download (Compact on mobile, descriptive on tablet/desktop) */}
            <a
              id="download-project-zip-header-btn"
              href="/RajuDailySummary-Project.zip"
              download="RajuDailySummary-Complete-Project.zip"
              onClick={() => showToast('সম্পূর্ণ প্রজেক্ট ব্যাকআপ (ZIP) ডাউনলোড শুরু হয়েছে...')}
              className="px-2 sm:px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white border border-emerald-500 text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-xs active:scale-95 shrink-0"
              title="ওয়েবসাইটের সম্পূর্ণ ফাইল ও প্রজেক্ট ব্যাকআপ (ZIP) ডাউনলোড করুন"
            >
              <FolderArchive className="w-3.5 h-3.5 text-emerald-100 shrink-0" />
              <span className="inline sm:hidden text-[11px] font-bold">ZIP</span>
              <span className="hidden sm:inline text-xs font-bold">প্রজেক্ট ZIP</span>
            </a>

            {/* Desktop Only Extra Action Buttons (Hidden on mobile to guarantee 1 clean line) */}
            <div className="hidden md:flex items-center gap-1.5">
              <PWAInstallButton variant="header" />

              {/* View mode switcher */}
              {activeViewMode === 'catalog' ? (
                <button
                  id="header-open-summary-app-btn"
                  type="button"
                  onClick={() => {
                    setActiveViewMode('counter');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-black text-xs flex items-center gap-1 transition cursor-pointer shadow-xs active:scale-95"
                  title="আমার দৈনিক সামারি অ্যাপে যান"
                >
                  <Layers className="w-3.5 h-3.5 text-slate-950" />
                  <span>সামারি অ্যাপ</span>
                </button>
              ) : (
                <button
                  id="header-open-catalog-btn"
                  type="button"
                  onClick={() => {
                    setActiveViewMode('catalog');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer shadow-xs active:scale-95"
                  title="ছবিসহ প্রোডাক্ট ক্যাটালগে যান"
                >
                  <ShoppingBag className="w-3.5 h-3.5 text-emerald-200" />
                  <span>পণ্য ক্যাটালগ</span>
                </button>
              )}

              <button
                id="dashboard-header-btn"
                type="button"
                onClick={() => setActiveViewMode(activeViewMode === 'dashboard' ? 'counter' : 'dashboard')}
                className={`px-2.5 py-1.5 rounded-lg border text-xs font-bold flex items-center gap-1 transition cursor-pointer shadow-xs ${
                  activeViewMode === 'dashboard'
                    ? 'bg-blue-600 hover:bg-blue-500 text-white border-blue-400'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                }`}
                title="ড্যাশবোর্ড দেখুন"
              >
                <LayoutDashboard className="w-3.5 h-3.5 text-amber-300" />
                <span>ড্যাশবোর্ড</span>
              </button>

              {/* Google Drive Cloud Auto-Sync Indicator */}
              <button
                id="header-google-drive-sync-btn"
                type="button"
                onClick={() => setShowBackupModal(true)}
                className={`p-2 rounded-lg text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shadow-xs border ${
                  driveSyncState.status === 'syncing'
                    ? 'bg-blue-600/30 text-blue-300 border-blue-500/50 animate-pulse'
                    : driveSyncState.status === 'synced'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : driveSyncState.status === 'error'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    : driveSyncState.status !== 'unauthenticated'
                    ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                    : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700'
                }`}
                title="গুগল ড্রাইভ অটো-সিঙ্ক ও ব্যাকআপ"
              >
                {driveSyncState.status === 'syncing' ? (
                  <RefreshCw className="w-4 h-4 text-amber-300 animate-spin" />
                ) : (
                  <Cloud className="w-4 h-4 text-emerald-400" />
                )}
              </button>

              {/* Offline file download */}
              <a
                id="offline-file-header-btn"
                href="/Raju-Daily-Summary-Standalone.html"
                download="Raju-Daily-Summary.html"
                onClick={() => showToast('অফলাইন সিঙ্গেল ফাইল অ্যাপ (HTML) ডাউনলোড হচ্ছে...')}
                className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1 transition cursor-pointer shadow-xs active:scale-95"
                title="ইন্টারনেট ছাড়াই সরাসরি ব্যবহারের জন্য অফলাইন সিঙ্গেল ফাইল (HTML) ডাউনলোড করুন"
              >
                <FileCode className="w-4 h-4 text-emerald-200" />
              </a>

              {/* Product manager */}
              <button
                id="product-manager-header-btn"
                onClick={() => setShowProductManagerModal(true)}
                className="p-2 rounded-lg bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-black border border-amber-400 text-xs flex items-center gap-1 transition cursor-pointer shadow-xs"
                title="নতুন প্রোডাক্ট যোগ এবং প্রাইজ আপডেট"
              >
                <Tag className="w-4 h-4 text-slate-950" />
              </button>
            </div>

            {/* Global Theme Toggle (Light / Dark Mode) */}
            <button
              id="theme-toggle-btn"
              type="button"
              onClick={toggleTheme}
              className="p-1.5 sm:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center transition cursor-pointer shrink-0"
              title={theme === 'dark' ? 'লাইট মোডে পরিবর্তন করুন' : 'ডার্ক মোডে পরিবর্তন করুন'}
              aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-300 transition-transform hover:rotate-45" />
              ) : (
                <Moon className="w-4 h-4 text-sky-300 transition-transform hover:-rotate-12" />
              )}
            </button>

            {/* Backup, Notification & Settings Button */}
            <button
              id="backup-modal-open-btn"
              onClick={() => setShowBackupModal(true)}
              className="p-1.5 sm:p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center justify-center transition cursor-pointer relative shrink-0"
              title="ব্যাকআপ, নোটিফিকেশন ও সেটিংস"
            >
              {notificationConfig.enabled ? (
                <BellRing className="w-4 h-4 text-amber-400" />
              ) : (
                <Download className="w-4 h-4 text-amber-400" />
              )}
              {notificationConfig.enabled && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-500 rounded-full border border-slate-900"
                  title="দৈনিক সামারি নোটিফিকেশন সক্রিয় আছে"
                />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Offline Status Alert Banner */}
      {!isOnline && (
        <div
          id="offline-indicator-banner"
          className="bg-emerald-800 text-emerald-100 px-3 py-1.5 text-xs font-bold flex items-center justify-center gap-2 text-center no-print shadow-inner"
        >
          <WifiOff className="w-4 h-4 text-amber-300 shrink-0" />
          <span>অফলাইন মোড সক্রিয় (Offline Run): কোনো ইন্টারনেট ছাড়াই অ্যাপ ও সকল মেমোর হিসাব সচল আছে</span>
        </div>
      )}

      {/* Main Content Area */}
      <main className="max-w-5xl mx-auto w-full px-2 sm:px-4 pt-3 sm:pt-4 space-y-3 sm:space-y-4 flex-1 min-w-0 overflow-x-hidden">
        {/* PWA Install Banner (Mobile / Desktop) */}
        <PWAInstallButton variant="banner" />

        {/* Main View Switching: Catalog (Pictures First!), Dashboard, History, Splitter, or Counter (Summary App) */}
        {activeViewMode === 'catalog' ? (
          <ProductCatalogView
            products={products}
            inputs={inputs}
            onInputChange={(idx, val) => {
              setInputs((prev) => {
                const next = [...prev];
                next[idx] = val;
                return next;
              });
            }}
            onOpenSummaryApp={() => {
              setActiveViewMode('counter');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onAddAll={addAll}
            currentDate={currentDate}
            imageMap={imageMap}
            onUpdateImageMap={setImageMap}
            showToast={showToast}
          />
        ) : activeViewMode === 'dashboard' ? (
          <DashboardView
            data={data}
            products={products}
            currentDate={currentDate}
            onSelectDate={(d) => setCurrentDate(d)}
            onSwitchToCounter={() => setActiveViewMode('counter')}
            onToast={showToast}
            onAddSampleHistory={handleAddSampleHistory}
            onClearSampleHistory={handleClearSampleHistory}
            hasSampleData={hasSampleData}
          />
        ) : activeViewMode === 'history' ? (
          /* Dedicated History View */
          <div className="space-y-4">
            {/* History Header Banner */}
            <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 shadow-sm border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-blue-50 dark:bg-blue-950/50 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-slate-100">
                    🧾 দৈনিক মেমো ও বিক্রয় হিস্ট্রি
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    তারিখ: <span className="font-bold text-slate-700 dark:text-slate-300">{currentDate}</span> | মোট রেকর্ড: <span className="font-bold text-blue-600 dark:text-blue-400">{currentDayData.history.length} টি</span>
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700">
                  <Calendar className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
                  <input
                    id="history-view-date-picker"
                    type="date"
                    value={currentDate}
                    onChange={(e) => setCurrentDate(e.target.value || getTodayString())}
                    className="bg-transparent font-bold text-sm text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => setActiveViewMode('counter')}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 hover:bg-slate-800 dark:hover:bg-amber-400 transition cursor-pointer shadow-xs"
                >
                  কাউন্টারে ফিরুন
                </button>
              </div>
            </div>

            {/* Summary Card at the top of the History view for currently filtered result set */}
            <HistorySummaryCard
              totalEntries={filteredHistorySummary.totalEntries}
              totalItemsSold={filteredHistorySummary.totalItemsSold}
              totalRevenue={filteredHistorySummary.totalRevenue}
              totalUnfilteredEntries={currentDayData.history.length}
              searchQuery={historySearchQuery}
              onSearchChange={setHistorySearchQuery}
              productFilter={historyProductFilter}
              onProductFilterChange={setHistoryProductFilter}
              productOptions={historyProductOptions}
              onClearFilters={() => {
                setHistorySearchQuery('');
                setHistoryProductFilter('all');
              }}
            />

            {/* Compact Itemized Bottom Product Summary for History context */}
            <BottomProductSummary
              products={products}
              daySum={currentDayData.sum}
              unlistedItems={currentDayData.unlistedItems || []}
              currentDate={currentDate}
              onCopyToast={showToast}
            />

            {/* Memo History Section Component */}
            <section id="memo-history-section" className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <div className="flex items-center gap-2">
                  <History className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                  <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-slate-100">
                    🧾 Memo History (আজকের এন্ট্রি তালিকা)
                  </h2>
                </div>
                <div className="flex items-center gap-2 flex-wrap no-print">
                  <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                    {historySearchQuery.trim() !== '' || historyProductFilter !== 'all'
                      ? `ফিল্টারকৃত ${filteredHistory.length} টি / মোট ${currentDayData.history.length} টি রেকর্ড`
                      : `মোট ${currentDayData.history.length} টি রেকর্ড`}
                  </span>
                  <button
                    type="button"
                    id="export-csv-history-btn-view"
                    onClick={exportDayCSV}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 transition cursor-pointer shadow-2xs"
                    title="আজকের হিসাব ও মেমো হিস্ট্রি Excel / CSV হিসেবে ডাউনলোড করুন"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Excel / CSV</span>
                  </button>
                  <button
                    type="button"
                    id="resync-history-btn-view"
                    onClick={resyncCurrentDay}
                    className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 transition cursor-pointer shadow-2xs"
                    title="মেমো হিস্ট্রি অনুযায়ী উপরের মোট হিসাব সিঙ্ক ও ঠিক করুন"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
                    <span>হিসাব সিঙ্ক</span>
                  </button>
                  {currentDayData.history.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsSelectionMode(!isSelectionMode);
                        if (isSelectionMode) {
                          setSelectedEntryIds([]);
                        }
                      }}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                        isSelectionMode
                          ? 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                      }`}
                      title="একাধিক এন্ট্রি নির্বাচন করে একসাথে মুছে ফেলতে ক্লিক করুন"
                    >
                      {isSelectionMode ? (
                        <>
                          <X className="w-3.5 h-3.5" />
                          <span>সিলেকশন বন্ধ</span>
                        </>
                      ) : (
                        <>
                          <CheckSquare className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                          <span>সিলেকশন মোড</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {/* Selection Actions Bar */}
              {isSelectionMode && currentDayData.history.length > 0 && (
                <div className="flex items-center justify-between flex-wrap gap-2.5 p-2.5 sm:p-3 bg-blue-50 dark:bg-slate-800/80 border border-blue-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm no-print">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-extrabold text-blue-900 dark:text-blue-300 bg-blue-200/90 dark:bg-blue-900/50 px-2.5 py-1 rounded-md text-xs">
                      {selectedSummary.count} টি নির্বাচিত
                    </span>
                    {selectedSummary.count > 0 ? (
                      <span className="text-blue-950 dark:text-slate-100 font-medium text-xs sm:text-sm">
                        মোট: <strong className="font-bold">{selectedSummary.pieces} পিস</strong> ({money(selectedSummary.amount)} টাকা)
                      </span>
                    ) : (
                      <span className="text-slate-500 dark:text-slate-400 text-xs italic">
                        নিচের চেকবক্সে টিক দিন অথবা এক ক্লিকে সবগুলো নির্বাচন করুন
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button
                      type="button"
                      onClick={toggleSelectAllInHistoryView}
                      className="px-2.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-blue-100 dark:hover:bg-slate-600 text-blue-900 dark:text-slate-100 border border-blue-300 dark:border-slate-600 rounded-lg font-bold text-xs transition cursor-pointer shadow-2xs"
                    >
                      {displayedHistoryViewList.length > 0 &&
                      displayedHistoryViewList.every((h) => selectedEntryIds.includes(h.id))
                        ? 'সব বাতিল'
                        : 'সবগুলো নির্বাচন'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const toDelete = currentDayData.history.filter((h) => selectedEntryIds.includes(h.id));
                        if (toDelete.length > 0) {
                          setDeleteModal({
                            isOpen: true,
                            type: 'bulk',
                            entries: toDelete
                          });
                        }
                      }}
                      disabled={selectedSummary.count === 0}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs transition shadow-2xs ${
                        selectedSummary.count > 0
                          ? 'bg-red-600 hover:bg-red-700 text-white cursor-pointer active:scale-95'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                      }`}
                      title={selectedSummary.count > 0 ? 'নির্বাচিত এন্ট্রিগুলো মুছে ফেলুন' : 'আগে এন্ট্রি নির্বাচন করুন'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>মুছে ফেলুন ({selectedSummary.count} টি)</span>
                    </button>
                  </div>
                </div>
              )}

              <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 tablebox">
                <table className="w-full border-collapse text-left text-xs sm:text-sm">
                  <thead>
                    <tr className="bg-slate-100 dark:bg-slate-800/90 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-800">
                      {isSelectionMode && (
                        <th className="py-2 px-3 text-center w-10 no-print">
                          <input
                            type="checkbox"
                            checked={
                              displayedHistoryViewList.length > 0 &&
                              displayedHistoryViewList.every((h) => selectedEntryIds.includes(h.id))
                            }
                            onChange={toggleSelectAllInHistoryView}
                            className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                            title="সবগুলো নির্বাচন / বাতিল করুন"
                          />
                        </th>
                      )}
                      <th className="py-2 px-3">সময়</th>
                      <th className="py-2 px-3">পণ্য</th>
                      <th className="py-2 px-3 text-center">Quantity (পিস)</th>
                      <th className="py-2 px-3 text-center">টাকা</th>
                      <th className="py-2 px-3 text-left">মেমো নম্বর</th>
                      <th className="py-2 px-3 text-center no-print">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {currentDayData.history.length === 0 ? (
                      <tr>
                        <td colSpan={isSelectionMode ? 7 : 6} className="py-6 text-center text-slate-400 dark:text-slate-500 font-medium">
                          আজ এখনো কোনো হিসাব যোগ করা হয়নি।
                        </td>
                      </tr>
                    ) : displayedHistoryViewList.length === 0 ? (
                      <tr>
                        <td colSpan={isSelectionMode ? 7 : 6} className="py-6 text-center text-slate-500 dark:text-slate-400 font-medium space-y-2">
                          <div>ফিল্টার অনুযায়ী কোনো এন্ট্রি খুঁজে পাওয়া যায়নি।</div>
                          <button
                            type="button"
                            onClick={() => {
                              setHistorySearchQuery('');
                              setHistoryProductFilter('all');
                            }}
                            className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer inline-flex items-center gap-1"
                          >
                            <RotateCcw className="w-3 h-3" />
                            <span>ফিল্টার রিসেট করুন</span>
                          </button>
                        </td>
                      </tr>
                    ) : (
                      displayedHistoryViewList.map((item) => {
                        const isSelected = selectedEntryIds.includes(item.id);
                        return (
                          <tr
                            key={item.id}
                            onClick={isSelectionMode ? () => toggleSelectEntry(item.id) : undefined}
                            className={`transition font-medium ${
                              isSelected
                                ? 'bg-blue-50/90 dark:bg-blue-950/40 text-blue-950 dark:text-blue-200 font-semibold'
                                : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                            } ${isSelectionMode ? 'cursor-pointer' : ''}`}
                          >
                            {isSelectionMode && (
                              <td className="py-2 px-3 text-center no-print" onClick={(e) => e.stopPropagation()}>
                                <input
                                  type="checkbox"
                                  checked={isSelected}
                                  onChange={() => toggleSelectEntry(item.id)}
                                  className="w-4 h-4 text-blue-600 rounded border-slate-300 dark:border-slate-700 focus:ring-blue-500 cursor-pointer"
                                />
                              </td>
                            )}
                            <td className="py-2 px-3 text-slate-500 dark:text-slate-400 font-mono text-xs">{item.time}</td>
                            <td className="py-2 px-3 font-bold text-slate-900 dark:text-slate-100">{item.productName}</td>
                            <td className="py-2 px-3 text-center font-extrabold text-blue-700 dark:text-blue-400">
                              {money(item.quantity)}
                            </td>
                            <td className="py-2 px-3 text-center font-extrabold text-slate-900 dark:text-slate-100">
                              {money(item.amount)} টাকা
                            </td>
                            <td className="py-2 px-3" onClick={(e) => e.stopPropagation()}>
                              {editingNoteId === item.id ? (
                                <div className="flex items-center gap-1">
                                  <input
                                    type="text"
                                    value={editingNoteText}
                                    onChange={(e) => setEditingNoteText(e.target.value)}
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') saveEditedNote(item.id);
                                      if (e.key === 'Escape') {
                                        setEditingNoteId(null);
                                        setEditingNoteText('');
                                      }
                                    }}
                                    autoFocus
                                    maxLength={40}
                                    placeholder="মেমো নম্বর লিখুন..."
                                    className="w-28 sm:w-36 px-2 py-1 border border-blue-500 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs font-semibold"
                                  />
                                  <button
                                    onClick={() => saveEditedNote(item.id)}
                                    className="p-1 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded cursor-pointer"
                                    title="সংরক্ষণ করুন"
                                  >
                                    <CheckCheck className="w-4 h-4" />
                                  </button>
                                  <button
                                    onClick={() => {
                                      setEditingNoteId(null);
                                      setEditingNoteText('');
                                    }}
                                    className="p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer"
                                    title="বাতিল করুন"
                                  >
                                    <X className="w-4 h-4" />
                                  </button>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1.5 group">
                                  {item.note ? (
                                    <span className="inline-flex items-center gap-1 bg-blue-50 dark:bg-blue-950/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800 px-2.5 py-0.5 rounded text-xs font-bold shadow-2xs">
                                      <FileText className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                      <span>{item.note}</span>
                                    </span>
                                  ) : (
                                    <span className="text-slate-400 dark:text-slate-500 text-xs italic no-print">—</span>
                                  )}
                                  <button
                                    onClick={() => {
                                      setEditingNoteId(item.id);
                                      setEditingNoteText(item.note || '');
                                    }}
                                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-800 rounded transition no-print cursor-pointer"
                                    title={item.note ? 'মেমো নম্বর এডিট করুন' : 'মেমো নম্বর লিখুন'}
                                  >
                                    <Edit3 className="w-3.5 h-3.5" />
                                  </button>
                                </div>
                              )}
                            </td>
                            <td className="py-2 px-3 text-center no-print" onClick={(e) => e.stopPropagation()}>
                              <button
                                type="button"
                                onClick={() => {
                                  setDeleteModal({
                                    isOpen: true,
                                    type: 'single',
                                    entry: item
                                  });
                                }}
                                className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 hover:text-red-800 dark:hover:text-red-400 transition cursor-pointer active:scale-90"
                                title="এই এন্ট্রি মুছে ফেলুন এবং মোট থেকে বাদ দিন"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
                {filteredHistory.length > 50 && (
                  <div className="p-2.5 text-center bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 no-print">
                    <button
                      type="button"
                      onClick={() => setShowAllHistory(!showAllHistory)}
                      className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition cursor-pointer"
                    >
                      {showAllHistory
                        ? 'সংক্ষেপ করুন (সর্বশেষ ৫০টি দেখুন)'
                        : `সবগুলো (${filteredHistory.length}টি) রেকর্ড দেখুন`}
                    </button>
                  </div>
                )}
              </div>
            </section>
          </div>
        ) : activeViewMode === 'splitter' ? (
          <BillSplitterChat
            currentDayTotal={totalDayMoney}
            currentDate={currentDate}
            onToast={showToast}
          />
        ) : (
          <>
        {/* Banner to switch to Product Catalog with Photos */}
        <div className="bg-gradient-to-r from-emerald-900 via-teal-900 to-slate-900 text-white p-3 sm:p-4 rounded-2xl border border-emerald-500/40 shadow-sm flex flex-wrap items-center justify-between gap-3 mb-1">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs sm:text-sm font-black text-white flex items-center gap-1.5">
                <span>ছবিসহ প্রোডাক্ট ক্যাটালগ ও অর্ডার গ্যালারি</span>
                <span className="text-[10px] bg-emerald-500 text-slate-950 font-black px-1.5 py-0.2 rounded-full">
                  ছবি
                </span>
              </div>
              <div className="text-[11px] text-emerald-200/80">
                ক্যাটাগরি অনুযায়ী ছবি দেখে অর্ডার বুক করতে বা ছবি আপলোড করতে চান?
              </div>
            </div>
          </div>
          <button
            type="button"
            id="switch-to-catalog-banner-btn"
            onClick={() => {
              setActiveViewMode('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="px-3.5 py-2 bg-emerald-500 hover:bg-emerald-400 active:scale-95 text-slate-950 font-black text-xs rounded-xl flex items-center gap-1.5 shadow-md transition cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>ছবিসহ ক্যাটালগে যান</span>
          </button>
        </div>

        {/* Date & Action Toolbar */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200/80 dark:border-slate-800 space-y-3 transition-colors">
          <div className="flex flex-wrap items-center justify-between gap-2.5">
            {/* Date selector */}
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700">
              <Calendar className="w-4 h-4 text-slate-600 dark:text-slate-400 shrink-0" />
              <input
                id="date-picker-input"
                type="date"
                value={currentDate}
                onChange={(e) => setCurrentDate(e.target.value || getTodayString())}
                className="bg-transparent font-bold text-sm text-slate-800 dark:text-slate-100 focus:outline-none cursor-pointer"
              />
            </div>

            {/* Quick Actions */}
            <div className="toolbar-actions flex items-center gap-2 flex-wrap">
              <button
                id="add-all-quantities-btn"
                onClick={addAll}
                className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition active:scale-95 cursor-pointer"
                title="সব পণ্যের লেখা Quantity একসাথে যোগ করুন"
              >
                <CheckCheck className="w-4 h-4" />
                <span>সব যোগ করুন</span>
                {uncommittedTotal.pieces > 0 && (
                  <span className="bg-blue-500 text-white px-1.5 py-0.5 rounded-md text-[11px] font-black">
                    {uncommittedTotal.pieces}
                  </span>
                )}
              </button>

              <button
                id="new-memo-btn"
                onClick={startNewMemo}
                className="inline-flex items-center gap-1.5 bg-slate-900 dark:bg-amber-500 hover:bg-slate-800 dark:hover:bg-amber-400 text-white dark:text-slate-950 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-sm transition active:scale-95 cursor-pointer"
                title="ইনপুট রিসেট করুন এবং পরবর্তী মেমো নম্বর শুরু করুন"
              >
                <Plus className="w-4 h-4 text-amber-400 dark:text-slate-950" />
                <span>নতুন Memo</span>
              </button>

              <button
                id="generate-pdf-btn"
                onClick={handleDownloadPDF}
                disabled={isGeneratingPdf}
                className="inline-flex items-center gap-1.5 bg-rose-600 hover:bg-rose-700 disabled:opacity-60 text-white px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-xs transition active:scale-95 cursor-pointer"
                title="আজকের হিসাব ও মেমো হিস্ট্রির সুবিন্যস্ত প্রফেশনাল PDF রিপোর্ট ডাউনলোড করুন"
              >
                {isGeneratingPdf ? (
                  <Loader2 className="w-4 h-4 animate-spin text-white" />
                ) : (
                  <FileDown className="w-4 h-4 text-rose-100" />
                )}
                <span>{isGeneratingPdf ? (pdfProgressStatus || 'PDF তৈরি...') : 'PDF রিপোর্ট'}</span>
              </button>

              <button
                id="export-day-csv-btn"
                onClick={exportDayCSV}
                className="inline-flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-2 rounded-xl text-xs sm:text-sm font-bold shadow-xs transition active:scale-95 cursor-pointer"
                title="আজকের হিসাব ও মেমো হিস্ট্রি Excel / CSV ফাইলে এক্সপোর্ট করুন"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
                <span>Excel / CSV</span>
              </button>

              <button
                id="print-btn"
                onClick={() => window.print()}
                className="inline-flex items-center gap-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer"
                title="হার্ডকপি প্রিন্ট বা ব্রাউজার প্রিন্ট প্রিভিউ"
              >
                <Printer className="w-4 h-4 text-slate-600 dark:text-slate-400" />
                <span>প্রিন্ট</span>
              </button>

              <button
                id="reset-inputs-btn"
                onClick={resetCurrentInputs}
                className="inline-flex items-center gap-1 bg-slate-100 dark:bg-slate-800 hover:bg-red-50 dark:hover:bg-red-950/40 text-slate-700 dark:text-slate-300 hover:text-red-700 dark:hover:text-red-400 border border-slate-300 dark:border-slate-700 px-3 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer"
                title="বর্তমান ইনপুট ০ করুন"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>ইনপুট ০</span>
              </button>

              <button
                id="product-manager-toolbar-btn"
                onClick={() => setShowProductManagerModal(true)}
                className="inline-flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 px-3 py-2 rounded-xl text-xs sm:text-sm font-black border border-amber-400 shadow-xs transition active:scale-95 cursor-pointer"
                title="নতুন প্রোডাক্ট যোগ এবং প্রাইজ আপডেট করার সেটিংস উইন্ডো খুলুন"
              >
                <Tag className="w-4 h-4 text-slate-950" />
                <span>প্রোডাক্ট ও প্রাইজ আপডেট</span>
              </button>

              <button
                id="permanent-backup-toolbar-btn"
                type="button"
                onClick={exportBackupJSON}
                className="inline-flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 text-white px-3 py-2 rounded-xl text-xs sm:text-sm font-bold border border-blue-500 shadow-xs transition active:scale-95 cursor-pointer"
                title="সকল ছবি, মেমো এবং পণ্যের তালিকা সহ সম্পূর্ণ ব্যাকআপ ফাইল ডাউনলোড করুন"
              >
                <Download className="w-4 h-4 text-blue-100" />
                <span>ছবি ও ডেটা ব্যাকআপ</span>
              </button>

              <a
                id="download-offline-html-toolbar-btn"
                href="/Raju-Daily-Summary-Standalone.html"
                download="Raju-Daily-Summary.html"
                onClick={() => showToast('অফলাইন সিঙ্গেল ফাইল অ্যাপ (HTML) ডাউনলোড হচ্ছে...')}
                className="inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-600 active:bg-emerald-800 text-white px-3 py-2 rounded-xl text-xs sm:text-sm font-bold border border-emerald-600 shadow-xs transition active:scale-95 cursor-pointer"
                title="কোনো ইন্টারনেট ছাড়া সরাসরি ব্যবহার উপযোগী সিঙ্গেল ফাইল (HTML) ডাউনলোড করুন"
              >
                <FileCode className="w-4 h-4 text-emerald-200" />
                <span>অফলাইন ফাইল (HTML)</span>
              </a>

              <a
                id="download-code-toolbar-btn"
                href="/RajuDailySummary-Project.zip"
                download="RajuDailySummary-Complete-Project.zip"
                onClick={() => showToast('সম্পূর্ণ অ্যাপ্লিকেশন সোর্স কোড ও প্রজেক্ট ব্যাকআপ (ZIP) ডাউনলোড হচ্ছে...')}
                className="inline-flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white px-3 py-2 rounded-xl text-xs sm:text-sm font-bold border border-slate-700 shadow-xs transition active:scale-95 cursor-pointer"
                title="অ্যাপ্লিকেশনের সম্পূর্ণ ফাইল, সোর্স কোড ও প্রজেক্ট ডাউনলোড করুন (ZIP)"
              >
                <FolderArchive className="w-4 h-4 text-slate-300" />
                <span>প্রজেক্ট ZIP ব্যাকআপ</span>
              </a>
            </div>
          </div>

          {/* Search and Group Filter Tabs */}
          <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                id="product-search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="পণ্য বা দাম দিয়ে খুঁজুন (যেমন: চকলেট, সস, ৪২)..."
                className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-amber-500/50 focus:bg-white dark:focus:bg-slate-800 transition"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-full"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            {/* Group Filter Buttons */}
            <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
              <button
                onClick={() => setSelectedGroup('all')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                  selectedGroup === 'all'
                    ? 'bg-slate-900 dark:bg-amber-500 text-white dark:text-slate-950 shadow-sm'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                }`}
              >
                সব ({products.length})
              </button>

              {maxFrequency > 0 && (
                <button
                  onClick={() => setSelectedGroup(selectedGroup === 'most-frequent' ? 'all' : 'most-frequent')}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition cursor-pointer flex items-center gap-1 ${
                    selectedGroup === 'most-frequent'
                      ? 'bg-amber-500 text-slate-950 font-black shadow-sm ring-2 ring-amber-600'
                      : 'bg-amber-100 text-amber-900 hover:bg-amber-200 border border-amber-300'
                  }`}
                  title="আজ সবচেয়ে বেশিবার যোগ হওয়া পণ্য ফিল্টার করুন"
                >
                  <Flame className="w-3.5 h-3.5 text-orange-600 fill-orange-500" />
                  <span>সর্বাধিক যোগ ({mostFrequentProducts.length})</span>
                </button>
              )}
              {GROUP_RANGES.map(([start, end], idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedGroup(idx)}
                  style={{
                    backgroundColor: selectedGroup === idx ? GROUP_COLORS[idx] : undefined,
                    borderColor: GROUP_COLORS[idx]
                  }}
                  className={`px-2 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap border transition cursor-pointer flex items-center gap-1 ${
                    selectedGroup === idx
                      ? 'text-slate-950 font-black shadow-sm ring-2 ring-slate-900'
                      : 'bg-white text-slate-800 hover:bg-slate-50'
                  }`}
                >
                  <span
                    className="w-2.5 h-2.5 rounded-full inline-block border border-black/20"
                    style={{ backgroundColor: GROUP_COLORS[idx] }}
                  />
                  G{idx + 1}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Products Table (শিট) - সরাসরি উপরে দৃশ্যমান */}
        <section className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
          <div className="p-3 border-b border-slate-200 flex items-center justify-between bg-slate-50 flex-wrap gap-2">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-800 flex items-center gap-2">
                <span>পণ্য ও মেমো তালিকা</span>
                <span className="text-xs font-medium text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
                  {filteredProducts.length} টি দেখানো হচ্ছে
                </span>
              </h2>

              {/* Quick Today's Total indicator directly on sheet header */}
              <div
                id="sheet-header-quick-total"
                className="inline-flex items-center gap-1.5 bg-emerald-50 text-emerald-950 border border-emerald-300 px-2.5 py-1 rounded-xl text-xs font-extrabold shadow-2xs"
                title="আজকের মোট জমা টাকা ও পিস"
              >
                <span>আজকের জমা:</span>
                <span className="text-emerald-700 font-black">{money(totalDayMoney)} টাকা</span>
                <span className="text-emerald-400">•</span>
                <span>{money(totalDayPieces)} পিস</span>
              </div>

              {maxFrequency > 0 && mostFrequentProducts.length > 0 && (
                <div
                  className="flex items-center gap-1.5 bg-amber-50 border border-amber-300 text-amber-950 px-2.5 py-1 rounded-xl text-xs font-bold shadow-2xs"
                  title="আজকের দিনে সবচেয়ে বেশিবার যোগ হওয়া পণ্য (Most Frequent Product)"
                >
                  <Flame className="w-3.5 h-3.5 text-orange-600 fill-orange-500" />
                  <span className="text-amber-800 font-semibold">শীর্ষ পণ্য:</span>
                  <span className="font-black text-slate-950">
                    {mostFrequentProducts.map((p) => p.name).join(', ')}
                  </span>
                  <span className="bg-amber-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-black">
                    {money(maxFrequency)} বার যোগ
                  </span>
                </div>
              )}
            </div>

            {/* Active Memo Tool */}
            <div className="flex items-center gap-1.5 bg-blue-50/90 dark:bg-slate-800 border border-blue-200 dark:border-blue-900/50 px-2.5 py-1 rounded-xl shadow-2xs">
              <span className="text-xs font-extrabold text-blue-900 dark:text-blue-300 whitespace-nowrap">মেমো নং:</span>
              <input
                type="text"
                value={activeMemo}
                onChange={(e) => updateActiveMemo(e.target.value, currentDate)}
                placeholder="মেমো নাম্বার.01"
                className="w-28 sm:w-36 px-2 py-1 bg-white dark:bg-slate-900 border border-blue-300 dark:border-slate-700 rounded-lg text-xs font-bold text-blue-950 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-600 shadow-inner"
                title="চলতি মেমো নম্বর (প্রতিটি পণ্যে আলাদা লিখতে না চাইলে এখানে একবার দিলেই হবে)"
              />
              <button
                type="button"
                onClick={() => {
                  const next = incrementMemoString(activeMemo);
                  updateActiveMemo(next, currentDate);
                  showToast(`মেমো নম্বর আপডেট: ${next}`);
                }}
                className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-lg transition active:scale-95 cursor-pointer whitespace-nowrap flex items-center gap-1"
                title="পরবর্তী মেমো নম্বর (+১)"
              >
                +১ পরবর্তী
              </button>
              <button
                type="button"
                onClick={() => {
                  const resetVal = 'মেমো নাম্বার.01';
                  updateActiveMemo(resetVal, currentDate);
                  showToast('মেমো নম্বর ০১ এ রিসেট করা হয়েছে!');
                }}
                className="px-2 py-1 bg-slate-200 hover:bg-slate-300 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 font-bold text-xs rounded-lg transition active:scale-95 cursor-pointer whitespace-nowrap"
                title="আজকের মেমো ০১ এ রিসেট করুন"
              >
                ০১ রিসেট
              </button>
            </div>
          </div>

          <div className="overflow-x-auto tablebox">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-200/90 text-slate-800 font-extrabold border-b border-slate-300">
                  <th className="py-2.5 px-2.5 text-center w-10">নং</th>
                  <th className="py-2.5 px-3">পণ্য</th>
                  <th className="py-2.5 px-3 text-center min-w-[130px]">Quantity</th>
                  <th className="py-2.5 px-3 text-center">Price (টাকা)</th>
                  <th className="py-2.5 px-3 text-center min-w-[190px]">মেমো নম্বর / যোগ</th>
                  <th className="py-2.5 px-2.5 text-center min-w-[130px]" title="আজ পণ্যটি কতবার যোগ করা হয়েছে (Most Frequent Product)">
                    <div className="flex flex-col items-center justify-center">
                      <span className="whitespace-nowrap flex items-center gap-1 text-slate-900 font-extrabold">
                        <Flame className="w-3.5 h-3.5 text-orange-600 fill-orange-500" />
                        <span>যোগ সংখ্যা</span>
                      </span>
                      <span className="text-[10px] font-semibold text-slate-600 whitespace-nowrap">
                        (সবচেয়ে বেশি যোগ)
                      </span>
                    </div>
                  </th>
                  <th className="py-2.5 px-3 text-center">মোট Qty</th>
                  <th className="py-2.5 px-3 text-center">মোট টাকা</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((p) => {
                  const dayQty = currentDayData.sum[p.id] || 0;
                  const dayAmount = dayQty * p.price;
                  const currentInput = inputs[p.id] || 0;
                  const freq = productFrequencyMap[p.id] || 0;
                  const isMostFrequent = maxFrequency > 0 && freq === maxFrequency;

                  return (
                    <tr
                      key={p.id}
                      id={`product-row-${p.id}`}
                      style={{ backgroundColor: p.groupColor }}
                      className={`border-b border-slate-400/40 hover:brightness-95 transition-colors font-medium text-slate-950 ${
                        isMostFrequent ? 'ring-1 ring-amber-400/70' : ''
                      }`}
                    >
                      {/* Product Index */}
                      <td className="py-2 px-2 text-center text-[11px] font-bold text-slate-700">
                        {p.id + 1}
                      </td>

                      {/* Product Name */}
                      <td className="py-2 px-3 font-extrabold text-slate-950 whitespace-nowrap">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span>{p.name}</span>
                          <span className="text-[10px] font-normal text-slate-700/80 bg-black/5 px-1 py-0.2 rounded">
                            G{p.groupIndex + 1}
                          </span>
                          {isMostFrequent && (
                            <span
                              className="inline-flex items-center gap-0.5 bg-amber-200/95 text-amber-950 border border-amber-400 text-[10px] font-black px-1.5 py-0.5 rounded-full shadow-2xs"
                              title="আজকের দিনে সবচেয়ে বেশিবার যোগ হওয়া পণ্য (Most Frequent Product)"
                            >
                              <Flame className="w-3 h-3 text-orange-600 fill-orange-500 shrink-0 animate-pulse" />
                              <span>সর্বাধিক যোগ</span>
                            </span>
                          )}
                        </div>
                      </td>

                      {/* Quantity Input + quick step controls */}
                      <td className="py-2 px-2 text-center">
                        <div className="inline-flex items-center gap-1 justify-center">
                          <button
                            type="button"
                            onClick={() => handleQuickAdd(p.id, -1)}
                            className="w-6 h-7 rounded bg-black/10 hover:bg-black/20 text-slate-900 font-black text-sm flex items-center justify-center cursor-pointer transition active:scale-95"
                            title="১ কমান"
                          >
                            -
                          </button>
                          <input
                            id={`qty-input-${p.id}`}
                            type="number"
                            min="0"
                            step="1"
                            value={currentInput === 0 ? '' : currentInput}
                            placeholder="0"
                            onChange={(e) => handleInputChange(p.id, parseInt(e.target.value, 10))}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                addOne(p.id);
                              }
                            }}
                            className="w-16 sm:w-20 px-1 py-1.5 border-2 border-slate-900 rounded-lg text-center font-black text-base sm:text-lg bg-white text-slate-950 shadow-inner focus:outline-none focus:ring-2 focus:ring-blue-600"
                          />
                          <button
                            type="button"
                            onClick={() => handleQuickAdd(p.id, 1)}
                            className="w-6 h-7 rounded bg-black/10 hover:bg-black/20 text-slate-900 font-black text-sm flex items-center justify-center cursor-pointer transition active:scale-95"
                            title="১ বাড়ান"
                          >
                            +
                          </button>
                        </div>
                      </td>

                      {/* Locked Unit Price */}
                      <td className="py-2 px-3 text-center font-extrabold text-red-700 text-sm whitespace-nowrap">
                        {money(p.price)}
                      </td>

                      {/* Memo Number Input + Add Button */}
                      <td className="py-2 px-2 text-center">
                        <div className="inline-flex items-center gap-1.5 justify-center">
                          <input
                            id={`note-input-${p.id}`}
                            type="text"
                            value={notes[p.id] || ''}
                            onChange={(e) => handleNoteChange(p.id, e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                addOne(p.id);
                              }
                            }}
                            placeholder={activeMemo || 'মেমো নাম্বার.01'}
                            maxLength={40}
                            className="w-24 sm:w-28 md:w-32 px-2 py-1.5 border border-slate-400/80 rounded-lg text-xs bg-white text-slate-950 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-blue-600 transition shadow-inner font-normal"
                            title="মেমো নম্বর (যেমন: মেমো নাম্বার.01)"
                          />
                          <button
                            id={`add-btn-${p.id}`}
                            onClick={() => addOne(p.id)}
                            className="bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-extrabold text-xs px-2.5 sm:px-3 py-1.5 rounded-lg shadow-sm transition active:scale-95 cursor-pointer whitespace-nowrap shrink-0"
                            title="হিসাবে যোগ করুন"
                          >
                            যোগ
                          </button>
                        </div>
                      </td>

                      {/* Most Frequent / Frequency Column */}
                      <td className="py-2 px-2 text-center whitespace-nowrap">
                        {isMostFrequent ? (
                          <div
                            className="inline-flex items-center gap-1 bg-gradient-to-r from-amber-100 to-amber-200 text-amber-950 border border-amber-400 px-2.5 py-0.5 rounded-full text-xs font-black shadow-2xs"
                            title={`আজকের দিনে সবচেয়ে বেশিবার যোগ হয়েছে: ${freq} বার (Most Frequent)`}
                          >
                            <Flame className="w-3.5 h-3.5 text-orange-600 fill-orange-500 shrink-0 animate-bounce" />
                            <span>{money(freq)} বার</span>
                            <span className="bg-amber-600 text-white text-[9px] px-1 py-0.2 rounded font-black tracking-wide shrink-0">
                              শীর্ষ
                            </span>
                          </div>
                        ) : freq > 0 ? (
                          <span
                            className="inline-flex items-center gap-1 bg-white/90 text-slate-800 border border-slate-300 px-2 py-0.5 rounded-md text-xs font-bold shadow-2xs"
                            title={`আজ মোট ${freq} বার যোগ করা হয়েছে`}
                          >
                            {money(freq)} বার
                          </span>
                        ) : (
                          <span className="text-slate-400 text-xs font-normal" title="আজ এখনো যোগ করা হয়নি">
                            -
                          </span>
                        )}
                      </td>

                      {/* Cumulative Total Quantity */}
                      <td className="py-2 px-3 text-center font-black text-slate-900 text-sm whitespace-nowrap">
                        <div className="inline-flex items-center justify-center gap-1.5">
                          <span>{money(dayQty)}</span>
                          {dayQty > 0 && (
                            <button
                              type="button"
                              onClick={() => {
                                setDeleteModal({
                                  isOpen: true,
                                  type: 'reset-product',
                                  product: p
                                });
                              }}
                              className="p-1 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition cursor-pointer no-print"
                              title={`${p.name} এর আজকের জমা (${dayQty} পিস) মুছে ০ করতে ক্লিক করুন`}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>

                      {/* Cumulative Total Amount */}
                      <td className="py-2 px-3 text-center font-black text-slate-950 text-sm whitespace-nowrap">
                        {money(dayAmount)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* --- শিটের নিচে সকল সামারি ও কার্ডস (All Summaries & Cards Placed Below The Sheet) --- */}

        {/* Today's Deposit & Total Overview Card */}
        <section
          id="today-summary-card"
          className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl p-4 sm:p-5 shadow-lg border border-slate-700 relative overflow-hidden"
        >
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 w-44 h-44 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="text-xs font-semibold text-amber-400 uppercase tracking-wider">
                {currentDate === getTodayString() ? 'আজকের জমা হিসাব' : `${currentDate} তারিখের হিসাব`}
              </div>
              <div className="text-2xl sm:text-4xl font-black tracking-tight text-white mt-1 flex items-baseline gap-2">
                <AnimatedCounter
                  id="total-day-money-counter"
                  value={totalDayMoney}
                  formatter={money}
                  className="text-white"
                />
                <span className="text-base sm:text-xl font-bold text-amber-400">টাকা</span>
              </div>
              <div className="text-xs sm:text-sm text-slate-300 mt-1 flex items-center gap-3">
                <span>
                  মোট পিস:{' '}
                  <strong className="text-white font-black">
                    <AnimatedCounter
                      id="total-day-pieces-counter"
                      value={totalDayPieces}
                      formatter={money}
                      className="text-white"
                    />
                  </strong>{' '}
                  pcs
                </span>
                <span>•</span>
                <span>পণ্য সংখ্যা: <strong className="text-white font-bold">{products.length}</strong> টি</span>
              </div>
            </div>

            {/* Uncommitted input indicator */}
            {uncommittedTotal.pieces > 0 && (
              <div className="bg-amber-400/20 border border-amber-400/40 rounded-xl p-2.5 sm:p-3 text-amber-200 text-xs sm:text-sm">
                <div className="font-bold text-amber-300 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  ইনপুটে যোগের অপেক্ষায়:
                </div>
                <div className="text-white font-extrabold mt-0.5">
                  {uncommittedTotal.pieces} পিস = {money(uncommittedTotal.moneyAmt)} টাকা
                </div>
                <button
                  onClick={addAll}
                  className="mt-1.5 w-full bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-2 py-1 rounded text-xs transition cursor-pointer"
                >
                  এখনই জমা যোগ করুন ➔
                </button>
              </div>
            )}
          </div>

          <div className="mt-3 pt-3 border-t border-slate-700/80 text-xs text-slate-400 flex items-center justify-between flex-wrap gap-2">
            <span>💡 Quantity লিখে “যোগ” বাটনে চাপলে সেই পণ্যটি আজকের জমার সাথে যোগ হবে এবং ঘর ০ হবে।</span>
            <span className="text-emerald-400 font-semibold flex items-center gap-1">
              ✓ অফলাইন মোড ও স্বয়ংক্রিয় সেভ চালু
            </span>
          </div>
        </section>

        {/* Simple Memo Counter Section (Strictly Total Memos & Total Items - NO SALES/MONEY CALCULATION) */}
        <section
          id="memo-counter-section"
          className="bg-white dark:bg-slate-900 rounded-2xl p-4 sm:p-5 shadow-sm border border-slate-200 dark:border-slate-800 transition-colors"
        >
          <div className="flex items-center justify-between flex-wrap gap-2 mb-3.5">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 flex items-center justify-center font-black text-base shadow-2xs border border-blue-100 dark:border-blue-900/50">
                📋
              </div>
              <div>
                <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-slate-100 leading-tight">
                  Memo Counter (মেমো কাউন্টার)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  সংরক্ষিত মেমোর সংখ্যা এবং মেমোভুক্ত মোট পণ্যের (Quantity) হিসাব
                </p>
              </div>
            </div>

            {/* Scope switcher if there are multiple dates with saved data */}
            {allTimeMemoStats.totalMemos > 0 && (
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-bold no-print">
                <button
                  type="button"
                  id="memo-scope-day-btn"
                  onClick={() => setMemoCounterScope('day')}
                  className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                    memoCounterScope === 'day'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-2xs font-extrabold'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                  title="শুধুমাত্র আজকের সংরক্ষিত মেমোর হিসাব"
                >
                  আজকের মেমো ({dayMemoStats.totalMemos})
                </button>
                <button
                  type="button"
                  id="memo-scope-all-btn"
                  onClick={() => setMemoCounterScope('all')}
                  className={`px-3 py-1 rounded-lg transition cursor-pointer ${
                    memoCounterScope === 'all'
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-slate-100 shadow-2xs font-extrabold'
                      : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200'
                  }`}
                  title="অ্যাপের শুরু থেকে সব দিনের সর্বমোট সংরক্ষিত মেমো"
                >
                  সব দিন ({allTimeMemoStats.totalMemos})
                </button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            {/* 1. Total Memos */}
            <div
              id="total-memos-card"
              className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 flex items-center justify-between"
            >
              <div>
                <div className="text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-300">
                  Total Memos
                </div>
                <div className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mt-0.5 tracking-tight">
                  {displayMemos}
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  {memoCounterScope === 'day' ? 'আজকের সংরক্ষিত মেমো' : 'সব দিনের মোট সংরক্ষিত মেমো'}
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 flex items-center justify-center font-bold text-xl shrink-0">
                📝
              </div>
            </div>

            {/* 2. Total Items/Pieces */}
            <div
              id="total-items-card"
              className="bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700/80 rounded-xl p-4 flex items-center justify-between"
            >
              <div>
                <div className="text-xs sm:text-sm font-bold text-slate-600 dark:text-slate-300">
                  Total Items
                </div>
                <div className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400 mt-0.5 tracking-tight">
                  {displayItems} Pcs
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                  মেমোভুক্ত পণ্যের মোট পিস (Total Quantity)
                </div>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-blue-100 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 flex items-center justify-center font-bold text-xl shrink-0">
                📦
              </div>
            </div>
          </div>
        </section>

        {/* Category Order Summary Section (ক্যাটাগরিভিত্তিক অর্ডার ও বিক্রয় সামারি: সস, স্ন্যাক্স, সেমাই [পিস+ফুল], আচার, চাটনি, চকোলেড, এডিবল জেল, ড্রিংকস, বিন, অন্যান্য) */}
        <CategoryOrderSummary
          products={products}
          daySum={currentDayData.sum}
          unlistedItems={currentDayData.unlistedItems || []}
          currentDate={currentDate}
          onAddUnlistedItem={handleAddUnlistedItem}
          onDeleteUnlistedItem={handleDeleteUnlistedItem}
          onToast={showToast}
        />

        {/* Group Summary Section */}
        <section className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
          <div className="flex items-center justify-between">
            <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-500" />
              <span>📊 Group Summary — আজ পর্যন্ত জমা</span>
            </h2>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">৮টি ক্যাটাগরি</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {groupSummaries.map((g) => (
              <div
                key={g.groupIdx}
                style={{ backgroundColor: g.color }}
                className="p-3 rounded-xl border border-black/15 shadow-xs transition hover:shadow-md"
              >
                <div className="text-[11px] font-bold text-slate-800 uppercase tracking-wide">
                  {g.name}
                </div>
                <div className="mt-1 font-black text-sm sm:text-base text-slate-950 leading-tight">
                  {money(g.pieces)} pcs
                </div>
                <div className="text-xs font-extrabold text-slate-900/90 mt-0.5">
                  {money(g.amount)} টাকা
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Compact Itemized Bottom Product Summary (আইসবার - 100, লিচু - 02 আকারে) */}
        <BottomProductSummary
          products={products}
          daySum={currentDayData.sum}
          unlistedItems={currentDayData.unlistedItems || []}
          currentDate={currentDate}
          onCopyToast={showToast}
        />

        {/* Memo History Section */}
        <section id="memo-history-section" className="bg-white dark:bg-slate-900 rounded-2xl p-3 sm:p-4 shadow-sm border border-slate-200 dark:border-slate-800 space-y-3 transition-colors">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <History className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-slate-100">
                🧾 Memo History (আজকের এন্ট্রি তালিকা)
              </h2>
            </div>
            <div className="flex items-center gap-2 flex-wrap no-print">
              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                মোট {currentDayData.history.length} টি রেকর্ড
              </span>
              <button
                type="button"
                id="export-csv-history-btn"
                onClick={exportDayCSV}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700/60 transition cursor-pointer shadow-2xs"
                title="আজকের হিসাব ও মেমো হিস্ট্রি Excel / CSV হিসেবে ডাউনলোড করুন"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>Excel / CSV</span>
              </button>
              <button
                type="button"
                id="resync-history-btn"
                onClick={resyncCurrentDay}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-50 dark:bg-amber-950/40 hover:bg-amber-100 dark:hover:bg-amber-900/50 text-amber-900 dark:text-amber-300 border border-amber-300 dark:border-amber-700/60 transition cursor-pointer shadow-2xs"
                title="মেমো হিস্ট্রি অনুযায়ী উপরের মোট হিসাব সিঙ্ক ও ঠিক করুন"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-700 dark:text-amber-400" />
                <span>হিসাব সিঙ্ক</span>
              </button>
              {currentDayData.history.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setIsSelectionMode(!isSelectionMode);
                    if (isSelectionMode) {
                      setSelectedEntryIds([]);
                    }
                  }}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                    isSelectionMode
                      ? 'bg-blue-600 text-white shadow-xs hover:bg-blue-700'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700'
                  }`}
                  title="একাধিক এন্ট্রি নির্বাচন করে একসাথে মুছে ফেলতে ক্লিক করুন"
                >
                  {isSelectionMode ? (
                    <>
                      <X className="w-3.5 h-3.5" />
                      <span>সিলেকশন বন্ধ</span>
                    </>
                  ) : (
                    <>
                      <CheckSquare className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
                      <span>সিলেকশন মোড</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>

          {/* Selection Actions Bar */}
          {isSelectionMode && currentDayData.history.length > 0 && (
            <div className="flex items-center justify-between flex-wrap gap-2.5 p-2.5 sm:p-3 bg-blue-50 dark:bg-slate-800/80 border border-blue-200 dark:border-slate-700 rounded-xl text-xs sm:text-sm no-print">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-extrabold text-blue-900 dark:text-blue-300 bg-blue-200/90 dark:bg-blue-900/50 px-2.5 py-1 rounded-md text-xs">
                  {selectedSummary.count} টি নির্বাচিত
                </span>
                {selectedSummary.count > 0 ? (
                  <span className="text-blue-950 dark:text-slate-100 font-medium text-xs sm:text-sm">
                    মোট: <strong className="font-bold">{selectedSummary.pieces} পিস</strong> ({money(selectedSummary.amount)} টাকা)
                  </span>
                ) : (
                  <span className="text-slate-500 dark:text-slate-400 text-xs italic">
                    নিচের চেকবক্সে টিক দিন অথবা এক ক্লিকে সবগুলো নির্বাচন করুন
                  </span>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={toggleSelectAll}
                  className="px-2.5 py-1.5 bg-white dark:bg-slate-700 hover:bg-blue-100 dark:hover:bg-slate-600 text-blue-900 dark:text-slate-100 border border-blue-300 dark:border-slate-600 rounded-lg font-bold text-xs transition cursor-pointer shadow-2xs"
                >
                  {visibleHistory.length > 0 &&
                  visibleHistory.every((h) => selectedEntryIds.includes(h.id))
                    ? 'সব বাতিল'
                    : 'সবগুলো নির্বাচন'}
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const toDelete = currentDayData.history.filter((h) => selectedEntryIds.includes(h.id));
                    if (toDelete.length > 0) {
                      setDeleteModal({
                        isOpen: true,
                        type: 'bulk',
                        entries: toDelete
                      });
                    }
                  }}
                  disabled={selectedSummary.count === 0}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs transition shadow-2xs ${
                    selectedSummary.count > 0
                      ? 'bg-red-600 hover:bg-red-700 text-white cursor-pointer active:scale-95'
                      : 'bg-slate-200 dark:bg-slate-800 text-slate-400 dark:text-slate-600 cursor-not-allowed'
                  }`}
                  title={selectedSummary.count > 0 ? 'নির্বাচিত এন্ট্রিগুলো মুছে ফেলুন' : 'আগে এন্ট্রি নির্বাচন করুন'}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>মুছে ফেলুন ({selectedSummary.count} টি)</span>
                </button>
              </div>
            </div>
          )}

          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800 tablebox">
            <table className="w-full border-collapse text-left text-xs sm:text-sm">
              <thead>
                <tr className="bg-slate-100 dark:bg-slate-800/90 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-800">
                  {isSelectionMode && (
                    <th className="py-2 px-3 text-center w-10 no-print">
                      <input
                        type="checkbox"
                        checked={
                          visibleHistory.length > 0 &&
                          visibleHistory.every((h) => selectedEntryIds.includes(h.id))
                        }
                        onChange={toggleSelectAll}
                        className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                        title="সবগুলো নির্বাচন / বাতিল করুন"
                      />
                    </th>
                  )}
                  <th className="py-2 px-3">সময়</th>
                  <th className="py-2 px-3">পণ্য</th>
                  <th className="py-2 px-3 text-center">Quantity (পিস)</th>
                  <th className="py-2 px-3 text-center">টাকা</th>
                  <th className="py-2 px-3 text-left">মেমো নম্বর</th>
                  <th className="py-2 px-3 text-center no-print">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {currentDayData.history.length === 0 ? (
                  <tr>
                    <td colSpan={isSelectionMode ? 7 : 6} className="py-6 text-center text-slate-400 dark:text-slate-500 font-medium">
                      আজ এখনো কোনো হিসাব যোগ করা হয়নি।
                    </td>
                  </tr>
                ) : (
                  visibleHistory.map((item) => {
                    const isSelected = selectedEntryIds.includes(item.id);
                    return (
                      <tr
                        key={item.id}
                        onClick={isSelectionMode ? () => toggleSelectEntry(item.id) : undefined}
                        className={`transition font-medium ${
                          isSelected
                            ? 'bg-blue-50/90 dark:bg-blue-950/40 text-blue-950 dark:text-blue-200 font-semibold'
                            : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                        } ${isSelectionMode ? 'cursor-pointer' : ''}`}
                      >
                        {isSelectionMode && (
                          <td className="py-2 px-3 text-center no-print" onClick={(e) => e.stopPropagation()}>
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelectEntry(item.id)}
                              className="w-4 h-4 text-blue-600 rounded border-slate-300 dark:border-slate-700 focus:ring-blue-500 cursor-pointer"
                            />
                          </td>
                        )}
                        <td className="py-2 px-3 text-slate-500 dark:text-slate-400 font-mono text-xs">{item.time}</td>
                        <td className="py-2 px-3 font-bold text-slate-900 dark:text-slate-100">{item.productName}</td>
                        <td className="py-2 px-3 text-center font-extrabold text-blue-700 dark:text-blue-400">
                          {money(item.quantity)}
                        </td>
                        <td className="py-2 px-3 text-center font-extrabold text-slate-900 dark:text-slate-100">
                          {money(item.amount)} টাকা
                        </td>
                        <td className="py-2 px-3" onClick={(e) => e.stopPropagation()}>
                          {editingNoteId === item.id ? (
                            <div className="flex items-center gap-1">
                              <input
                                type="text"
                                value={editingNoteText}
                                onChange={(e) => setEditingNoteText(e.target.value)}
                                onKeyDown={(e) => {
                                  if (e.key === 'Enter') saveEditedNote(item.id);
                                  if (e.key === 'Escape') {
                                    setEditingNoteId(null);
                                    setEditingNoteText('');
                                  }
                                }}
                                autoFocus
                                maxLength={40}
                                placeholder="মেমো নম্বর লিখুন..."
                                className="w-28 sm:w-36 px-2 py-1 border border-blue-500 rounded text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-xs font-semibold"
                              />
                              <button
                                onClick={() => saveEditedNote(item.id)}
                                className="p-1 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded cursor-pointer"
                                title="সংরক্ষণ করুন"
                              >
                                <CheckCheck className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => {
                                  setEditingNoteId(null);
                                  setEditingNoteText('');
                                }}
                                className="p-1 text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded cursor-pointer"
                                title="বাতিল করুন"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center gap-1.5 group">
                              {item.note ? (
                                <span className="inline-flex items-center gap-1 bg-blue-50 dark:bg-blue-950/60 text-blue-900 dark:text-blue-300 border border-blue-200 dark:border-blue-800 px-2.5 py-0.5 rounded text-xs font-bold shadow-2xs">
                                  <FileText className="w-3 h-3 text-blue-600 dark:text-blue-400" />
                                  <span>{item.note}</span>
                                </span>
                              ) : (
                                <span className="text-slate-400 dark:text-slate-500 text-xs italic no-print">—</span>
                              )}
                              <button
                                onClick={() => {
                                  setEditingNoteId(item.id);
                                  setEditingNoteText(item.note || '');
                                }}
                                className="opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-blue-50 dark:hover:bg-slate-800 rounded transition no-print cursor-pointer"
                                title={item.note ? 'মেমো নম্বর এডিট করুন' : 'মেমো নম্বর লিখুন'}
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          )}
                        </td>
                        <td className="py-2 px-3 text-center no-print" onClick={(e) => e.stopPropagation()}>
                          <button
                            type="button"
                            onClick={() => {
                              setDeleteModal({
                                isOpen: true,
                                type: 'single',
                                entry: item
                              });
                            }}
                            className="p-1.5 rounded-lg text-red-600 hover:bg-red-50 dark:hover:bg-red-950/50 hover:text-red-800 dark:hover:text-red-400 transition cursor-pointer active:scale-90"
                            title="এই এন্ট্রি মুছে ফেলুন এবং মোট থেকে বাদ দিন"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
            {currentDayData.history.length > 50 && (
              <div className="p-2.5 text-center bg-slate-50 dark:bg-slate-800/60 border-t border-slate-200 dark:border-slate-800 no-print">
                <button
                  type="button"
                  onClick={() => setShowAllHistory(!showAllHistory)}
                  className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition cursor-pointer"
                >
                  {showAllHistory
                    ? 'সংক্ষেপ করুন (সর্বশেষ ৫০টি দেখুন)'
                    : `সবগুলো (${currentDayData.history.length}টি) রেকর্ড দেখুন`}
                </button>
              </div>
            )}
          </div>
        </section>
          </>
        )}

        {/* Play-Ready App Download Card at the bottom */}
        <section className="no-print pt-2">
          <PWAInstallButton variant="play-ready" />
        </section>
      </main>

      {/* Backup / Export Modal */}
      {showBackupModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-2 sm:p-4 backdrop-blur-xs overflow-y-auto overscroll-contain animate-fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowBackupModal(false);
          }}
        >
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh] overflow-hidden my-auto animate-scale-in">
            {/* Sticky Header with prominent Close button */}
            <div className="bg-slate-900 text-white px-4 sm:px-5 py-3.5 flex items-center justify-between border-b border-slate-800 shrink-0 sticky top-0 z-10 shadow-xs">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 text-amber-400 flex items-center justify-center font-bold">
                  <Download className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-black text-white">
                    ডাটা ব্যাকআপ ও সেটিংস
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    দৈনিক সামারি নোটিফিকেশন, মেমো রিপোর্ট ও ব্যাকআপ
                  </p>
                </div>
              </div>
              <button
                type="button"
                id="close-backup-modal-header-btn"
                onClick={() => setShowBackupModal(false)}
                className="px-3 py-1.5 rounded-xl bg-rose-600/20 hover:bg-rose-600/30 active:bg-rose-600/40 text-rose-300 border border-rose-500/40 text-xs sm:text-sm font-bold flex items-center gap-1.5 transition cursor-pointer active:scale-95 shadow-xs"
                title="উইন্ডো বন্ধ করুন"
              >
                <X className="w-4 h-4 text-rose-400" />
                <span>বন্ধ করুন</span>
              </button>
            </div>

            {/* Scrollable Content Body */}
            <div className="overflow-y-auto p-4 sm:p-5 space-y-3.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 flex-1 overscroll-contain">
              {/* Google Drive Automatic Real-time Cloud Sync Card */}
              <GoogleDriveSyncCard
                getBackupPayload={getBackupPayload}
                onRestoreData={handleRestorePayload}
                onShowToast={showToast}
              />

              {/* Daily Summary Notification Setting Card */}
              <DailyNotificationSettings
                onDownloadPDF={handleDownloadPDF}
                onDownloadCSV={exportDayCSV}
                onShowToast={showToast}
              />

              <p className="text-xs text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800/60 p-2.5 rounded-xl border border-slate-200/80 dark:border-slate-700/80">
                আপনার মেমো কাউন্টারের সকল দিনের জমা এবং হিস্ট্রি সুরক্ষিত রাখতে ব্যাকআপ ফাইল ডাউনলোড করুন অথবা আগের ব্যাকআপ রিস্টোর করুন।
              </p>

              <div className="p-3 bg-gradient-to-r from-blue-500/10 via-amber-500/10 to-emerald-500/10 dark:bg-slate-800/80 rounded-xl border border-blue-300 dark:border-blue-700/60 space-y-2.5">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    ১. সম্পূর্ণ ডেটা ও সকল ছবি পার্মানেন্ট ব্যাকআপ (Full Export)
                  </span>
                  <span className="text-[10px] font-black bg-blue-600 text-white px-2 py-0.5 rounded-full">
                    ছবি সহ
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300">
                  আপনার সকল আপলোড করা পণ্যের ছবি ({Object.keys(imageMap).length} টি), মেমো, রেট এবং হিস্ট্রি পার্মানেন্টলি সেভ করে ব্যাকআপ ফাইল ডাউনলোড করুন।
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={exportBackupJSON}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 text-xs"
                  >
                    <Download className="w-4 h-4 text-amber-300" />
                    সম্পূর্ণ ব্যাকআপ (ছবি + ডেটা)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      exportAllPhotosJSON(imageMap, products);
                      showToast('শুধু ছবিগুলোর ব্যাকআপ ফাইল ডাউনলোড হয়েছে!');
                    }}
                    className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-amber-300 font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 text-xs"
                  >
                    <Camera className="w-4 h-4 text-amber-400" />
                    শুধু ছবি ব্যাকআপ (JSON)
                  </button>
                </div>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center justify-between">
                  <span>২. ব্যাকআপ লোড ও ছবি রিস্টোর (Restore with Photos)</span>
                  <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                    সহজ রিস্টোর
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  আগের সংরক্ষিত যেকোনো ব্যাকআপ ফাইল বা ছবির ফাইল সিলেক্ট করলেই স্বয়ংক্রিয়ভাবে সমস্ত ছবি ও হিসাব রিস্টোর হয়ে যাবে।
                </p>
                <label className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer text-center shadow-xs active:scale-95 text-xs sm:text-sm">
                  <Upload className="w-4 h-4" />
                  ব্যাকআপ ফাইল সিলেক্ট করুন
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportFile}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="p-3 bg-rose-50/80 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-800/60 space-y-2">
                <div className="font-bold text-rose-950 dark:text-rose-300 flex items-center justify-between">
                  <span>৩. আজকের সুবিন্যস্ত PDF রিপোর্ট (Browser PDF)</span>
                  <span className="text-[11px] font-semibold text-rose-800 dark:text-rose-300 bg-rose-200/70 dark:bg-rose-900/60 px-1.5 py-0.5 rounded">
                    {currentDate}
                  </span>
                </div>
                <p className="text-xs text-rose-800 dark:text-rose-300/90">
                  ব্রাউজারে সরাসরি প্রস্তুত করা ঝকঝকে প্রফেশনাল A4 সাইজ PDF রিপোর্ট ডাউনলোড করুন (গ্রুপ বিবরণী, ৪৫টি পণ্যের বিক্রয় ও বিস্তারিত মেমো হিস্ট্রি সম্বলিত)।
                </p>
                <button
                  type="button"
                  onClick={handleDownloadPDF}
                  disabled={isGeneratingPdf}
                  className="w-full py-2 bg-rose-700 hover:bg-rose-800 active:bg-rose-900 disabled:opacity-60 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm shadow-xs active:scale-95"
                >
                  {isGeneratingPdf ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <FileDown className="w-4 h-4 text-rose-100" />
                  )}
                  <span>{isGeneratingPdf ? (pdfProgressStatus || 'PDF তৈরি হচ্ছে...') : 'PDF ফাইল ডাউনলোড করুন'}</span>
                </button>
              </div>

              <div className="p-3 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800/60 space-y-2">
                <div className="font-bold text-emerald-950 dark:text-emerald-300 flex items-center justify-between">
                  <span>৪. আজকের Excel / CSV রিপোর্ট</span>
                  <span className="text-[11px] font-semibold text-emerald-800 dark:text-emerald-300 bg-emerald-200/70 dark:bg-emerald-900/60 px-1.5 py-0.5 rounded">
                    {currentDate}
                  </span>
                </div>
                <p className="text-xs text-emerald-800 dark:text-emerald-300/90">
                  আজকের পণ্যভিত্তিক বিক্রয় সারসংক্ষেপ ও সম্পূর্ণ মেমো হিস্ট্রি এক্সেলে খোলার উপযোগী CSV ফাইল হিসেবে ডাউনলোড করুন।
                </p>
                <button
                  type="button"
                  onClick={exportDayCSV}
                  className="w-full py-2 bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm shadow-xs active:scale-95"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  Excel / CSV ফাইল ডাউনলোড করুন
                </button>
              </div>

              <div className="p-3.5 bg-gradient-to-r from-emerald-500/15 via-teal-500/15 to-blue-500/15 rounded-xl border border-emerald-300 dark:border-emerald-700/60 space-y-2.5">
                <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <FileCode className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    ৫. সম্পূর্ণ অফলাইন অ্যাপ ফাইল (Single HTML File)
                  </span>
                  <span className="text-[10px] font-black bg-emerald-600 text-white px-2 py-0.5 rounded-full uppercase">
                    হাতে তৈরি ফাইল
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  এটি একটি একক (Single) ফাইল যা যেকোনো মোবাইল বা কম্পিউটারে কোনো ইন্টারনেট বা সার্ভার ছাড়াই সরাসরি ডাবল ক্লিক বা ব্রাউজারে ওপেন করলেই চলবে।
                </p>
                <a
                  id="modal-download-offline-html-btn"
                  href="/Raju-Daily-Summary-Standalone.html"
                  download="Raju-Daily-Summary.html"
                  onClick={() => showToast('অফলাইন সিঙ্গেল ফাইল অ্যাপ (HTML) ডাউনলোড শুরু হয়েছে...')}
                  className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold rounded-lg transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm shadow-xs active:scale-95 text-center"
                >
                  <FileCode className="w-4 h-4 text-emerald-200" />
                  <span>অফলাইন অ্যাপ ফাইল (HTML) ডাউনলোড করুন</span>
                </a>
              </div>

              <div className="p-3.5 bg-gradient-to-r from-slate-900 to-slate-950 text-white rounded-xl border border-slate-700 shadow-lg space-y-2.5">
                <div className="font-bold flex items-center justify-between">
                  <span className="flex items-center gap-1.5 text-amber-300">
                    <FolderArchive className="w-4 h-4 text-amber-400" />
                    ৬. সম্পূর্ণ অ্যাপ্লিকেশন ও প্রজেক্ট ব্যাকআপ (ZIP - ১-ক্লিক ব্যাকআপ)
                  </span>
                  <span className="text-[10px] font-black bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full uppercase">
                    ফুল প্রজেক্ট
                  </span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  এই জিপ ফাইলে অ্যাপের সম্পূর্ণ সোর্স কোড, অফলাইন সিঙ্গেল ফাইল, নির্দেশনা এবং সকল কম্পোনেন্ট সংরক্ষিত আছে। আপনার ফোনের মেমরিতে ডাউনলোড করে রাখলে ভবিষ্যতে সার্ভার, পিসি অথবা যেকোনো AI (Gemini, Claude, ChatGPT)-কে দিলে ১ মিনিটেই পুরো প্রজেক্ট লাইভ চালানো যাবে।
                </p>
                <a
                  id="download-app-zip-btn"
                  href="/RajuDailySummary-Project.zip"
                  download="RajuDailySummary-Complete-Project.zip"
                  onClick={() => showToast('সম্পূর্ণ অ্যাপ্লিকেশন ও প্রজেক্ট জিপ (ZIP) ডাউনলোড শুরু হয়েছে...')}
                  className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black rounded-lg transition flex items-center justify-center gap-2 cursor-pointer text-xs sm:text-sm text-center shadow-md active:scale-95"
                >
                  <Download className="w-4 h-4 text-emerald-100" />
                  <span>১-ক্লিকে সম্পূর্ণ প্রজেক্ট জিপ ডাউনলোড করুন (ZIP)</span>
                </a>
              </div>
            </div>

            {/* Sticky Footer */}
            <div className="p-3 sm:p-4 bg-slate-100 dark:bg-slate-950/90 border-t border-slate-200 dark:border-slate-800 shrink-0 flex items-center justify-between gap-3 sticky bottom-0 z-10 shadow-inner">
              <span className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400 truncate">
                বাইরে ক্লিক করেও বন্ধ করতে পারেন
              </span>
              <button
                type="button"
                id="close-backup-modal-footer-btn"
                onClick={() => setShowBackupModal(false)}
                className="px-4 py-2 bg-slate-900 hover:bg-slate-800 active:bg-slate-700 dark:bg-slate-800 dark:hover:bg-slate-700 text-white font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer flex items-center gap-1.5 active:scale-95 shadow-xs shrink-0"
              >
                <X className="w-4 h-4 text-slate-400" />
                <span>উইন্ডো বন্ধ করুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Custom In-App Delete Confirmation Modal (Iframe & Mobile Safe) */}
      {deleteModal && deleteModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-4 sm:p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 animate-scale-in">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-full bg-red-100 dark:bg-red-950/60 flex items-center justify-center shrink-0 text-red-600 dark:text-red-400">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="space-y-1 flex-1">
                <h3 className="text-base font-extrabold text-slate-900 dark:text-slate-100">
                  {deleteModal.type === 'single' && 'মেমো এন্ট্রি মুছে ফেলতে চান?'}
                  {deleteModal.type === 'bulk' && `নির্বাচিত ${deleteModal.entries?.length || 0}টি এন্ট্রি মুছে ফেলতে চান?`}
                  {deleteModal.type === 'reset-product' && `"${deleteModal.product?.name}" এর আজকের জমা ০ করবেন?`}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">
                  {deleteModal.type === 'single' && 'এই এন্ট্রি মুছে ফেললে উপরের পণ্য তালিকা থেকেও এই পরিমাণ স্বয়ংক্রিয়ভাবে বাদ যাবে।'}
                  {deleteModal.type === 'bulk' && 'নির্বাচিত সব এন্ট্রি মুছে ফেললে উপরের পণ্য তালিকা থেকেও সংশ্লিষ্ট মোট হিসাব স্বয়ংক্রিয়ভাবে কমে যাবে।'}
                  {deleteModal.type === 'reset-product' && 'এটি নিশ্চিত করলে এই পণ্যের আজকের মোট জমা শূন্য (০) হয়ে যাবে এবং আজকের মেমো হিস্ট্রি থেকেও এর এন্ট্রিগুলো মুছে যাবে।'}
                </p>
              </div>
            </div>

            {/* Details Box */}
            <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-xl border border-slate-200 dark:border-slate-700 text-xs sm:text-sm space-y-1.5">
              {deleteModal.type === 'single' && deleteModal.entry && (
                <>
                  <div className="flex justify-between font-bold text-slate-900 dark:text-slate-100">
                    <span>পণ্য:</span>
                    <span className="text-blue-700 dark:text-blue-400">{deleteModal.entry.productName}</span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>পরিমাণ:</span>
                    <span className="font-extrabold text-slate-900 dark:text-slate-100">{money(deleteModal.entry.quantity)} পিস</span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>টাকা:</span>
                    <span className="font-extrabold text-emerald-700 dark:text-emerald-400">{money(deleteModal.entry.amount)} টাকা</span>
                  </div>
                  <div className="flex justify-between text-slate-500 dark:text-slate-400 text-xs">
                    <span>সময় ও নোট:</span>
                    <span>{deleteModal.entry.time} {deleteModal.entry.note ? `[${deleteModal.entry.note}]` : ''}</span>
                  </div>
                </>
              )}

              {deleteModal.type === 'bulk' && deleteModal.entries && (
                <>
                  <div className="flex justify-between font-bold text-slate-900 dark:text-slate-100">
                    <span>মোট নির্বাচিত এন্ট্রি:</span>
                    <span className="text-blue-700 dark:text-blue-400">{deleteModal.entries.length} টি</span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>মোট পরিমাণ:</span>
                    <span className="font-extrabold text-slate-900 dark:text-slate-100">
                      {money(deleteModal.entries.reduce((sum, e) => sum + e.quantity, 0))} পিস
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>মোট বিক্রয় মূল্য:</span>
                    <span className="font-extrabold text-emerald-700 dark:text-emerald-400">
                      {money(deleteModal.entries.reduce((sum, e) => sum + e.amount, 0))} টাকা
                    </span>
                  </div>
                </>
              )}

              {deleteModal.type === 'reset-product' && deleteModal.product && (
                <>
                  <div className="flex justify-between font-bold text-slate-900 dark:text-slate-100">
                    <span>পণ্য:</span>
                    <span className="text-blue-700 dark:text-blue-400">{deleteModal.product.name}</span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>আজকের মোট জমা:</span>
                    <span className="font-extrabold text-red-600 dark:text-red-400">
                      {money(currentDayData.sum[deleteModal.product.id] || 0)} পিস
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-700 dark:text-slate-300">
                    <span>মোট টাকা:</span>
                    <span className="font-extrabold text-red-600 dark:text-red-400">
                      {money((currentDayData.sum[deleteModal.product.id] || 0) * deleteModal.product.price)} টাকা
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer"
              >
                বাতিল করুন
              </button>
              <button
                type="button"
                onClick={() => {
                  if (deleteModal.type === 'single' && deleteModal.entry) {
                    executeDeleteHistoryEntry(deleteModal.entry);
                  } else if (deleteModal.type === 'bulk' && deleteModal.entries) {
                    executeBulkDelete(deleteModal.entries);
                  } else if (deleteModal.type === 'reset-product' && deleteModal.product) {
                    executeResetProduct(deleteModal.product);
                  }
                }}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-extrabold rounded-xl text-xs sm:text-sm shadow-sm transition active:scale-95 cursor-pointer flex items-center gap-1.5"
              >
                <Trash2 className="w-4 h-4" />
                <span>হ্যাঁ, মুছে ফেলুন</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product & Price Manager Modal (Add Product, Update Prices, Reset) */}
      <ProductPriceManagerModal
        isOpen={showProductManagerModal}
        onClose={() => setShowProductManagerModal(false)}
        products={products}
        onUpdateProducts={handleUpdateProducts}
        onResetProducts={handleResetProducts}
        onToast={showToast}
      />

      {/* Daily Summary In-App Reminder Due Banner */}
      {inAppReminderDue && (
        <DailyReminderDueBanner
          currentDate={currentDate}
          onDownloadPDF={handleDownloadPDF}
          onDownloadCSV={exportDayCSV}
          onDismiss={dismissInAppReminder}
        />
      )}

      {/* Floating Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-20 sm:bottom-22 left-1/2 -translate-x-1/2 z-50 bg-slate-900/95 text-white border border-slate-700 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold shadow-2xl backdrop-blur-xs flex items-center gap-2 animate-fade-in pointer-events-none">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Persistent Bottom Navigation Bar for Mobile & Desktop */}
      <nav
        id="persistent-bottom-navbar"
        aria-label="Bottom Navigation"
        className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 shadow-[0_-4px_16px_rgba(0,0,0,0.06)] dark:shadow-[0_-4px_16px_rgba(0,0,0,0.3)] no-print pb-safe"
      >
        <div className="max-w-xl mx-auto grid grid-cols-4 h-16 items-stretch px-1">
          {/* 1. Catalog Tab (Product Pictures - FIRST) */}
          <button
            type="button"
            id="bottom-nav-catalog-tab"
            onClick={() => {
              setActiveViewMode('catalog');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-all cursor-pointer relative py-1 ${
              activeViewMode === 'catalog'
                ? 'text-emerald-600 dark:text-emerald-400 font-extrabold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            {activeViewMode === 'catalog' && (
              <span className="absolute top-0 w-8 sm:w-10 h-1 bg-emerald-600 dark:bg-emerald-400 rounded-b-full transition-all" />
            )}
            <div className="relative">
              <ShoppingBag className="w-5 h-5" />
              {Object.keys(imageMap).length > 0 && (
                <span className="absolute -top-1.5 -right-2 bg-emerald-600 text-white text-[9px] font-black rounded-full px-1 py-0.2 min-w-[14px] text-center leading-tight shadow-xs">
                  {Object.keys(imageMap).length}
                </span>
              )}
            </div>
            <span className="text-[10px] sm:text-xs leading-none">পণ্য (ছবি)</span>
          </button>

          {/* 2. Counter Tab ("Amar ey samari apk") */}
          <button
            type="button"
            id="bottom-nav-counter-tab"
            onClick={() => {
              setActiveViewMode('counter');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-all cursor-pointer relative py-1 ${
              activeViewMode === 'counter'
                ? 'text-blue-600 dark:text-amber-400 font-extrabold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            {activeViewMode === 'counter' && (
              <span className="absolute top-0 w-8 sm:w-10 h-1 bg-blue-600 dark:bg-amber-400 rounded-b-full transition-all" />
            )}
            <div className="relative">
              <Layers className="w-5 h-5" />
              {pendingInputsCount > 0 && (
                <span className="absolute -top-1.5 -right-2.5 bg-rose-600 text-white text-[10px] font-black rounded-full px-1.5 py-0.2 min-w-[16px] text-center leading-tight shadow-xs animate-pulse">
                  {pendingInputsCount}
                </span>
              )}
            </div>
            <span className="text-[10px] sm:text-xs leading-none">মেমো সামারি</span>
          </button>

          {/* 2. Dashboard Tab */}
          <button
            type="button"
            id="bottom-nav-dashboard-tab"
            onClick={() => {
              setActiveViewMode('dashboard');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-all cursor-pointer relative py-1 ${
              activeViewMode === 'dashboard'
                ? 'text-blue-600 dark:text-amber-400 font-extrabold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            {activeViewMode === 'dashboard' && (
              <span className="absolute top-0 w-10 sm:w-12 h-1 bg-blue-600 dark:bg-amber-400 rounded-b-full transition-all" />
            )}
            <div className="relative">
              <LayoutDashboard className="w-5 h-5" />
            </div>
            <span className="text-[11px] sm:text-xs leading-none">ড্যাশবোর্ড</span>
          </button>

          {/* 3. History Tab */}
          <button
            type="button"
            id="bottom-nav-history-tab"
            onClick={() => {
              setActiveViewMode('history');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className={`flex flex-col items-center justify-center gap-1 transition-all cursor-pointer relative py-1 ${
              activeViewMode === 'history'
                ? 'text-blue-600 dark:text-amber-400 font-extrabold'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 font-medium'
            }`}
          >
            {activeViewMode === 'history' && (
              <span className="absolute top-0 w-10 sm:w-12 h-1 bg-blue-600 dark:bg-amber-400 rounded-b-full transition-all" />
            )}
            <div className="relative">
              <History className="w-5 h-5" />
              {currentDayData.history.length > 0 && (
                <span className="absolute -top-1.5 -right-3 bg-blue-600 text-white text-[10px] font-bold rounded-full px-1.5 py-0.2 min-w-[16px] text-center leading-tight">
                  {currentDayData.history.length > 99 ? '99+' : currentDayData.history.length}
                </span>
              )}
            </div>
            <span className="text-[11px] sm:text-xs leading-none">হিস্ট্রি</span>
          </button>
        </div>
      </nav>

      {/* Offline Status Bar */}
      <OfflineIndicator />
    </div>
  );
}
