import { useState, useEffect, useCallback } from 'react';

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export interface DailyNotificationConfig {
  enabled: boolean;
  reminderTime: string; // "HH:MM" e.g. "20:00"
  lastNotifiedDate: string; // "YYYY-MM-DD"
  notifyViaSound: boolean;
}

const STORAGE_KEY_CONFIG = 'raju_daily_notification_config';
const DEFAULT_CONFIG: DailyNotificationConfig = {
  enabled: false,
  reminderTime: '20:00', // 8:00 PM default (end of business day)
  lastNotifiedDate: '',
  notifyViaSound: true,
};

function getStoredConfig(): DailyNotificationConfig {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CONFIG);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        enabled: Boolean(parsed.enabled),
        reminderTime: typeof parsed.reminderTime === 'string' ? parsed.reminderTime : '20:00',
        lastNotifiedDate: typeof parsed.lastNotifiedDate === 'string' ? parsed.lastNotifiedDate : '',
        notifyViaSound: parsed.notifyViaSound !== false,
      };
    }
  } catch (e) {
    console.error('Error reading notification config from localStorage:', e);
  }
  return DEFAULT_CONFIG;
}

function saveStoredConfig(config: DailyNotificationConfig) {
  try {
    localStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(config));
  } catch (e) {
    console.error('Error saving notification config to localStorage:', e);
  }
}

export function useDailyNotification(onTriggerReminder?: () => void) {
  const [config, setConfig] = useState<DailyNotificationConfig>(getStoredConfig);
  const [permission, setPermission] = useState<NotificationPermissionState>(() => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      return 'unsupported';
    }
    return Notification.permission as NotificationPermissionState;
  });
  const [isTesting, setIsTesting] = useState(false);
  const [inAppReminderDue, setInAppReminderDue] = useState(false);

  // Sync permission status if it changes
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      setPermission(Notification.permission as NotificationPermissionState);
    }
  }, []);

  // Save config changes to localStorage
  const updateConfig = useCallback((updater: Partial<DailyNotificationConfig> | ((prev: DailyNotificationConfig) => DailyNotificationConfig)) => {
    setConfig((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : { ...prev, ...updater };
      saveStoredConfig(next);
      return next;
    });
  }, []);

  // Dispatch system notification via Service Worker or standard Notification constructor
  const dispatchNotification = useCallback(async (title: string, options: NotificationOptions) => {
    // Check if Service Worker can show notification (best for PWAs & Android Web APK)
    if ('serviceWorker' in navigator) {
      try {
        const registration = await navigator.serviceWorker.ready;
        if (registration && typeof registration.showNotification === 'function') {
          await registration.showNotification(title, options);
          return true;
        }
      } catch (swErr) {
        console.warn('Service worker showNotification failed, falling back to window.Notification:', swErr);
      }
    }

    // Fallback to standard window.Notification constructor
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        const notification = new Notification(title, options);
        notification.onclick = () => {
          window.focus();
          notification.close();
        };
        return true;
      } catch (notifErr) {
        console.warn('window.Notification constructor failed:', notifErr);
      }
    }

    return false;
  }, []);

  // Request browser permission and enable daily notification
  const enableNotifications = useCallback(async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setPermission('unsupported');
      return {
        success: false,
        permission: 'unsupported' as NotificationPermissionState,
        message: 'আপনার বর্তমান ব্রাউজারে নোটিফিকেশন API সাপোর্ট করে না। তবে অ্যাপের ভেতরে ইন-অ্যাপ রিমাইন্ডার কাজ করবে।'
      };
    }

    try {
      let result: NotificationPermission;
      // Handle promise vs callback syntax for requestPermission
      if (typeof Notification.requestPermission === 'function') {
        try {
          result = await Notification.requestPermission();
        } catch {
          result = await new Promise((resolve) => Notification.requestPermission(resolve));
        }
      } else {
        result = 'denied';
      }

      setPermission(result as NotificationPermissionState);

      if (result === 'granted') {
        updateConfig({ enabled: true });
        return {
          success: true,
          permission: 'granted' as NotificationPermissionState,
          message: 'সফলভাবে নোটিফিকেশন অনুমোদন করা হয়েছে! প্রতিদিন নির্দিষ্ট সময়ে দৈনিক রিপোর্ট রিমাইন্ডার পাবেন।'
        };
      } else if (result === 'denied') {
        updateConfig({ enabled: false });
        return {
          success: false,
          permission: 'denied' as NotificationPermissionState,
          message: 'ব্রাউজারে নোটিফিকেশন ব্লক করা রয়েছে। ব্রাউজার অ্যাড্রেসবারের লক (🔒) আইকনে ক্লিক করে নোটিফিকেশন "Allow" করে দিন।'
        };
      } else {
        return {
          success: false,
          permission: 'default' as NotificationPermissionState,
          message: 'নোটিফিকেশনের অনুমতি দেয়া হয়নি।'
        };
      }
    } catch (err) {
      console.warn('Notification.requestPermission error (might be inside iframe):', err);
      // In iframes or restricted environments, enable in-app fallback
      updateConfig({ enabled: true });
      return {
        success: true,
        permission: 'default' as NotificationPermissionState,
        message: 'ইন-অ্যাপ রিমাইন্ডার সক্রিয় হয়েছে। ব্রাউজার প্রিভিউ আইফ্রেমের জন্য ফুল স্ক্রিন বা PWA তে সিস্টেম নোটিফিকেশন কাজ করবে।'
      };
    }
  }, [updateConfig]);

  // Disable daily notifications
  const disableNotifications = useCallback(() => {
    updateConfig({ enabled: false });
  }, [updateConfig]);

  // Toggle notification on / off
  const toggleNotifications = useCallback(async () => {
    if (config.enabled) {
      disableNotifications();
      return { success: true, enabled: false, message: 'দৈনিক সামারি নোটিফিকেশন বন্ধ করা হয়েছে।' };
    } else {
      const res = await enableNotifications();
      return { success: res.success, enabled: res.permission === 'granted' || res.success, message: res.message };
    }
  }, [config.enabled, disableNotifications, enableNotifications]);

  // Fire a test notification immediately
  const sendTestNotification = useCallback(async () => {
    setIsTesting(true);
    try {
      // If permission is not granted yet, ask for it
      if (permission !== 'granted' && typeof window !== 'undefined' && 'Notification' in window) {
        const req = await enableNotifications();
        if (!req.success && req.permission === 'denied') {
          setIsTesting(false);
          return { success: false, message: req.message };
        }
      }

      const title = '📊 মেমো কাউন্টার — টেস্ট নোটিফিকেশন';
      const options: NotificationOptions & { vibrate?: number[] } = {
        body: 'আপনার PWA ডিভাইসে দৈনিক সামারি নোটিফিকেশন চমৎকারভাবে কাজ করছে! দিনশেষে এই রিমাইন্ডার দেখে PDF ও CSV রিপোর্ট সংরক্ষণ করতে পারবেন।',
        icon: '/pwa-192x192.png',
        badge: '/pwa-192x192.png',
        tag: 'daily-summary-test',
        vibrate: [200, 100, 200],
        silent: false,
      };

      const sent = await dispatchNotification(title, options as NotificationOptions);
      setIsTesting(false);

      if (sent) {
        return {
          success: true,
          message: 'টেস্ট নোটিফিকেশন সফলভাবে পাঠানো হয়েছে! ডিভাইসের নোটিফিকেশন বার চেক করুন।'
        };
      } else {
        // Fallback in-app preview
        setInAppReminderDue(true);
        return {
          success: true,
          message: 'নোটিফিকেশন পাঠানো হয়েছে (প্রিভিউ আইফ্রেম বা ব্রাউজারে ইন-অ্যাপ নোটিফিকেশন দেখানো হচ্ছে)।'
        };
      }
    } catch (err) {
      setIsTesting(false);
      console.error('Error sending test notification:', err);
      return {
        success: false,
        message: 'নোটিফিকেশন পাঠাতে সমস্যা হয়েছে। দয়া করে ব্রাউজার সেটিংস চেক করুন।'
      };
    }
  }, [permission, enableNotifications, dispatchNotification]);

  // Periodic check for daily reminder (runs every 30 seconds)
  useEffect(() => {
    if (!config.enabled) return;

    const checkReminder = async () => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = String(now.getMonth() + 1).padStart(2, '0');
      const currentDay = String(now.getDate()).padStart(2, '0');
      const todayStr = `${currentYear}-${currentMonth}-${currentDay}`;

      // If already reminded today, skip
      if (config.lastNotifiedDate === todayStr) {
        return;
      }

      const currentHours = String(now.getHours()).padStart(2, '0');
      const currentMinutes = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentHours}:${currentMinutes}`;

      // Check if current time has reached or passed scheduled reminderTime
      if (currentTimeStr >= config.reminderTime) {
        // Trigger notification!
        const title = '📊 মেমো কাউন্টার — দৈনিক রিপোর্ট রিমাইন্ডার';
        const options: NotificationOptions & { vibrate?: number[] } = {
          body: `আজকের (${todayStr}) মেমো ও বিক্রয় হিসাব সম্পন্ন হয়েছে? এখনই PDF এবং Excel/CSV রিপোর্ট ডাউনলোড করে সুরক্ষিত রাখুন।`,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
          tag: 'daily-summary-scheduled-reminder',
          vibrate: [300, 150, 300],
          requireInteraction: true,
        };

        await dispatchNotification(title, options as NotificationOptions);

        // Also trigger in-app reminder banner/event
        setInAppReminderDue(true);
        if (onTriggerReminder) {
          onTriggerReminder();
        }

        // Mark today as notified
        updateConfig({ lastNotifiedDate: todayStr });
      }
    };

    // Run check immediately on mount/update
    checkReminder();

    // Check every 30 seconds
    const interval = setInterval(checkReminder, 30000);
    return () => clearInterval(interval);
  }, [config.enabled, config.reminderTime, config.lastNotifiedDate, dispatchNotification, onTriggerReminder, updateConfig]);

  const dismissInAppReminder = useCallback(() => {
    setInAppReminderDue(false);
  }, []);

  return {
    config,
    permission,
    isTesting,
    inAppReminderDue,
    updateReminderTime: (time: string) => updateConfig({ reminderTime: time }),
    toggleNotifications,
    enableNotifications,
    disableNotifications,
    sendTestNotification,
    dismissInAppReminder,
  };
}
