// Smart matching algorithm to map uploaded files to products by Name, Number, and Keywords

import { Product } from '../data/products';

export interface FileMatchResult {
  file: File;
  previewUrl: string;
  matchedProductId: number;
  matchedProductName: string;
  confidence: 'high' | 'medium' | 'sequential';
  matchReason: string;
}

// Convert Bengali digits to English digits
export function convertBnToEnDigits(str: string): string {
  const bn = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let res = str;
  for (let i = 0; i < 10; i++) {
    res = res.replaceAll(bn[i], i.toString());
  }
  return res;
}

// Normalize strings for fuzzy matching
export function normalizeText(str: string): string {
  return convertBnToEnDigits(str.toLowerCase())
    .replace(/[._\-–—()\[\]]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Keyword dictionary for each default product
 */
export const PRODUCT_KEYWORDS: Record<number, string[]> = {
  // Drinks & Ice
  0: ['আইচবার', 'আইসবার ১২', 'icebar 12', 'ice bar 12', '12'],
  1: ['আইসবার ৪৫', 'আইচবার ৪৫', 'icebar 45', 'ice bar 45'],
  2: ['সিপ স্টার', 'সিপস্টার', 'sip star', 'sipstar', 'star'],
  3: ['সিপ জেলি', 'সিপজেলি', 'sip jelly', 'sipjelly', 'jelly'],
  4: ['পিং পং ৪৫', 'পিংপং ৪৫', 'ping pong 45', 'pingpong 45'],
  5: ['পিংপং কালার', 'পিং পং কালার', 'ping pong color', 'pingpong color'],
  6: ['আইচপপ', 'আইসপপ', 'ice pop', 'icepop', 'pop'],

  // Edible Gel & Pudding
  7: ['পুডিং', 'pudding', 'creme caramel'],
  8: ['লিচু ৪৫', 'lichu 45', 'lychee 45', 'lichu'],
  9: ['লিচু পলি', 'lichu poly', 'lychee poly', 'poly'],

  // Chocolate
  10: ['চকোলেড ০৫', 'চকলেট ০৫', 'চকোলেট ০৫', 'choc 05', 'choc 5', 'chocolate 5', 'choc05'],
  11: ['চকোলেড ২৪', 'চকলেট ২৪', 'চকোলেট ২৪', 'choc 24', 'chocolate 24', 'choc24'],
  12: ['চকোলেড ০০', 'চকলেট ০০', 'চকোলেট ০০', 'choc 00', 'chocolate 00', 'choc00', 'black'],
  13: ['মিক্স বার', 'মিক্সবার', 'mix bar', 'mixbar'],
  14: ['লাভ বক্স', 'লাভবক্স', 'love box', 'lovebox', 'heart'],
  15: ['চকোলেড ১৬', 'চকলেট ১৬', 'choc 16', 'chocolate 16'],
  16: ['কেরামেল বক্স', 'ক্যারামেল', 'caramel box', 'caramel'],
  17: ['বেলজিও কফি', 'belgio coffee', 'coffee'],
  18: ['বেলজিও মিক্স', 'belgio mix', 'belgio'],
  19: ['বেলজিও স্ট্রবেরি', 'বেলজিও স্টবেরি', 'belgio strawberry', 'strawberry'],
  20: ['জুম ০৫', 'জুম ৫', 'zoom 05', 'zoom 5'],
  21: ['জুম ১০', 'zoom 10'],

  // Sauce
  22: ['১৬০ সস', '১৬০সস', '160 sauce', '160 sos', '160', '১৬০'],
  23: ['২৫০ সস', '২৫০সস', '250 sauce', '250 sos', '250', '২৫০'],
  24: ['৫০০ সস', '৫০০সস', '500 sauce', '500 sos', '500', '৫০০'],
  25: ['০১ কেজি সস', '১ কেজি সস', '1 kg sauce', '1kg sauce', '1kg sos', '1 kg sos', '1kg', '০১ কেজি', '১ কেজি'],
  26: ['০২ কেজি সস', '২ কেজি সস', '2 kg sauce', '2kg sauce', '2kg sos', '2 kg sos', '2kg', '০২ কেজি', '২ কেজি'],
  27: ['৫ কেজি সস', '০৫ কেজি সস', '5 kg sauce', '5kg sauce', '5kg sos', '5 kg sos', '5kg', '৫ কেজি'],
  28: ['পাতা সস', 'পাতাসস', 'pata sauce', 'pata sos', 'leaf sauce', 'pata'],
  29: ['নাগা চিলি সস', 'নাগা মরিচ', 'নাগা সস', 'naga chili', 'naga sauce', 'naga sos', 'naga'],

  // Chutney & Pickle
  30: ['প্রাণ চাটনি', 'চাটনি', 'pran chatni', 'chatni', 'chutney'],
  31: ['জলপাই', 'জলপাই আচার', 'jolpai', 'olive pickle', 'olive'],
  32: ['আম ভাগ আচার', 'আম ভাগ', 'আমের আচার', 'am vag', 'aam vag', 'mango pickle'],
  33: ['কালোজিরা', 'কালোজিরা আচার', 'kalojira', 'black seed'],

  // Toys & Gems
  34: ['জেমস ০৫', 'জেমস ৫', 'জেমস', 'gems 05', 'gems 5', 'gems'],
  35: ['ফিডার', 'baby feeder', 'feeder', 'milk bottle'],
  36: ['ডরিমেন', 'ডোরেমন', 'doremon', 'doraemon'],
  37: ['চশমা', 'সানগ্লাস', 'choshma', 'glasses', 'sunglasses'],

  // Snacks
  38: ['টোস্ট ১০', 'টোস্ট ১০ টাকা', 'toast 10', 'toast10'],
  39: ['টোস্ট বড়', 'বড় টোস্ট', 'toast boro', 'toast big', 'toast large'],
  40: ['চিড়া ভাজা', 'চিড়াভাজা', 'chira vaja', 'chira fry', 'chira'],

  // Semai
  41: ['লাচ্ছা সেমাই', 'লাচ্ছা', 'laccha semai', 'laccha', 'lachha'],
  42: ['বারমিসিলি সেমাই', 'বারমিসিলি', 'ভার্মিসিলি', 'vermicelli', 'vermiceli', 'semai']
};

/**
 * Match a file by filename to the best matching product
 */
export function matchFileToProduct(
  file: File,
  fileIndex: number,
  products: Product[],
  alreadyAssignedIds: Set<number>
): FileMatchResult {
  const previewUrl = URL.createObjectURL(file);
  const cleanName = normalizeText(file.name.replace(/\.[^/.]+$/, ''));

  // 1. Direct check against exact or partial product names
  for (const p of products) {
    const pNorm = normalizeText(p.name);
    if (cleanName.includes(pNorm) || pNorm.includes(cleanName)) {
      return {
        file,
        previewUrl,
        matchedProductId: p.id,
        matchedProductName: p.name,
        confidence: 'high',
        matchReason: `ফাইলের নামের সাথে হুবহু মিল (${p.name})`
      };
    }
  }

  // 2. Keyword & Alias matching
  for (const p of products) {
    const keywords = PRODUCT_KEYWORDS[p.id] || [];
    for (const kw of keywords) {
      const kwNorm = normalizeText(kw);
      if (cleanName.includes(kwNorm)) {
        return {
          file,
          previewUrl,
          matchedProductId: p.id,
          matchedProductName: p.name,
          confidence: 'high',
          matchReason: `কীওয়ার্ড "${kw}" এর সাথে মিলেছে (${p.name})`
        };
      }
    }
  }

  // 3. Number/Serial Match in filename (e.g. "product 22", "item_4", "04.jpg", "250.jpg")
  const numbersInFile = cleanName.match(/\d+/g);
  if (numbersInFile && numbersInFile.length > 0) {
    for (const numStr of numbersInFile) {
      const numVal = parseInt(numStr, 10);
      // Check if numVal is an item serial number 1..43
      if (numVal >= 1 && numVal <= products.length) {
        const targetProd = products[numVal - 1];
        if (targetProd && !alreadyAssignedIds.has(targetProd.id)) {
          return {
            file,
            previewUrl,
            matchedProductId: targetProd.id,
            matchedProductName: targetProd.name,
            confidence: 'medium',
            matchReason: `ক্রমিক নম্বর #${numVal} অনুযায়ী মিল (${targetProd.name})`
          };
        }
      }
    }
  }

  // 4. Sequential fallback matching
  // Pick the next unassigned product
  let fallbackProduct = products.find((p) => !alreadyAssignedIds.has(p.id));
  if (!fallbackProduct) {
    fallbackProduct = products[fileIndex % products.length];
  }

  return {
    file,
    previewUrl,
    matchedProductId: fallbackProduct.id,
    matchedProductName: fallbackProduct.name,
    confidence: 'sequential',
    matchReason: `ক্রমিক অনুযায়ী পণ্য #${fallbackProduct.id + 1} (${fallbackProduct.name})`
  };
}
