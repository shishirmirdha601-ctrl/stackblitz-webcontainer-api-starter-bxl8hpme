// Native Android / Web Share utility for Raju Daily Summary
// Allows instant 1-click sharing of backup JSON directly to Gmail, Google Drive app, Files, etc.
// Completely offline-friendly, zero OAuth tokens or verification required!

export async function shareOrDownloadBackup(
  payload: any,
  suggestedFilename?: string
): Promise<{ success: boolean; message: string }> {
  try {
    const jsonStr = typeof payload === 'string' ? payload : JSON.stringify(payload, null, 2);
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = suggestedFilename || `raju-daily-summary-backup-${dateStr}.json`;

    const blob = new Blob([jsonStr], { type: 'application/json' });
    const file = new File([blob], filename, { type: 'application/json' });

    // Try Web Share API with file (works natively on Android Chrome & modern mobile browsers)
    if (
      typeof navigator !== 'undefined' &&
      navigator.canShare &&
      navigator.canShare({ files: [file] })
    ) {
      try {
        await navigator.share({
          title: 'রাজু এন্টারপ্রাইজ ব্যাকআপ',
          text: `রাজু এন্টারপ্রাইজ দৈনিক হিসাব ও ছবির সম্পূর্ণ ব্যাকআপ ফাইল (${dateStr})`,
          files: [file]
        });
        return {
          success: true,
          message: 'সফলভাবে জিমেইল / গুগল ড্রাইভ / ফাইলে ব্যাকআপ পাঠানো হয়েছে!'
        };
      } catch (shareErr: any) {
        if (shareErr.name === 'AbortError') {
          return {
            success: false,
            message: 'শেয়ার উইন্ডো বাতিল করা হয়েছে।'
          };
        }
        console.warn('Web Share failed, falling back to direct download:', shareErr);
      }
    }

    // Fallback: Direct download to phone's Files / Downloads folder
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    return {
      success: true,
      message: 'ব্যাকআপ ফাইলটি সরাসরি আপনার ফোনের Files (Downloads) ফোল্ডারে সেভ হয়েছে!'
    };
  } catch (err: any) {
    console.error('Error in shareOrDownloadBackup:', err);
    return {
      success: false,
      message: `ব্যাকআপ নিতে সমস্যা হয়েছে: ${err.message || 'অজানা ত্রুটি'}`
    };
  }
}
