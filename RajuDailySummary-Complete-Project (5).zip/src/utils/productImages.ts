// Storage and compression utilities for Raju Daily Summary product images
// Includes IndexedDB persistent storage, localStorage backup, and 1-click export/restore

const STORAGE_KEY_PRODUCT_IMAGES = 'raju_product_images_v1';
const IDB_DB_NAME = 'raju_daily_summary_db';
const IDB_STORE_NAME = 'product_photos_store';
const IDB_VERSION = 1;

export type ProductImageMap = Record<number, string>;

let memoryCache: ProductImageMap | null = null;

/**
 * Requests persistent storage from browser so device never clears images/data
 */
export function requestPersistentStorage(): void {
  try {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
      navigator.storage.persist().then((isPersisted) => {
        if (isPersisted) {
          console.log('Browser persistent storage granted for Raju Daily Summary');
        }
      }).catch(() => {});
    }
  } catch {}
}

/**
 * Open IndexedDB helper
 */
function openImageDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(IDB_DB_NAME, IDB_VERSION);
    request.onupgradeneeded = (event: any) => {
      const db = event.target.result as IDBDatabase;
      if (!db.objectStoreNames.contains(IDB_STORE_NAME)) {
        db.createObjectStore(IDB_STORE_NAME);
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Loads images from IndexedDB asynchronously
 */
export async function loadImagesFromIndexedDB(): Promise<ProductImageMap | null> {
  try {
    const db = await openImageDB();
    return new Promise((resolve) => {
      const tx = db.transaction(IDB_STORE_NAME, 'readonly');
      const store = tx.objectStore(IDB_STORE_NAME);
      const req = store.get('all_product_photos');
      req.onsuccess = () => {
        if (req.result && typeof req.result === 'object') {
          resolve(req.result as ProductImageMap);
        } else {
          resolve(null);
        }
      };
      req.onerror = () => resolve(null);
    });
  } catch {
    return null;
  }
}

/**
 * Saves images to IndexedDB asynchronously
 */
export async function saveImagesToIndexedDB(images: ProductImageMap): Promise<void> {
  try {
    const db = await openImageDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(IDB_STORE_NAME, 'readwrite');
      const store = tx.objectStore(IDB_STORE_NAME);
      store.put(images, 'all_product_photos');
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (err) {
    console.warn('IndexedDB save failed, falling back to localStorage only:', err);
  }
}

/**
 * Loads all custom uploaded product images from localStorage.
 */
export function getStoredProductImages(): ProductImageMap {
  if (memoryCache !== null) {
    return { ...memoryCache };
  }
  try {
    const raw = localStorage.getItem(STORAGE_KEY_PRODUCT_IMAGES);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed === 'object' && parsed !== null) {
        memoryCache = parsed;
        return { ...parsed };
      }
    }
  } catch (err) {
    console.error('Failed to load stored product images:', err);
  }
  memoryCache = {};
  return {};
}

/**
 * Saves all product images to localStorage and IndexedDB.
 */
export function saveStoredProductImages(images: ProductImageMap): void {
  memoryCache = { ...images };
  try {
    localStorage.setItem(STORAGE_KEY_PRODUCT_IMAGES, JSON.stringify(images));
  } catch (err) {
    console.warn('Failed to save product images to localStorage:', err);
  }
  saveImagesToIndexedDB(images).catch(() => {});
}

/**
 * Saves a single product image by product ID.
 */
export function saveSingleProductImage(productId: number, base64Data: string): ProductImageMap {
  const current = getStoredProductImages();
  current[productId] = base64Data;
  saveStoredProductImages(current);
  return current;
}

/**
 * Removes a product image by product ID.
 */
export function removeProductImage(productId: number): ProductImageMap {
  const current = getStoredProductImages();
  delete current[productId];
  saveStoredProductImages(current);
  return current;
}

/**
 * 1-Click download of ALL product photos as a JSON file
 */
export function exportAllPhotosJSON(images: ProductImageMap, products?: any[]): void {
  const exportPayload = {
    type: 'raju_permanent_photos_backup',
    version: 2,
    appName: 'Raju Daily Summary',
    exportTimestamp: new Date().toISOString(),
    photoCount: Object.keys(images).length,
    images,
    productsSummary: products?.map(p => ({ id: p.id, name: p.name, hasPhoto: !!images[p.id] })) || []
  };

  const blob = new Blob([JSON.stringify(exportPayload, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const dateStr = new Date().toISOString().split('T')[0];
  a.download = `raju-product-photos-backup-${dateStr}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/**
 * Compresses an uploaded image File using HTML5 canvas to keep size small (~25-35KB).
 */
export function compressImageFile(
  file: File,
  maxWidth = 400,
  maxHeight = 400,
  quality = 0.82
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Canvas context not available'));
          return;
        }

        // Fill white background for transparent images
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Image failed to load'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('FileReader failed'));
    reader.readAsDataURL(file);
  });
}
