import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas-pro';
import { GROUP_RANGES, Product } from '../data/products';

export interface PDFReportData {
  currentDate: string;
  totalDayPieces: number;
  totalDayMoney: number;
  groupSummaries: {
    groupIdx: number;
    name?: string;
    pieces: number;
    amount: number;
    color?: string;
  }[];
  products: Product[];
  currentDayData: {
    sum: Record<number, number>;
    history: {
      id?: string;
      time: string;
      productName: string;
      quantity: number;
      productIndex: number;
      memoNumber?: number | string;
      note?: string;
    }[];
  };
  productFrequencyMap: Record<number, number>;
}

const GROUP_NAMES: Record<number, string> = {
  0: 'গ্রুপ ১ (আইচবার ও সিপ)',
  1: 'গ্রুপ ২ (পুডিং ও লিচু)',
  2: 'গ্রুপ ৩ (চকোলেড ও বেলজিও)',
  3: 'গ্রুপ ৪ (সস)',
  4: 'গ্রুপ ৫ (চাটনি ও আচার)',
  5: 'গ্রুপ ৬ (জেমস ও খেলনা)',
  6: 'গ্রুপ ৭ (টোস্ট ও চিড়া)',
  7: 'গ্রুপ ৮ (সেমাই)',
};

export async function generateDailySummaryPDF(
  data: PDFReportData,
  onProgress?: (status: string) => void
): Promise<void> {
  if (onProgress) onProgress('রিপোর্ট প্রস্তুত করা হচ্ছে...');

  const {
    currentDate = '',
    totalDayPieces = 0,
    totalDayMoney = 0,
    groupSummaries = [],
    products = [],
    currentDayData = { sum: {}, history: [] },
    productFrequencyMap = {},
  } = data || {};

  const history = Array.isArray(currentDayData?.history) ? currentDayData.history : [];
  const sum = currentDayData?.sum || {};

  // Calculate active products count
  const activeProducts = products.filter(
    (p, idx) => ((sum[p.id ?? idx]) || 0) > 0
  );

  // Format currency helper
  const fmtMoney = (val: number = 0) => (val || 0).toLocaleString('en-US');

  // Create temporary offscreen container for printable DOM
  const container = document.createElement('div');
  container.id = 'pdf-render-container';
  container.style.position = 'fixed';
  container.style.left = '0';
  container.style.top = '0';
  container.style.zIndex = '-99999';
  container.style.width = '800px';
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.fontFamily =
    'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Noto Sans Bengali", Kalpurush, sans-serif';
  container.style.padding = '32px 36px';
  container.style.boxSizing = 'border-box';
  container.style.lineHeight = '1.4';

  const generatedTime = new Date().toLocaleTimeString('bn-BD', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  // Build the complete, clean HTML layout
  container.innerHTML = `
    <div style="border-bottom: 2px solid #0f172a; padding-bottom: 16px; margin-bottom: 20px;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start;">
        <div>
          <h1 style="margin: 0; font-size: 24px; font-weight: 800; color: #0f172a; letter-spacing: -0.5px;">
            রাজু ডেইলি সামারি (Raju Daily Summary)
          </h1>
          <p style="margin: 4px 0 0 0; font-size: 13px; font-weight: 600; color: #475569;">
            মেমো কাউন্টার ও দৈনিক বিক্রয় হিস্ট্রি রিপোর্ট
          </p>
        </div>
        <div style="text-align: right;">
          <div style="display: inline-block; background-color: #f1f5f9; padding: 6px 12px; border-radius: 6px; border: 1px solid #cbd5e1;">
            <div style="font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase;">রিপোর্টের তারিখ</div>
            <div style="font-size: 15px; font-weight: 800; color: #0f172a;">${currentDate}</div>
          </div>
          <div style="font-size: 11px; color: #64748b; margin-top: 4px;">
            প্রিন্ট সময়: ${generatedTime}
          </div>
        </div>
      </div>
    </div>

    <!-- Summary Metrics Cards -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 24px;">
      <div style="background-color: #f8fafc; border: 1.5px solid #0284c7; border-radius: 8px; padding: 12px 14px;">
        <div style="font-size: 11px; font-weight: 700; color: #0369a1;">মোট বিক্রয় টাকা</div>
        <div style="font-size: 20px; font-weight: 800; color: #0f172a; margin-top: 2px;">
          ৳ ${fmtMoney(totalDayMoney)}
        </div>
      </div>

      <div style="background-color: #f8fafc; border: 1.5px solid #10b981; border-radius: 8px; padding: 12px 14px;">
        <div style="font-size: 11px; font-weight: 700; color: #047857;">মোট বিক্রিত পরিমাণ</div>
        <div style="font-size: 20px; font-weight: 800; color: #0f172a; margin-top: 2px;">
          ${fmtMoney(totalDayPieces)} <span style="font-size: 12px; font-weight: 600; color: #64748b;">পিস</span>
        </div>
      </div>

      <div style="background-color: #f8fafc; border: 1.5px solid #8b5cf6; border-radius: 8px; padding: 12px 14px;">
        <div style="font-size: 11px; font-weight: 700; color: #6d28d9;">মোট মেমো এন্ট্রি</div>
        <div style="font-size: 20px; font-weight: 800; color: #0f172a; margin-top: 2px;">
          ${history.length} <span style="font-size: 12px; font-weight: 600; color: #64748b;">বার</span>
        </div>
      </div>

      <div style="background-color: #f8fafc; border: 1.5px solid #f59e0b; border-radius: 8px; padding: 12px 14px;">
        <div style="font-size: 11px; font-weight: 700; color: #b45309;">বিক্রিত পণ্যের ধরন</div>
        <div style="font-size: 20px; font-weight: 800; color: #0f172a; margin-top: 2px;">
          ${activeProducts.length} <span style="font-size: 12px; font-weight: 600; color: #64748b;">/ ${products.length} টি</span>
        </div>
      </div>
    </div>

    <!-- Section 1: Group Summary -->
    <div style="margin-bottom: 24px; page-break-inside: avoid;">
      <h2 style="font-size: 14px; font-weight: 800; color: #0f172a; border-left: 4px solid #0284c7; padding-left: 8px; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 0.5px;">
        ১. গ্রুপভিত্তিক বিক্রয় সারসংক্ষেপ (Group Summary)
      </h2>
      <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
        <thead>
          <tr style="background-color: #0f172a; color: #ffffff;">
            <th style="padding: 6px 8px; text-align: center; border: 1px solid #334155; width: 60px;">গ্রুপ</th>
            <th style="padding: 6px 10px; text-align: left; border: 1px solid #334155;">গ্রুপ নাম ও রেঞ্জ</th>
            <th style="padding: 6px 10px; text-align: right; border: 1px solid #334155; width: 120px;">মোট পরিমাণ (পিস)</th>
            <th style="padding: 6px 10px; text-align: right; border: 1px solid #334155; width: 130px;">মোট মূল্য (টাকা)</th>
            <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 80px;">অংশ (%)</th>
          </tr>
        </thead>
        <tbody>
          ${groupSummaries
            .map((g) => {
              const range = (GROUP_RANGES && GROUP_RANGES[g.groupIdx]) || [0, 0];
              const start = range[0] ?? 0;
              const end = range[1] ?? 0;
              const pct = totalDayMoney > 0 ? ((g.amount / totalDayMoney) * 100).toFixed(1) : '0.0';
              const groupLabel = GROUP_NAMES[g.groupIdx] || `গ্রুপ ${g.groupIdx + 1}`;
              const rangeLabel = end > start ? `(${start + 1} থেকে ${end} নং)` : '';

              return `
                <tr style="background-color: ${g.groupIdx % 2 === 0 ? '#f8fafc' : '#ffffff'};">
                  <td style="padding: 6px 8px; text-align: center; border: 1px solid #e2e8f0; font-weight: 700;">
                    গ্রুপ ${g.groupIdx + 1}
                  </td>
                  <td style="padding: 6px 10px; border: 1px solid #e2e8f0;">
                    ${groupLabel} ${rangeLabel}
                  </td>
                  <td style="padding: 6px 10px; text-align: right; border: 1px solid #e2e8f0; font-weight: 600;">
                    ${fmtMoney(g.pieces)} pcs
                  </td>
                  <td style="padding: 6px 10px; text-align: right; border: 1px solid #e2e8f0; font-weight: 700;">
                    ৳ ${fmtMoney(g.amount)}
                  </td>
                  <td style="padding: 6px 8px; text-align: right; border: 1px solid #e2e8f0; color: #475569; font-size: 11px;">
                    ${pct}%
                  </td>
                </tr>
              `;
            })
            .join('')}
          <tr style="background-color: #f1f5f9; font-weight: 800; border-top: 2px solid #0f172a;">
            <td colspan="2" style="padding: 8px 10px; text-align: left; border: 1px solid #cbd5e1;">
              সর্বমোট (সকল গ্রুপ মিলিয়ে)
            </td>
            <td style="padding: 8px 10px; text-align: right; border: 1px solid #cbd5e1; color: #0369a1;">
              ${fmtMoney(totalDayPieces)} pcs
            </td>
            <td style="padding: 8px 10px; text-align: right; border: 1px solid #cbd5e1; color: #047857;">
              ৳ ${fmtMoney(totalDayMoney)}
            </td>
            <td style="padding: 8px 8px; text-align: right; border: 1px solid #cbd5e1;">
              100%
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Section 2: Product Sales Breakdown -->
    <div style="margin-bottom: 24px;">
      <h2 style="font-size: 14px; font-weight: 800; color: #0f172a; border-left: 4px solid #10b981; padding-left: 8px; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 0.5px;">
        ২. পণ্যভিত্তিক বিক্রয় বিবরণী (Product Sales Breakdown)
      </h2>
      <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
        <thead>
          <tr style="background-color: #0f172a; color: #ffffff;">
            <th style="padding: 6px 6px; text-align: center; border: 1px solid #334155; width: 36px;">নং</th>
            <th style="padding: 6px 10px; text-align: left; border: 1px solid #334155;">পণ্যের নাম</th>
            <th style="padding: 6px 8px; text-align: center; border: 1px solid #334155; width: 65px;">গ্রুপ</th>
            <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 75px;">একক দর</th>
            <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 85px;">পরিমাণ (পিস)</th>
            <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 95px;">মোট মূল্য (টাকা)</th>
            <th style="padding: 6px 6px; text-align: center; border: 1px solid #334155; width: 60px;">যোগ বার</th>
          </tr>
        </thead>
        <tbody>
          ${products
            .map((prod, idx) => {
              const qty = sum[prod.id ?? idx] || 0;
              const freq = productFrequencyMap[prod.id ?? idx] || 0;
              const hasSales = qty > 0;
              return `
                <tr style="background-color: ${
                  hasSales ? (idx % 2 === 0 ? '#f0fdf4' : '#f8fafc') : (idx % 2 === 0 ? '#fafafa' : '#ffffff')
                }; color: ${hasSales ? '#0f172a' : '#94a3b8'};">
                  <td style="padding: 5px 6px; text-align: center; border: 1px solid #e2e8f0; font-weight: 600;">
                    ${idx + 1}
                  </td>
                  <td style="padding: 5px 10px; border: 1px solid #e2e8f0; font-weight: ${hasSales ? '700' : '400'};">
                    ${prod.name}
                  </td>
                  <td style="padding: 5px 8px; text-align: center; border: 1px solid #e2e8f0; font-size: 10px;">
                    গ্রুপ ${(prod.groupIndex ?? 0) + 1}
                  </td>
                  <td style="padding: 5px 8px; text-align: right; border: 1px solid #e2e8f0;">
                    ৳ ${prod.price}
                  </td>
                  <td style="padding: 5px 8px; text-align: right; border: 1px solid #e2e8f0; font-weight: ${hasSales ? '700' : '400'};">
                    ${qty > 0 ? `${fmtMoney(qty)} pcs` : '-'}
                  </td>
                  <td style="padding: 5px 8px; text-align: right; border: 1px solid #e2e8f0; font-weight: ${hasSales ? '800' : '400'}; color: ${hasSales ? '#047857' : '#94a3b8'};">
                    ${qty > 0 ? `৳ ${fmtMoney(qty * prod.price)}` : '-'}
                  </td>
                  <td style="padding: 5px 6px; text-align: center; border: 1px solid #e2e8f0; font-size: 10px;">
                    ${freq > 0 ? `${freq} বার` : '-'}
                  </td>
                </tr>
              `;
            })
            .join('')}
          <tr style="background-color: #f1f5f9; font-weight: 800; border-top: 2px solid #0f172a;">
            <td colspan="4" style="padding: 7px 10px; text-align: left; border: 1px solid #cbd5e1;">
              মোট পণ্য তালিকা সমাপনী (${products.length}টি পণ্য)
            </td>
            <td style="padding: 7px 8px; text-align: right; border: 1px solid #cbd5e1; color: #0369a1;">
              ${fmtMoney(totalDayPieces)} pcs
            </td>
            <td style="padding: 7px 8px; text-align: right; border: 1px solid #cbd5e1; color: #047857;">
              ৳ ${fmtMoney(totalDayMoney)}
            </td>
            <td style="padding: 7px 6px; text-align: center; border: 1px solid #cbd5e1;">
              -
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Section 3: Detailed Memo Transactions -->
    <div style="margin-bottom: 24px;">
      <h2 style="font-size: 14px; font-weight: 800; color: #0f172a; border-left: 4px solid #8b5cf6; padding-left: 8px; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 0.5px;">
        ৩. বিস্তারিত মেমো হিস্ট্রি (Detailed Memo Transactions Log)
      </h2>
      ${
        history.length === 0
          ? `
            <div style="background-color: #f8fafc; border: 1px dashed #cbd5e1; padding: 16px; text-align: center; color: #64748b; border-radius: 6px; font-size: 12px;">
              আজকের তারিখে এখনো কোনো মেমো ট্রানজ্যাকশন যোগ করা হয়নি।
            </div>
          `
          : `
            <table style="width: 100%; border-collapse: collapse; font-size: 11px;">
              <thead>
                <tr style="background-color: #0f172a; color: #ffffff;">
                  <th style="padding: 6px 6px; text-align: center; border: 1px solid #334155; width: 36px;">নং</th>
                  <th style="padding: 6px 8px; text-align: center; border: 1px solid #334155; width: 75px;">সময়</th>
                  <th style="padding: 6px 8px; text-align: center; border: 1px solid #334155; width: 70px;">মেমো নং</th>
                  <th style="padding: 6px 10px; text-align: left; border: 1px solid #334155;">পণ্যের নাম</th>
                  <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 85px;">পরিমাণ (পিস)</th>
                  <th style="padding: 6px 8px; text-align: right; border: 1px solid #334155; width: 80px;">একক দর</th>
                  <th style="padding: 6px 10px; text-align: right; border: 1px solid #334155; width: 95px;">মোট টাকা</th>
                </tr>
              </thead>
              <tbody>
                ${history
                  .map((item, index) => {
                    const unitPrice = products[item.productIndex]?.price || 0;
                    const itemTotal = (item.quantity || 0) * unitPrice;
                    const memoBadge = item.memoNumber || item.note || index + 1;
                    return `
                      <tr style="background-color: ${index % 2 === 0 ? '#f8fafc' : '#ffffff'};">
                        <td style="padding: 5px 6px; text-align: center; border: 1px solid #e2e8f0; font-weight: 600;">
                          ${index + 1}
                        </td>
                        <td style="padding: 5px 8px; text-align: center; border: 1px solid #e2e8f0; color: #475569;">
                          ${item.time}
                        </td>
                        <td style="padding: 5px 8px; text-align: center; border: 1px solid #e2e8f0; font-weight: 700; color: #d97706;">
                          #${memoBadge}
                        </td>
                        <td style="padding: 5px 10px; border: 1px solid #e2e8f0; font-weight: 600;">
                          ${item.productName}
                        </td>
                        <td style="padding: 5px 8px; text-align: right; border: 1px solid #e2e8f0; font-weight: 700;">
                          ${fmtMoney(item.quantity)} pcs
                        </td>
                        <td style="padding: 5px 8px; text-align: right; border: 1px solid #e2e8f0; color: #64748b;">
                          ৳ ${unitPrice}
                        </td>
                        <td style="padding: 5px 10px; text-align: right; border: 1px solid #e2e8f0; font-weight: 700; color: #047857;">
                          ৳ ${fmtMoney(itemTotal)}
                        </td>
                      </tr>
                    `;
                  })
                  .join('')}
              </tbody>
            </table>
          `
      }
    </div>

    <!-- Signatures & Authentication -->
    <div style="margin-top: 36px; padding-top: 20px; border-top: 1px dashed #94a3b8; display: flex; justify-content: space-between; align-items: flex-end; font-size: 11px; color: #475569;">
      <div>
        <div style="font-weight: 700; color: #0f172a;">রিপোর্ট প্রস্তুতকারী</div>
        <div style="margin-top: 24px; border-top: 1px solid #94a3b8; width: 140px; text-align: center; padding-top: 4px;">
          স্বাক্ষর ও তারিখ
        </div>
      </div>

      <div style="text-align: center; font-size: 10px; color: #64748b;">
        <div>Raju Daily Summary System — অফলাইন ও নিরাপদ হিসাব ব্যবস্থাপনা</div>
        <div>স্বয়ংক্রিয় ব্রাউজার-জেনারেটেড পিডিএফ রিপোর্ট</div>
      </div>

      <div>
        <div style="font-weight: 700; color: #0f172a; text-align: right;">যাচাইকারী / ম্যানেজার</div>
        <div style="margin-top: 24px; border-top: 1px solid #94a3b8; width: 140px; text-align: center; padding-top: 4px;">
          অনুমোদন স্বাক্ষর
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    if (onProgress) onProgress('পিডিএফ রেন্ডার হচ্ছে...');

    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: 800,
    });

    if (onProgress) onProgress('পিডিএফ পেজ সাজানো হচ্ছে...');

    const imgData = canvas.toDataURL('image/jpeg', 0.96);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pdfWidth = pdf.internal.pageSize.getWidth(); // 210 mm
    const pdfPageHeight = pdf.internal.pageSize.getHeight(); // 297 mm
    const imgHeight = (canvas.height * pdfWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    // First page
    pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight);
    heightLeft -= pdfPageHeight;

    // Remaining pages if content spans across multiple pages
    while (heightLeft > 0) {
      position = -(imgHeight - heightLeft);
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, pdfWidth, imgHeight);
      heightLeft -= pdfPageHeight;
    }

    if (onProgress) onProgress('ডাউনলোড সম্পন্ন হচ্ছে...');
    pdf.save(`RajuDailySummary-Report-${currentDate || 'today'}.pdf`);
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}
