export interface HistoryEntry {
  id: string;
  date: string;
  time: string;
  productIndex: number;
  productName: string;
  quantity: number;
  amount: number;
  note?: string;
}

export interface UnlistedItem {
  id: string;
  name: string;
  quantity: number;
  price: number;
  note?: string;
  timestamp: string;
}

export interface DayData {
  sum: number[]; // cumulative quantities for each of the products
  history: HistoryEntry[];
  unlistedItems?: UnlistedItem[]; // Items not in the main 43 product list (Others)
}

export interface AppStorageData {
  [date: string]: DayData;
}
