package com.raju.dailysummary

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.gson.Gson
import com.raju.dailysummary.data.ProductCatalog
import com.raju.dailysummary.model.BackupRoot
import com.raju.dailysummary.model.DayData
import com.raju.dailysummary.model.HistoryEntry
import com.raju.dailysummary.model.Product
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RajuDailySummaryApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RajuDailySummaryApp() {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("raju_daily_summary_prefs", Context.MODE_PRIVATE) }
    val gson = remember { Gson() }

    val dateFormat = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    var currentDate by remember { mutableStateOf(dateFormat.format(Date())) }

    // App state
    var dataMap by remember { mutableStateOf<Map<String, DayData>>(emptyMap()) }
    var globalHistory by remember { mutableStateOf<List<HistoryEntry>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Dashboard/Products, 1: History

    // Load initial state from SharedPreferences
    LaunchedEffect(Unit) {
        val savedData = sharedPrefs.getString("app_data_json", null)
        val savedGlobal = sharedPrefs.getString("global_history_json", null)
        if (!savedData.isNullOrEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<Map<String, DayData>>() {}.type
                dataMap = gson.fromJson(savedData, type) ?: emptyMap()
            } catch (_: Exception) {}
        }
        if (!savedGlobal.isNullOrEmpty()) {
            try {
                val type = object : com.google.gson.reflect.TypeToken<List<HistoryEntry>>() {}.type
                globalHistory = gson.fromJson(savedGlobal, type) ?: emptyList()
            } catch (_: Exception) {}
        }
    }

    // Auto-save to SharedPreferences
    fun saveDataToDisk(newData: Map<String, DayData>, newGlobal: List<HistoryEntry>) {
        dataMap = newData
        globalHistory = newGlobal
        sharedPrefs.edit()
            .putString("app_data_json", gson.toJson(newData))
            .putString("global_history_json", gson.toJson(newGlobal))
            .apply()
    }

    val currentDayData = dataMap[currentDate] ?: DayData(
        sum = List(ProductCatalog.items.size) { 0 },
        history = emptyList()
    )

    // Export Launcher (Android System File Picker for saving JSON)
    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                    val writer = OutputStreamWriter(outputStream)
                    val backup = BackupRoot(
                        version = 1,
                        appName = "Raju Daily Summary",
                        exportDate = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).format(Date()),
                        data = dataMap,
                        globalHistory = globalHistory
                    )
                    writer.write(gson.toJson(backup))
                    writer.flush()
                }
                Toast.makeText(context, "ব্যাকআপ ফাইল সফলভাবে সেভ হয়েছে!", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(context, "সেভ করতে সমস্যা: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Import Launcher (Android System File Picker for selecting JSON)
    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    val reader = BufferedReader(InputStreamReader(inputStream))
                    val backup = gson.fromJson(reader, BackupRoot::class.java)
                    if (backup != null && backup.data.isNotEmpty()) {
                        saveDataToDisk(backup.data, backup.globalHistory)
                        Toast.makeText(context, "ব্যাকআপ রিস্টোর সফল হয়েছে! (${backup.data.size} দিনের ডাটা)", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "ফাইলে কোনো ডাটা পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "ইমপোর্ট ব্যর্থ হয়েছে: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // Add entry logic
    fun addEntry(product: Product, quantity: Int, memo: String) {
        if (quantity <= 0) {
            Toast.makeText(context, "সঠিক Quantity দিন", Toast.LENGTH_SHORT).show()
            return
        }

        val newSumList = currentDayData.sum.toMutableList()
        while (newSumList.size < ProductCatalog.items.size) {
            newSumList.add(0)
        }
        newSumList[product.id] = (newSumList.getOrElse(product.id) { 0 }) + quantity

        val entry = HistoryEntry(
            id = "${System.currentTimeMillis()}-${product.id}",
            date = currentDate,
            time = timeFormat.format(Date()),
            productIndex = product.id,
            productName = product.name,
            quantity = quantity,
            amount = quantity * product.price,
            note = memo.ifBlank { null }
        )

        val updatedDayData = DayData(
            sum = newSumList,
            history = listOf(entry) + currentDayData.history
        )

        val updatedMap = dataMap.toMutableMap()
        updatedMap[currentDate] = updatedDayData

        saveDataToDisk(updatedMap, listOf(entry) + globalHistory)
        Toast.makeText(context, "${product.name} যোগ হয়েছে: $quantity পিস", Toast.LENGTH_SHORT).show()
    }

    // Delete history entry logic
    fun deleteHistoryEntry(entry: HistoryEntry) {
        val updatedHistory = currentDayData.history.filter { it.id != entry.id }
        val newSumList = currentDayData.sum.toMutableList()
        if (entry.productIndex in newSumList.indices) {
            newSumList[entry.productIndex] = maxOf(0, newSumList[entry.productIndex] - entry.quantity)
        }

        val updatedDayData = DayData(
            sum = newSumList,
            history = updatedHistory
        )

        val updatedMap = dataMap.toMutableMap()
        updatedMap[currentDate] = updatedDayData

        saveDataToDisk(updatedMap, globalHistory.filter { it.id != entry.id })
        Toast.makeText(context, "এন্ট্রি মুছে ফেলা হয়েছে", Toast.LENGTH_SHORT).show()
    }

    val totalPieces = currentDayData.sum.sum()
    val totalAmount = currentDayData.sum.mapIndexed { idx, qty ->
        val price = ProductCatalog.items.getOrNull(idx)?.price ?: 0
        qty * price
    }.sum()

    // Simple Memo Counter: Total Memos & Total Items across all saved memos (No money/sales calculation)
    val memoStats = remember(currentDayData.history) {
        val memoMap = mutableMapOf<String, Int>()
        currentDayData.history.forEach { entry ->
            val note = entry.note?.trim() ?: ""
            val key = if (note.isNotEmpty()) "note_${note.lowercase(Locale.getDefault())}" else "id_${entry.id}"
            memoMap[key] = (memoMap[key] ?: 0) + entry.quantity
        }
        val count = memoMap.size
        val items = memoMap.values.sum()
        Pair(count, items)
    }
    val totalMemos = memoStats.first
    val totalItems = memoStats.second

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Raju Daily Summary",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                        Text(
                            text = "অফলাইন দৈনিক হিসাব • তারিখ: $currentDate",
                            fontSize = 11.sp,
                            color = Color(0xFFFBBF24)
                        )
                    }
                },
                actions = {
                    TextButton(onClick = { importLauncher.launch(arrayOf("application/json", "*/*")) }) {
                        Text("ইমপোর্ট", color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = { exportLauncher.launch("raju-daily-summary-backup-$currentDate.json") }) {
                        Text("এক্সপোর্ট", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A)
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0F172A)) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    label = { Text("ড্যাশবোর্ড ও পণ্য", color = if (selectedTab == 0) Color(0xFFFBBF24) else Color.Gray) },
                    icon = { Text("📊") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    label = { Text("মেমো হিস্ট্রি (${currentDayData.history.size})", color = if (selectedTab == 1) Color(0xFFFBBF24) else Color.Gray) },
                    icon = { Text("📋") }
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFFF1F5F9))
        ) {
            // Dashboard Summary Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("মোট বিক্রিত পরিমাণ", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        Text("$totalPieces পিস", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("মোট বিক্রয় মূল্য", fontSize = 12.sp, color = Color(0xFF94A3B8))
                        Text("৳ $totalAmount", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color(0xFF38BDF8))
                    }
                }
            }

            // Simple Memo Counter Card (No money/sales amount calculation)
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "📋 Memo Counter (মেমো কাউন্টার)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Memos", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            Text("$totalMemos", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF0F172A))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total Items", fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                            Text("$totalItems Pcs", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color(0xFF2563EB))
                        }
                    }
                }
            }

            if (selectedTab == 0) {
                // Products list & Entry addition
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    placeholder = { Text("পণ্য খুঁজুন...") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )

                val filteredProducts = remember(searchQuery) {
                    if (searchQuery.isBlank()) ProductCatalog.items
                    else ProductCatalog.items.filter { it.name.contains(searchQuery, ignoreCase = true) }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filteredProducts) { product ->
                        ProductItemCard(
                            product = product,
                            currentSum = currentDayData.sum.getOrElse(product.id) { 0 },
                            onAdd = { qty, memo -> addEntry(product, qty, memo) }
                        )
                    }
                }
            } else {
                // History Tab
                if (currentDayData.history.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("আজকের দিনে কোনো হিস্ট্রি পাওয়া যায়নি", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(currentDayData.history) { entry ->
                            HistoryCard(entry = entry, onDelete = { deleteHistoryEntry(entry) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductItemCard(
    product: Product,
    currentSum: Int,
    onAdd: (Int, String) -> Unit
) {
    var qtyText by remember { mutableStateOf("") }
    var memoText by remember { mutableStateOf("") }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = product.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(text = "একক দর: ৳${product.price}", fontSize = 12.sp, color = Color.Gray)
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFEF3C7)
                ) {
                    Text(
                        text = "মোট: $currentSum",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB45309),
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = qtyText,
                    onValueChange = { qtyText = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )

                OutlinedTextField(
                    value = memoText,
                    onValueChange = { memoText = it },
                    modifier = Modifier.weight(1.5f),
                    placeholder = { Text("মেমো / নোট") },
                    singleLine = true,
                    shape = RoundedCornerShape(8.dp)
                )

                Button(
                    onClick = {
                        val qty = qtyText.toIntOrNull() ?: 0
                        if (qty > 0) {
                            onAdd(qty, memoText)
                            qtyText = ""
                            memoText = ""
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F172A))
                ) {
                    Text("যোগ", color = Color(0xFFFBBF24), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun HistoryCard(entry: HistoryEntry, onDelete: () -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = entry.productName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(
                    text = "${entry.time} • পরিমাণ: ${entry.quantity} পিস • মোট: ৳${entry.amount}",
                    fontSize = 12.sp,
                    color = Color.DarkGray
                )
                if (!entry.note.isNullOrBlank()) {
                    Text(text = "নোট: ${entry.note}", fontSize = 11.sp, color = Color(0xFF0284C7))
                }
            }
            TextButton(onClick = onDelete) {
                Text("মুছুন", color = Color.Red, fontSize = 12.sp)
            }
        }
    }
}
