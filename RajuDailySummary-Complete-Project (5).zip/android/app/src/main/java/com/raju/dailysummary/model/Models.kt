package com.raju.dailysummary.model

import com.google.gson.annotations.SerializedName

data class Product(
    val id: Int,
    val name: String,
    val price: Int,
    val groupIndex: Int
)

data class HistoryEntry(
    @SerializedName("id") val id: String = "",
    @SerializedName("date") val date: String = "",
    @SerializedName("time") val time: String = "",
    @SerializedName("productIndex") val productIndex: Int = 0,
    @SerializedName("productName") val productName: String = "",
    @SerializedName("quantity") val quantity: Int = 0,
    @SerializedName("amount") val amount: Int = 0,
    @SerializedName("note") val note: String? = null
)

data class DayData(
    @SerializedName("sum") val sum: List<Int> = emptyList(),
    @SerializedName("history") val history: List<HistoryEntry> = emptyList()
)

data class BackupRoot(
    @SerializedName("version") val version: Int = 1,
    @SerializedName("appName") val appName: String = "Raju Daily Summary",
    @SerializedName("exportDate") val exportDate: String = "",
    @SerializedName("data") val data: Map<String, DayData> = emptyMap(),
    @SerializedName("globalHistory") val globalHistory: List<HistoryEntry> = emptyList()
)
