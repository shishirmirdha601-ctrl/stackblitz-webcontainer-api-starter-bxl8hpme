package com.raju.dailysummary.data

import com.raju.dailysummary.model.Product

object ProductCatalog {
    val items: List<Product> = listOf(
        // Group 1
        Product(0, "আইচবার ১২", 42, 0),
        Product(1, "আইসবার ৪৫", 163, 0),
        Product(2, "সিপ স্টার", 192, 0),
        Product(3, "সিপ জেলি", 80, 0),
        Product(4, "পিং পং ৪৫", 180, 0),
        Product(5, "পিংপং কালার", 180, 0),
        Product(6, "আইচপপ", 8, 0),

        // Group 2
        Product(7, "পুডিং", 207, 1),
        Product(8, "লিচু ৪৫", 180, 1),
        Product(9, "লিচু পলি", 45, 1),

        // Group 3
        Product(10, "চকোলেড ০৫", 250, 2),
        Product(11, "চকোলেড ২৪", 192, 2),
        Product(12, "চকোলেড ০০", 250, 2),
        Product(13, "মিক্স বার", 160, 2),
        Product(14, "লাভ বক্স", 163, 2),
        Product(15, "চকোলেড ১৬", 183, 2),
        Product(16, "কেরামেল বক্স", 80, 2),
        Product(17, "বেলজিও কফি", 90, 2),
        Product(18, "বেলজিও মিক্স", 90, 2),
        Product(19, "বেলজিও স্ট্রবেরি", 90, 2),
        Product(20, "জুম ০৫", 120, 2),
        Product(21, "জুম ১০", 192, 2),

        // Group 4
        Product(22, "১৬০ সস", 55, 3),
        Product(23, "২৫০ সস", 77, 3),
        Product(24, "৫০০ সস", 129, 3),
        Product(25, "০১ কেজি সস", 245, 3),
        Product(26, "০২ কেজি সস", 470, 3),
        Product(27, "৫ কেজি সস", 770, 3),
        Product(28, "পাতা সস", 23, 3),
        Product(29, "নাগা চিলি সস", 100, 3),

        // Group 5
        Product(30, "প্রাণ চাটনি", 4, 4),
        Product(31, "জলপাই", 8, 4),
        Product(32, "আম ভাগ আচার", 98, 4),
        Product(33, "কালোজিরা", 0, 4),

        // Group 6
        Product(34, "জেমস ০৫", 95, 5),
        Product(35, "ফিডার", 460, 5),
        Product(36, "ডরিমেন", 240, 5),
        Product(37, "চশমা", 300, 5),

        // Group 7
        Product(38, "টোস্ট ১০", 8, 6),
        Product(39, "টোস্ট বড়", 55, 6),
        Product(40, "চিড়া ভাজা", 95, 6),

        // Group 8
        Product(41, "লাচ্ছা সেমাই", 40, 7),
        Product(42, "বারমিসিলি সেমাই", 35, 7)
    )
}
