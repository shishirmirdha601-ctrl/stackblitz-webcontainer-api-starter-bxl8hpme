# Proguard rules for Raju Daily Summary
-keepattributes *Annotation*
-keepclassmembers class * {
    @com.google.gson.annotations.SerializedName <fields>;
}
-keep class com.raju.dailysummary.model.** { *; }
