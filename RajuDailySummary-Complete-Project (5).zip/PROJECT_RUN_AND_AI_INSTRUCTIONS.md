# 🚀 রাজু এন্টারপ্রাইজ - দৈনিক বিক্রয় ও মেমো সামারি (সম্পূর্ণ প্রজেক্ট ব্যাকআপ)
> **Raju Daily Summary & Product Counter - 100% Complete Standalone Web & Mobile App**

---

## 📱 ১. কোনো কিছু ইন্সটল ছাড়া সরাসরি চালানোর নিয়ম (Instant 0-Install Run)
আপনি যদি কোনো সফটওয়্যার, Node.js বা সার্ভার ছাড়া সাথে সাথে এই অ্যাপটি মোবাইল বা কম্পিউটারে চালাতে চান:
1. এই জিপ ফাইলটি আনজিপ করুন (Unzip)।
2. ফোল্ডারের ভেতরে থাকা **`Raju-Daily-Summary-Standalone.html`** ফাইলে ডাবল ক্লিক করুন অথবা যেকোনো ব্রাউজারে (Chrome/Edge/Safari/Firefox) ওপেন করুন।
3. **১০০% ইন্টারনেট ছাড়াও সম্পূর্ণ অফলাইনে চলবে:** পণ্যের তালিকা, রেট, স্বয়ংক্রিয় হিসাব, মেমো তৈরি ও CSV ডাউনলোড সরাসরি কাজ করবে।

---

## 💻 ২. কম্পিউটার বা সার্ভারে ডেভেলপমেন্ট / প্রোডাকশন রান করার নিয়ম (For Developers & PC/Server)
প্রজেক্টটিতে **React 19 + TypeScript + Vite + Tailwind CSS + Express backend** রয়েছে:

### ধাপ ১: প্রয়োজনীয় প্যাকেজ ইন্সটল
```bash
npm install
```

### ধাপ ২: লোকাল সার্ভারে রান করা
```bash
npm run dev
```
👉 আপনার ব্রাউজারে খুলুন: **`http://localhost:3000`**

### ধাপ ৩: প্রোডাকশন বিল্ড তৈরি
```bash
npm run build
npm start
```

---

## 🤖 ৩. যেকোনো AI (Gemini, Claude, ChatGPT)-কে দিয়ে নতুন ফিচার যুক্ত বা রিস্টোর করার নিয়ম (For AI Prompting)
ভবিষ্যতে যদি প্রজেক্টটি আবার যেকোনো AI এর কাছে দিতে চান, শুধু এই জিপ (ZIP) ফাইলটি চ্যাটে আপলোড করবেন এবং সাথে নিচের প্রম্পটটি লিখে দেবেন:

> **AI Prompt Template:**
> *"This is the complete source code for 'Raju Daily Summary', a daily sales counter, memo calculation, and product catalog web application built with React, TypeScript, Vite, and Tailwind CSS. All product lists, categories, calculations, photo uploaders, and PDF reports are fully functional. Please review the project structure and run `npm run dev` to start the app."*

---

## 🛡️ ৪. ছবি ও ডেটা নিরাপত্তা (Photo & Data Security)
- সমস্ত পণ্যের ছবি ব্রাউজারের **IndexedDB** এবং **LocalStorage**-এ পার্মানেন্টলি সংরক্ষিত থাকে।
- অ্যাপের ভেতর **"ছবি ও ডেটা পার্মানেন্ট ব্যাকআপ"** বাটনে ক্লিক করলে আপনার সমস্ত আপলোড করা পণ্যের ছবি, মেমো এবং পণ্যের তালিকা একটি একক ফাইলে ব্যাকআপ হয়ে যায়।
- যেকোনো সময় সেই ব্যাকআপ ফাইলটি রিস্টোর বাটনে দিলে সব ছবি আবার ফিরে আসবে।
