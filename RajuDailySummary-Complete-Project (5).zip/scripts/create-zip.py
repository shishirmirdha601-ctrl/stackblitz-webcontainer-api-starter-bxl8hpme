#!/usr/bin/env python3
import os
import zipfile

def create_project_zip():
    exclude_dirs = {
        'node_modules',
        'dist',
        'dev-dist',
        '.git',
        '.cache',
        '.vscode',
        '.idea'
    }
    exclude_extensions = {'.zip', '.log', '.tmp'}

    targets = [
        'public/RajuDailySummary-Project.zip',
        'public/website-source-code.zip',
        'public/RajuDailySummary-App.zip'
    ]

    os.makedirs('public', exist_ok=True)

    # First collect files
    files_to_zip = []
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude_dirs and (not d.startswith('.') or d == '.github')]
        for file in files:
            ext = os.path.splitext(file)[1]
            if ext in exclude_extensions:
                continue
            if file.startswith('.DS_Store'):
                continue
            filepath = os.path.join(root, file)
            arcname = os.path.relpath(filepath, '.')
            # Skip root zip files
            if arcname.endswith('.zip'):
                continue
            files_to_zip.append((filepath, arcname))

    for target in targets:
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as zf:
            for filepath, arcname in files_to_zip:
                zf.write(filepath, arcname)
        size_kb = os.path.getsize(target) / 1024
        print(f"Created {target} ({size_kb:.1f} KB, {len(files_to_zip)} files)")

if __name__ == '__main__':
    create_project_zip()
