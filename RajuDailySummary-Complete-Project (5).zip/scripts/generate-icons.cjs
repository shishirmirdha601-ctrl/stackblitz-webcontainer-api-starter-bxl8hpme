const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

// CRC32 table
const crcTable = [];
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    if (c & 1) c = 0xedb88320 ^ (c >>> 1);
    else c = c >>> 1;
  }
  crcTable[n] = c >>> 0;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = (c >>> 8) ^ crcTable[(c ^ buf[i]) & 0xff];
  }
  return (c ^ 0xffffffff) >>> 0;
}

function makeChunk(type, data) {
  const len = data.length;
  const buf = Buffer.alloc(4 + 4 + len + 4);
  buf.writeUInt32BE(len, 0);
  buf.write(type, 4, 4, 'ascii');
  data.copy(buf, 8);
  const typeAndData = buf.subarray(4, 8 + len);
  const crc = crc32(typeAndData);
  buf.writeUInt32BE(crc, 8 + len);
  return buf;
}

function createPNG(width, height, drawFn) {
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  // IHDR chunk
  const ihdrData = Buffer.alloc(13);
  ihdrData.writeUInt32BE(width, 0);
  ihdrData.writeUInt32BE(height, 4);
  ihdrData.writeUInt8(8, 8); // bit depth 8
  ihdrData.writeUInt8(6, 9); // RGBA
  ihdrData.writeUInt8(0, 10); // compression
  ihdrData.writeUInt8(0, 11); // filter
  ihdrData.writeUInt8(0, 12); // interlace
  const ihdr = makeChunk('IHDR', ihdrData);

  // Raw image scanlines
  // Each row starts with filter byte 0 (None), followed by width * 4 bytes RGBA
  const rawBytes = Buffer.alloc(height * (1 + width * 4));
  for (let y = 0; y < height; y++) {
    const rowOffset = y * (1 + width * 4);
    rawBytes[rowOffset] = 0; // Filter: none
    for (let x = 0; x < width; x++) {
      const pxOffset = rowOffset + 1 + x * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rawBytes[pxOffset] = r;
      rawBytes[pxOffset + 1] = g;
      rawBytes[pxOffset + 2] = b;
      rawBytes[pxOffset + 3] = a;
    }
  }

  const compressed = zlib.deflateSync(rawBytes, { level: 9 });
  const idat = makeChunk('IDAT', compressed);
  const iend = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdr, idat, iend]);
}

// Visual drawing function for HUB HUB Icon
function drawHubHubIcon(x, y, w, h, isMaskable = false) {
  // Normalize coords [0, 1]
  const nx = x / w;
  const ny = y / h;

  // Background: dark navy slate (#111827)
  let r = 17, g = 24, b = 39, a = 255;

  // Inner card bounds
  const margin = isMaskable ? 0.2 : 0.12;
  const cardX1 = margin, cardX2 = 1 - margin;
  const cardY1 = margin, cardY2 = 1 - margin;

  // Check if inside memo card
  if (nx >= cardX1 && nx <= cardX2 && ny >= cardY1 && ny <= cardY2) {
    // Memo paper: white #ffffff
    r = 255; g = 255; b = 255;

    // Header stripe on paper (amber #f59e0b)
    const headerHeight = (cardY2 - cardY1) * 0.16;
    if (ny >= cardY1 && ny <= cardY1 + headerHeight) {
      r = 245; g = 158; b = 11;
    } else {
      // Lines on receipt
      const relY = (ny - (cardY1 + headerHeight)) / (cardY2 - (cardY1 + headerHeight));
      // Add multiple memo stripes
      const linePos = [0.15, 0.3, 0.45, 0.6, 0.8];
      for (const lp of linePos) {
        if (Math.abs(relY - lp) < 0.035 && nx >= cardX1 + 0.05 && nx <= cardX2 - 0.05) {
          if (lp === 0.8) {
            // Total accent green or dark
            r = 34; g = 197; b = 94;
          } else {
            // Gray line
            r = 203; g = 213; b = 225;
          }
        }
      }
    }
  }

  // Rounded corner clipping for standard icons (non-maskable)
  if (!isMaskable) {
    const cornerRadius = 0.22;
    // Check corners
    const checkCorner = (cx, cy) => {
      const dx = Math.abs(nx - cx);
      const dy = Math.abs(ny - cy);
      if (dx > (0.5 - cornerRadius) && dy > (0.5 - cornerRadius)) {
        const ox = dx - (0.5 - cornerRadius);
        const oy = dy - (0.5 - cornerRadius);
        if (ox * ox + oy * oy > cornerRadius * cornerRadius) {
          a = 0; // transparent outside rounded corner
        }
      }
    };
    checkCorner(0.5, 0.5);
  }

  return [r, g, b, a];
}

const publicDir = path.resolve(__dirname, '../public');

// 1. 192x192
const pwa192 = createPNG(192, 192, (x, y, w, h) => drawHubHubIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), pwa192);

// 2. 512x512
const pwa512 = createPNG(512, 512, (x, y, w, h) => drawHubHubIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), pwa512);

// 3. 512x512 maskable (safe zone 80%, no rounded transparent corners)
const pwaMaskable = createPNG(512, 512, (x, y, w, h) => drawHubHubIcon(x, y, w, h, true));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pwaMaskable);

// 4. apple-touch-icon (180x180)
const appleIcon = createPNG(180, 180, (x, y, w, h) => drawHubHubIcon(x, y, w, h, false));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), appleIcon);

console.log('Successfully generated all PWA icons!');
